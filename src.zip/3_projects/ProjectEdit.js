import { useState } from "react";
import { useERP } from "../context/ERPContext";
import { formatProjectId, formatQuotationId } from "../utils/formatUtils";
import { getProjectManagers, getProjectStatus } from "../utils/projectUtils";

function ProjectEdit(props) {

    const { projects, updateProject, customers, employees } = useERP()

    const selectedProject = projects.find(
        project => project.id === props.selectedProjectId
    );

    // 수정 중에는 기존 프로젝트를 직접 변경하지 않고 입력값을 별도 관리
    const [projectName, setProjectName] = useState(selectedProject?.name ?? "");
    const [managerId, setManagerId] = useState(selectedProject?.managerId ?? "");
    const [startDate, setStartDate] = useState(selectedProject?.startDate ?? "");
    const [dueDate, setDueDate] = useState(selectedProject?.dueDate ?? "");
    const [description, setDescription] = useState(selectedProject?.description ?? "");

    const customer = customers.find(
        c => c.id === selectedProject?.customerId
    );

    const projectManagers = getProjectManagers(employees)

    const pastManager = employees.find(
        e => e.id === selectedProject?.managerId
    );

    const keepPastManager =
        selectedProject?.status === "완료" &&
        pastManager &&
        !projectManagers.some(e => e.id === pastManager.id);

    const editProject = (e) => {

        e.preventDefault();

        if (!selectedProject) return;

        const result = updateProject({
            id: selectedProject.id,
            name: projectName.trim(),
            managerId: managerId,
            startDate,
            dueDate,
            description
        })

        if (!result.ok) {
            alert(result.message);
            return;
        }

        props.setPage("detail");
    };

    if (!selectedProject) {
        return (
            <div className="pe-page pj-page">
                <div className="pe-container pj-container">
                    <p>프로젝트를 찾을 수 없습니다.</p>
                    <button className="pe-back pj-back" onClick={() => props.setPage("list")}>
                        ← 프로젝트 목록으로
                    </button>
                </div>
            </div>
        );
    }

    if (selectedProject.status === "완료") {
        return (
            <div className="pe-page pj-page">
                <div className="pe-container pj-container">
                    <p>완료된 프로젝트는 수정할 수 없습니다.</p>
                    <button
                        type="button"
                        className="pe-back pj-back"
                        onClick={() => props.setPage("detail")}
                    >
                        ← 프로젝트 상세로
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="pe-page pj-page">
            <div className="pe-container pj-container">
                <button type="button" className="pe-back pj-back" onClick={() => props.setPage("list")}>
                    ← 프로젝트 목록으로
                </button>

                <header className="pe-heading">
                    <div>
                        <p className="pe-eyebrow pj-eyebrow">PROJECT MANAGEMENT / EDIT</p>
                        <h1>프로젝트 수정</h1>
                        <p className="pe-subtitle pj-subtitle">기존 프로젝트 정보를 확인하고 필요한 항목을 변경하세요.</p>
                    </div>
                    <span className="pe-project-number">
                        {formatProjectId(selectedProject.id)}
                    </span>
                </header>

                <form className="pe-card pj-card" onSubmit={editProject}>
                    <div className="pe-card-heading pj-card-heading">
                        <div>
                            <span className="pe-section-num pj-eyebrow">PROJECT INFO</span>
                            <h2>프로젝트 기본 정보</h2>
                        </div>
                        <span className="pe-card-note">고객사와 연결 견적은 변경할 수 없습니다.</span>
                    </div>

                    <div className="pe-grid">
                        <div className="pe-field pe-full pj-field pj-full">
                            <label htmlFor="pe-name">프로젝트명 <span className="pe-required pj-required">*</span></label>
                            <input
                                id="pe-name"
                                name="projectName"
                                value={projectName}
                                onChange={(e) => setProjectName(e.target.value)}
                                required
                            />
                        </div>

                        <div className="pe-field pj-field">
                            <label>고객사</label>
                            <div className="pe-readonly">
                                {customer?.companyName ?? `고객 ID ${selectedProject.customerId}`}
                            </div>
                        </div>

                        <div className="pe-field pj-field">
                            <label>연결된 견적</label>
                            <div className="pe-readonly">
                                {selectedProject.quotationId != null
                                    ? formatQuotationId(selectedProject.quotationId)
                                    : "미연결"}
                            </div>
                        </div>

                        <div className="pe-field pj-field">
                            <label htmlFor="pe-manager">담당자</label>
                            <select
                                id="pe-manager"
                                name="managerId"
                                value={managerId}
                                onChange={(e) => setManagerId(Number(e.target.value))}
                            >
                                <option value="" disabled>담당자를 선택하세요</option>
                                {keepPastManager && (
                                    <option key={pastManager.id} value={pastManager.id}>{pastManager.name} ({pastManager.status} · 기존 담당자)</option>
                                )}
                                {projectManagers.map(emp => (
                                    <option key={emp.id} value={emp.id}>{emp.name}</option>
                                ))}
                            </select>
                        </div>

                        <div className="pe-field pj-field">
                            <label>진행 상태</label>
                            <div className="pe-readonly pe-readonly-status">
                                <span className="pe-status-dot" />
                                {getProjectStatus(selectedProject)}
                            </div>
                        </div>

                        <div className="pe-field pj-field">
                            <label htmlFor="pe-start-date">시작 예정일</label>
                            <input
                                id="pe-start-date"
                                name="startDate"
                                type="date"
                                value={startDate}
                                onChange={(e) => setStartDate(e.target.value)}
                            />
                        </div>

                        <div className="pe-field pj-field">
                            <label htmlFor="pe-due-date">납품 예정일</label>
                            <input
                                id="pe-due-date"
                                name="dueDate"
                                type="date"
                                value={dueDate}
                                onChange={(e) => setDueDate(e.target.value)}
                            />
                        </div>

                        <div className="pe-field pe-full pj-field pj-full">
                            <label htmlFor="pe-description">프로젝트 설명</label>
                            <textarea
                                id="pe-description"
                                name="description"
                                rows={3}
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                            />
                        </div>
                    </div>

                    <footer className="pe-footer pj-footer">
                        <p><span className="pe-required pj-required">*</span> 필수 입력 항목</p>
                        <div className="pe-actions pj-actions">
                            <button type="button" className="pe-btn pe-cancel pj-btn" onClick={() => props.setPage("detail")}>
                                취소
                            </button>
                            <button type="submit" className="pe-btn pe-save pj-btn pj-primary">
                                변경사항 저장
                            </button>
                        </div>
                    </footer>
                </form>
            </div>
        </div>
    );
}

export default ProjectEdit;
