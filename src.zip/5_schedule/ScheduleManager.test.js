/* [파일 안내] 일정관리 자동 회귀 검사
 * 실행: npm test -- --watchAll=false --runInBand src/5_schedule/ScheduleManager.test.js
 * 테스트용 DOM·저장소에서 동작하며 실제 크롬 데이터는 사용하지 않습니다.
 * 날짜·반복 계산과 화면 입력·저장 결과를 검사합니다. CSS의 실제 배치는 브라우저 검사가 필요합니다.
 */

/* beforeEach에서 저장소·공휴일 응답을 준비하고 사용자 동작 후 화면과 저장 결과를 검증합니다. */
import React from "react";
import userEvent from "@testing-library/user-event";
import { act, fireEvent, render, screen, within } from "@testing-library/react";
import ScheduleManager from "./ScheduleManager";
import ScheduleStaffWeek from "./ScheduleStaffWeek";
import { useERP } from "../context/ERPContext";
import { loadSchedules, mergeScheduleChanges } from "./scheduleStorage";
import ScheduleFormModal, { ScheduleListModal } from "./ScheduleFormModal";
import { ScheduleAgendaItem, ScheduleEvent, ScheduleTimeRow } from "./ScheduleItemParts";
import { createScheduleCopyForm, validateScheduleForm, createEmptyForm } from "./scheduleData";
import { getScheduleProjectId, findScheduleConflicts, getScheduleInterval } from "./scheduleData";
import {
  dateKey, getTodayKey, getNextScheduleDate, getUpcomingSchedules,
  normalizeAttendees, createScheduleForm, excludeOccurrence, expandSchedules,
  getSchedulePeople, getRepeatLabel, getScheduleTime, getRepeatSummary, getScheduleDurationFields, restoreDeletedSchedule,
} from "./scheduleData";

test("손상된 참석자 연결이 저장돼 있어도 회의 조회와 편집에서 오류 없이 이름을 보존한다", async () => {
  saveSchedules([makeStoredSchedule({ date: getTodayKey(), scope: "업무용", category: "회의",
    person: "김담당", employeeId: 802, title: "참석자 복원 회의", attendees: ["외부 참석자"],
    attendeeEmployees: {}, legacyAttendees: null })]);
  render(<ScheduleManager />);
  expect(screen.getByText("참석자: 외부 참석자")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "참석자 복원 회의 일정 수정" }));
  expect(screen.getByRole("dialog", { name: "일정 수정" })).toBeInTheDocument();
  expect(screen.getByRole("checkbox", { name: "외부 참석자", exact: true })).toBeChecked();
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(loadSchedules().items[0].attendees).toEqual(["외부 참석자"]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("주간표는 연결 없는 캐시 이름만 숨기고 HR 직원과 과거 일정 이름은 유지한다", async () => {
  saveSchedules([makeStoredSchedule({ date: "2025-01-01", scope: "업무용", person: "과거 이름" })]);
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(["버려진 이름", "김담당", "과거 이름"]));
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  expect(screen.queryByRole("button", { name: "버려진 이름 일정 펼치기" })).not.toBeInTheDocument();
  expect(screen.getByRole("button", { name: "김담당 일정 펼치기" })).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "과거 이름 일정 펼치기" })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test.each([["옛 이름", "현재 이름"], ["현재 이름", "옛 이름"]])("개명 전후 팀원 이름의 순서와 관계없이 빈 중복 행을 만들지 않는다: %j", (first, second) => {
  const date = getTodayKey();
  const item = { ...createEmptyForm(), id: "rename-only", date, person: "옛 이름", employeeId: 1, title: "이전 기록" };
  render(<ScheduleStaffWeek people={[first, second]} employees={[{ id: 1, name: "현재 이름" }]}
    items={[item]} weekDates={[{ key: date }]} selectedDate={date} holidayDates={{}} />);
  expect(screen.getAllByRole("button", { name: /일정 펼치기$/ })).toHaveLength(1);
  expect(screen.getByRole("button", { name: "현재 이름 일정 펼치기" })).toBeInTheDocument();
});

test("주간표를 연 뒤 현재 이름으로 검색하면 이전 기록을 찾고 검색한 직원 행을 펼친다", async () => {
  const employees = [{ id: 1, name: "현재 이름" }, { id: 2, name: "다른 직원" }];
  useERP.mockReturnValue({ employees, projects: [] });
  saveSchedules([
    makeStoredSchedule({ id: "old", date: getTodayKey(), scope: "업무용", person: "옛 이름", employeeId: 1, title: "개명 전 기록" }),
    makeStoredSchedule({ id: "other", date: getTodayKey(), scope: "업무용", person: "다른 직원", employeeId: 2, title: "다른 직원 기록" }),
  ]);
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(["옛 이름", "현재 이름", "다른 직원"]));
  render(<ScheduleManager />);
  const before = localStorage.getItem(storageKey);
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "현재 이름" } });
  const week = within(screen.getByRole("region", { name: "담당자별 주간 일정표" }));
  expect(week.getByRole("button", { name: "현재 이름 일정 접기" })).toHaveAttribute("aria-expanded", "true");
  expect(week.getByText("개명 전 기록")).toBeInTheDocument();
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "다른 직원" } });
  expect(week.getByRole("button", { name: "다른 직원 일정 접기" })).toBeInTheDocument();
  expect(week.getByText("다른 직원 기록")).toBeInTheDocument();
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "옛 이름" } });
  expect(week.getByRole("button", { name: "현재 이름 일정 접기" })).toBeInTheDocument();
  expect(week.getByText("개명 전 기록")).toBeInTheDocument();
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "" } });
  expect(week.getByRole("button", { name: "현재 이름 일정 펼치기" })).toBeInTheDocument();
  expect(localStorage.getItem(storageKey)).toBe(before);
  expect(getSchedulePeople({ person: "옛 이름", employeeId: 1 }, employees)).toEqual(["옛 이름", "현재 이름"]);
  expect(getSchedulePeople({ person: "옛 이름" }, employees)).toEqual(["옛 이름"]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("개명 전후 담당·참석 일정은 현재 직원 이름의 한 행에 모으고 동명이인은 구분한다", () => {
  const date = getTodayKey();
  const base = { ...createEmptyForm(), date, scope: "업무용" };
  const items = [
    { ...base, id: "old", person: "이전 이름", employeeId: 1, title: "개명 전 담당" },
    { ...base, id: "new", person: "현재 이름", employeeId: 1, title: "개명 후 담당" },
    { ...base, id: "meeting", person: "다른 담당", title: "개명 전 참석",
      attendeeEmployees: [{ id: 1, name: "이전 이름" }], legacyAttendees: [] },
    { ...base, id: "other", person: "현재 이름", employeeId: 2, title: "동명이인 담당" },
  ];
  const before = JSON.stringify(items);
  render(<ScheduleStaffWeek people={["이전 이름", "현재 이름"]}
    employees={[{ id: 1, name: "현재 이름" }, { id: 2, name: "현재 이름" }]}
    items={items} weekDates={[{ key: date }]} selectedDate={date} holidayDates={{}} />);
  expect(screen.getAllByRole("button", { name: /일정 펼치기$/ })).toHaveLength(2);
  fireEvent.click(screen.getByRole("button", { name: "현재 이름 (직원 1) 일정 펼치기" }));
  const row = screen.getByRole("button", { name: "현재 이름 (직원 1) 일정 접기" }).closest("tr");
  expect(within(row).getByText("개명 전 담당")).toBeInTheDocument();
  expect(within(row).getByText("개명 후 담당")).toBeInTheDocument();
  expect(within(row).getByText("개명 전 참석")).toBeInTheDocument();
  expect(within(row).queryByText("동명이인 담당")).not.toBeInTheDocument();
  expect(JSON.stringify(items)).toBe(before);
});

test("견적과 완료 프로젝트의 설명·달력·상세는 원본 상태를 표시한다", async () => {
  useERP.mockReturnValue({
    employees: [], customers: [{ id: 1, companyName: "상태 고객" }],
    projects: [{ id: 1, name: "완료 프로젝트", startDate: getTodayKey(), status: "완료" }],
    quotations: [{ id: 1, customerId: 1, validUntil: getTodayKey(), status: "승인 완료" }],
  });
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("checkbox", { name: "견적 유효기간 표시" }));
  const project = screen.getByRole("button", { name: /완료 프로젝트 · 시작일 선택한 날짜/ });
  expect(project).toHaveAttribute("title", expect.stringContaining("· 완료"));
  const quote = screen.getByRole("button", { name: /견적 #1 유효기간 선택한 날짜/ });
  expect(quote).toHaveAttribute("title", expect.stringContaining("· 승인 완료"));
  expect(screen.getByText("프로젝트 시작일 · 완료")).toBeInTheDocument();
  expect(screen.getByText("프로젝트 상태 · 완료")).toBeInTheDocument();
  expect(screen.queryByText(/상단의 오늘·전체 일정 건수는 직접 등록한 일정 기준/)).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("날짜 더보기는 연동 항목을 읽기 전용으로 표시하고 견적 상태와 작업 완료 필터를 유지한다", async () => {
  useERP.mockReturnValue({
    projects: [{ id: 1, name: "더보기 프로젝트", startDate: getTodayKey() }],
    employees: [], customers: [{ id: 1, companyName: "더보기 고객" }],
    tasks: [{ id: 1, projectId: 1, taskDeadline: getTodayKey(), taskType: "완료 작업", progress: "완료" }],
    quotations: [{ id: 1, customerId: 1, validUntil: getTodayKey(), status: "승인 완료" }],
  });
  render(<ScheduleManager />);
  const before = localStorage.getItem(storageKey);
  fireEvent.click(screen.getByRole("checkbox", { name: "견적 유효기간 표시" }));
  fireEvent.click(screen.getByRole("button", { name: "+ 더보기", exact: true }));
  const dialog = within(screen.getByRole("dialog"));
  expect(dialog.getByRole("status", { name: "목록 표시 건수" })).toHaveTextContent("표시 3건");
  expect(dialog.getByText("견적 상태 · 승인 완료")).toBeInTheDocument();
  expect(dialog.getByRole("link", { name: "견적 관리로 이동" })).toHaveAttribute("href", "/quotation");
  expect(dialog.queryByRole("button", { name: /일정 수정/ })).not.toBeInTheDocument();
  expect(dialog.queryByRole("button", { name: /즐겨찾기/ })).not.toBeInTheDocument();
  fireEvent.change(dialog.getByRole("combobox", { name: "목록 진행 상태" }), { target: { value: "completed" } });
  expect(dialog.getByText("작업 상태 · 완료")).toBeInTheDocument();
  expect(dialog.getByRole("status", { name: "목록 표시 건수" })).toHaveTextContent("표시 1건");
  expect(localStorage.getItem(storageKey)).toBe(before);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("내 일정 선택은 계정 전환과 로그아웃 시 해제되고 없는 부서 선택은 안내 후 초기화된다", async () => {
  const employees = [{ id: 1, name: "영업 직원", department: "영업팀" }, { id: 2, name: "생산 직원", department: "생산팀" }];
  const erp = { employees, projects: [], currentEmployee: employees[0] };
  useERP.mockReturnValue(erp);
  const view = render(<ScheduleManager />);
  const myFilter = () => screen.getByRole("checkbox", { name: "내 담당·참석 일정" });
  fireEvent.click(myFilter());
  expect(myFilter()).toBeChecked();
  useERP.mockReturnValue({ ...erp, currentEmployee: employees[1] });
  view.rerender(<ScheduleManager />);
  expect(myFilter()).not.toBeChecked();
  fireEvent.click(myFilter());
  useERP.mockReturnValue({ ...erp, currentEmployee: null });
  view.rerender(<ScheduleManager />);
  expect(myFilter()).not.toBeChecked();
  expect(myFilter()).toBeDisabled();
  fireEvent.change(screen.getByRole("combobox", { name: "일정 부서 필터" }), { target: { value: "영업팀" } });
  useERP.mockReturnValue({ ...erp, employees: [employees[1]], currentEmployee: null });
  view.rerender(<ScheduleManager />);
  expect(screen.getByRole("combobox", { name: "일정 부서 필터" })).toHaveValue("");
  expect(screen.getByText("선택한 부서가 직원 목록에 없어 전체 부서로 변경했습니다.")).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("로그인 직원의 담당·참석 일정과 부서 필터를 적용하고 초기화한다", async () => {
  const employees = [
    { id: 1, name: "영업 직원", department: "영업팀", status: "재직" },
    { id: 2, name: "생산 직원", department: "생산팀", status: "재직" },
  ];
  useERP.mockReturnValue({ employees, projects: [], currentEmployee: employees[0] });
  saveSchedules([
    makeStoredSchedule({ id: "mine", date: getTodayKey(), title: "내 담당 일정", scope: "업무용", person: "영업 직원", employeeId: 1 }),
    makeStoredSchedule({ id: "meeting", date: getTodayKey(), title: "내 참석 회의", scope: "업무용", person: "생산 직원", employeeId: 2,
      attendees: ["영업 직원"], attendeeEmployees: [{ id: 1, name: "영업 직원" }], legacyAttendees: [] }),
    makeStoredSchedule({ id: "other", date: getTodayKey(), title: "다른 직원 일정", scope: "업무용", person: "생산 직원", employeeId: 2 }),
  ]);
  render(<ScheduleManager />);
  const before = localStorage.getItem(storageKey);
  const calendar = within(screen.getByRole("region", { name: "일정 달력" }));
  fireEvent.click(screen.getByRole("tab", { name: "일별" }));
  fireEvent.click(screen.getByRole("checkbox", { name: "내 담당·참석 일정" }));
  expect(calendar.getByRole("button", { name: /내 참석 회의 선택한 날짜/ })).toBeInTheDocument();
  expect(calendar.queryByRole("button", { name: /다른 직원 일정 선택한 날짜/ })).not.toBeInTheDocument();
  fireEvent.change(screen.getByRole("combobox", { name: "일정 부서 필터" }), { target: { value: "생산팀" } });
  expect(calendar.queryByRole("button", { name: /내 담당 일정 선택한 날짜/ })).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "담당·부서 필터 초기화" }));
  expect(calendar.getByRole("button", { name: /다른 직원 일정 선택한 날짜/ })).toBeInTheDocument();
  expect(localStorage.getItem(storageKey)).toBe(before);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("미완료 마감 조회는 지연·오늘·7일 경계를 구분하고 완료 작업을 제외한다", async () => {
  const day = offset => { const date = new Date(getTodayKey() + "T12:00:00"); date.setDate(date.getDate() + offset); return dateKey(date); };
  useERP.mockReturnValue({ employees: [], projects: [{ id: 1, name: "마감 검증" }],
    tasks: [-1, 0, 6, 7].map((offset, index) => ({ id: index, projectId: 1, taskType: "작업" + offset, taskDeadline: day(offset), progress: "대기중" }))
      .concat({ id: 10, projectId: 1, taskType: "끝난 작업", taskDeadline: day(0), progress: "완료" }) });
  render(<ScheduleManager />);
  fireEvent.click(screen.getByText("미완료 작업 마감 모아보기"));
  const panel = screen.getByRole("combobox", { name: "작업 마감 조회 기간" }).closest("details");
  expect(within(panel).getAllByRole("button")).toHaveLength(2);
  expect(within(panel).queryByText(/끝난 작업/)).not.toBeInTheDocument();
  fireEvent.change(screen.getByRole("combobox", { name: "작업 마감 조회 기간" }), { target: { value: "overdue" } });
  expect(within(panel).getByRole("button")).toHaveTextContent("작업-1");
  fireEvent.change(screen.getByRole("combobox", { name: "작업 마감 조회 기간" }), { target: { value: "today" } });
  expect(within(panel).getByRole("button")).toHaveTextContent("작업0");
  fireEvent.click(within(panel).getByRole("button"));
  expect(screen.getByRole("tab", { name: "일별" })).toHaveAttribute("aria-selected", "true");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("견적 유효기간 표시와 담당자별 작업 행은 저장 일정을 추가하지 않는다", async () => {
  const employees = [{ id: 1, name: "동명", department: "영업팀" }, { id: 2, name: "동명", department: "생산팀" }];
  useERP.mockReturnValue({ employees, projects: [{ id: 1, name: "주간 검증" }],
    tasks: employees.map(employee => ({ id: employee.id, projectId: 1, employeeId: employee.id,
      taskType: "담당 작업" + employee.id, taskDeadline: getTodayKey() })),
    quotations: [{ id: 7, validUntil: getTodayKey(), customerId: 3, employeeId: 1 }],
    customers: [{ id: 3, companyName: "견적 고객" }] });
  render(<ScheduleManager />);
  expect(screen.getByRole("checkbox", { name: "내 담당·참석 일정" })).toBeDisabled();
  fireEvent.click(screen.getByRole("tab", { name: "일별" }));
  expect(screen.queryByRole("button", { name: /견적 #7 유효기간 선택한 날짜/ })).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("checkbox", { name: "견적 유효기간 표시" }));
  expect(screen.getByRole("button", { name: /견적 #7 유효기간 선택한 날짜/ })).toBeInTheDocument();
  expect(screen.getByRole("link", { name: "견적 관리로 이동" })).toHaveAttribute("href", "/quotation");
  fireEvent.click(screen.getByRole("checkbox", { name: "견적 유효기간 표시" }));
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  fireEvent.click(screen.getByRole("button", { name: "동명 (직원 1) 일정 펼치기" }));
  const row = screen.getByRole("button", { name: "동명 (직원 1) 일정 접기" }).closest("tr");
  expect(within(row).getByText("주간 검증 · 담당 작업1 마감")).toBeInTheDocument();
  expect(within(row).queryByText("주간 검증 · 담당 작업2 마감")).not.toBeInTheDocument();
  expect(loadSchedules().items).toEqual([]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("세부 작업 마감은 달력과 선택 날짜에 표시하고 일정 원본에 복제하지 않는다", async () => {
  useERP.mockReturnValue({
    projects: [{ id: 1, name: "제작 프로젝트" }],
    employees: [{ id: 3, name: "담당 직원" }],
    tasks: [{ id: 7, projectId: 1, employeeId: 3, taskType: "검수", taskDeadline: getTodayKey() }],
  });
  render(<ScheduleManager />);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
  expect(screen.getByRole("button", { name: /제작 프로젝트 · 검수 마감 선택한 날짜 일정에서 보기/ })).toBeInTheDocument();
  expect(screen.getByText("마감일 변경은 세부 작업 관리에서 해주세요.")).toBeInTheDocument();
  expect(screen.getByText("담당 직원")).toBeInTheDocument();
  expect(screen.queryByRole("button", { name: /검수 마감 일정 삭제/ })).not.toBeInTheDocument();
  expect(loadSchedules().items).toEqual([]);
});

test("세부 작업 상태와 이동 링크를 표시하고 완료 작업만 달력과 상세에서 숨긴다", async () => {
  useERP.mockReturnValue({
    projects: [{ id: 1, name: "진행 프로젝트" }],
    employees: [],
    tasks: [
      { id: 1, projectId: 1, taskType: "검수", taskDeadline: getTodayKey(), progress: "완료" },
      { id: 2, projectId: 1, taskType: "포장", taskDeadline: getTodayKey(), progress: "작업중" },
    ],
  });
  render(<ScheduleManager />);
  expect(screen.getByText("작업 상태 · 완료")).toBeInTheDocument();
  expect(screen.getAllByRole("link", { name: "세부 작업 관리로 이동" })).toHaveLength(2);
  fireEvent.click(screen.getByRole("checkbox", { name: "완료된 세부 작업 숨기기" }));
  expect(screen.queryByText("작업 상태 · 완료")).not.toBeInTheDocument();
  expect(screen.getByText("작업 상태 · 작업중")).toBeInTheDocument();
  expect(screen.getAllByRole("link", { name: "세부 작업 관리로 이동" })).toHaveLength(1);
  fireEvent.click(screen.getByRole("checkbox", { name: "완료된 세부 작업 숨기기" }));
  expect(screen.getByText("작업 상태 · 완료")).toBeInTheDocument();
  expect(loadSchedules().items).toEqual([]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("프로젝트 이름 변경은 검색과 상세에 반영하고 직원 연결 안내는 저장 원본을 보존한다", async () => {
  const original = makeStoredSchedule({ date: getTodayKey(), scope: "업무용", projectId: 1,
    project: "이전 프로젝트", employeeId: 802, person: "이전 직원",
    attendeeEmployees: [{ id: 999, name: "삭제 직원" }], attendees: ["삭제 직원"] });
  saveSchedules([original]);
  useERP.mockReturnValue({ ...useERP(), projects: [{ id: 1, name: "변경 프로젝트" }] });
  render(<ScheduleManager />);
  const before = localStorage.getItem(storageKey);
  expect(screen.getByText("직원 연결 확인 필요 · 1건")).toBeInTheDocument();
  expect(screen.getByText(/이전 직원 → 김담당 · 이름 변경/)).toHaveTextContent("삭제 직원 · 직원 정보가 없습니다.");
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "변경 프로젝트" } });
  expect(screen.getByRole("button", { name: /09:00.*\[테스트\] 일정 선택한 날짜 일정에서 보기/ })).toBeInTheDocument();
  expect(screen.getByText("변경 프로젝트", { selector: "dd" })).toBeInTheDocument();
  expect(localStorage.getItem(storageKey)).toBe(before);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("담당자별 주간표는 같은 이름의 담당 일정과 이름만 있는 일정을 나눠 표시한다", () => {
  const date = "2026-11-10";
  const item = { ...createEmptyForm(), date, scope: "업무용", person: "김민수" };
  render(<ScheduleStaffWeek people={["김민수"]} weekDates={[{ key: date }]} selectedDate={date}
    holidayDates={{}} items={[
      { ...item, id: "a", employeeId: 1, title: "첫 담당 일정" },
      { ...item, id: "b", employeeId: 2, title: "둘째 담당 일정" },
      { ...item, id: "c", title: "이름만 있는 일정" },
      { ...item, id: "d", person: "", title: "첫 직원 참석 회의", attendees: ["김민수"],
        attendeeEmployees: [{ id: 1, name: "김민수" }], legacyAttendees: [] },
      { ...item, id: "e", person: "", title: "둘째 직원 참석 회의", attendees: ["김민수"],
        attendeeEmployees: [{ id: 2, name: "김민수" }], legacyAttendees: [] },
    ]} />);
  fireEvent.click(screen.getByRole("button", { name: "김민수 (직원 2) 일정 펼치기" }));
  expect(screen.getByText("둘째 담당 일정")).toBeInTheDocument();
  expect(screen.queryByText("첫 담당 일정")).not.toBeInTheDocument();
  expect(screen.getByText("둘째 직원 참석 회의")).toBeInTheDocument();
  expect(screen.queryByText("첫 직원 참석 회의")).not.toBeInTheDocument();
  expect(screen.getByRole("button", { name: "김민수 (이름 기준) 일정 펼치기" })).toBeInTheDocument();
});

test("동명이인 담당자는 겹침에서 구분하고 이름만 있는 참석자는 기존대로 확인한다", () => {
  const candidate = { ...createEmptyForm(), id: "a", date: "2026-11-10", title: "첫 일정",
    scope: "업무용", person: "김민수", employeeId: 1, time: "09:00", endTime: "11:00" };
  const other = { ...candidate, id: "b", title: "둘째 일정", employeeId: 2 };
  const conflicts = item => findScheduleConflicts(candidate, [item], candidate.date, candidate.date, {});
  expect(conflicts(other)).toEqual([]);
  expect(conflicts({ ...other, employeeId: 1, person: "이전 이름" })).toHaveLength(1);
  expect(conflicts({ ...other, employeeId: null })).toHaveLength(1);
  expect(conflicts({ ...other, attendees: ["김민수"] })).toHaveLength(1);
  const meeting = { ...other, person: "", employeeId: null, attendees: ["김민수"], legacyAttendees: [],
    attendeeEmployees: [{ id: 2, name: "김민수" }] };
  expect(conflicts(meeting)).toEqual([]);
  expect(conflicts({ ...meeting, attendeeEmployees: [{ id: 1, name: "김민수" }] })).toHaveLength(1);
  expect(findScheduleConflicts({ ...meeting, id: "c", title: "셋째 일정" }, [meeting],
    candidate.date, candidate.date, {})).toHaveLength(1);
});

/* 가짜 시계와 서버 응답은 테스트 안에서만 사용합니다. afterEach에서 복원해 다른 검사에 영향을 주지 않게 합니다. */
/* 화면 테스트를 읽는 순서: 저장할 데이터 준비 → render로 화면 생성 → fireEvent로 사용자 동작 → expect로 결과 확인.
 * 내부 함수의 모양보다 검색·등록·반복 수정 후 화면과 저장 데이터가 맞는지를 검사합니다.
 */
const storageKey = "made-mate-schedules";

// 실제 화면은 ERPProvider가 필수입니다. 여기서는 useERP를 대체하고 각 검사 전에 빈 목록으로 초기화합니다.
// 따라서 이 검사의 통과가 실제 Provider 연동까지 검증했다는 뜻은 아닙니다. 직원 매핑은 Bridge 테스트에서 별도 검사합니다.
jest.mock("../context/ERPContext", () => {
  return { useERP: jest.fn() };
});

test("끊긴 프로젝트 연결을 찾아 편집 안내를 표시하고 재선택은 저장 전 원본에 반영하지 않는다", async () => {
  saveSchedules([makeStoredSchedule({ scope: "업무용", category: "프로젝트", project: "삭제된 프로젝트", projectId: 99 })]);
  render(<ScheduleManager />);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
  expect(screen.getByText("프로젝트 연결 확인 필요 · 1건")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "[테스트] 일정 연결 확인", hidden: true }));
  expect(screen.getByRole("status", { name: "프로젝트 연결 안내" })).toHaveTextContent("연결했던 프로젝트가 없습니다");
  fireEvent.click(screen.getByRole("button", { name: "프로젝트 다시 선택" }));
  expect(screen.getByRole("combobox", { name: "프로젝트", exact: true })).toHaveValue("");
  expect(JSON.parse(localStorage.getItem(storageKey))[0].projectId).toBe(99);
});

test("과거 반복 중복 정리 전 원본을 보존하고 원본 보존 실패 시 자동 저장을 막는다", () => {
  const raw = JSON.stringify([
    makeStoredSchedule({ id: "early", seriesId: "legacy", repeatType: "monthly" }),
    makeStoredSchedule({ id: "late", seriesId: "legacy", repeatType: "monthly", date: "2026-12-04", title: "다른 내용" }),
  ]);
  localStorage.setItem(storageKey, raw);
  const result = loadSchedules();
  expect(result.readError).toBe(false);
  expect(result.items.map(item => item.id)).toEqual(["early"]);
  const backup = Object.keys(localStorage).find(key => key.startsWith(storageKey + "-backup-"));
  expect(localStorage.getItem(backup)).toBe(raw);
  const originalSet = Storage.prototype.setItem;
  jest.spyOn(Storage.prototype, "setItem").mockImplementation(function(key, value) {
    if (key.startsWith(storageKey + "-backup-")) throw new Error("quota");
    return originalSet.call(this, key, value);
  });
  expect(loadSchedules().readError).toBe(true);
  expect(localStorage.getItem(storageKey)).toBe(raw);
});

test.each([
  [null, 0, false, "등록된 일정이 없습니다. 목록을 닫고 일정 등록 버튼으로 추가해 보세요."],
  ["2026-11-04", 1, false, "선택한 날짜에 일정이 없습니다. 목록을 닫고 일정 등록 버튼으로 추가해 보세요."],
  ["2026-11-04", 1, true, "선택한 날짜에 조건과 일치하는 일정이 없습니다. 검색어나 필터를 변경해 주세요."],
])("빈 목록은 상태 필터보다 원래 비어 있는 이유를 먼저 안내한다: %s/%s/%s", (filterDate, totalCount, hasActiveFilter, message) => {
  render(<ScheduleListModal items={[]} filterDate={filterDate} totalCount={totalCount} hasActiveFilter={hasActiveFilter}
    onClose={jest.fn()} onEdit={jest.fn()} onClearDateFilter={jest.fn()} onToggleFavorite={jest.fn()} />);
  fireEvent.change(screen.getByLabelText("목록 진행 상태"), { target: { value: "completed" } });
  expect(screen.getByText(message)).toBeInTheDocument();
  expect(screen.getByRole("status", { name: "목록 표시 건수" })).toHaveTextContent("표시 0건");
  expect(screen.queryByRole("button", { name: "진행 상태 전체 보기" })).not.toBeInTheDocument();
});

test("목록 도구에서 상태 결과가 없으면 정렬을 유지하며 전체 보기로 돌아간다", () => {
  const items = [makeStoredSchedule({ id: "work", scope: "업무용", status: "pending" }), makeStoredSchedule({ id: "personal" })];
  const original = JSON.stringify(items);
  render(<ScheduleListModal items={items} totalCount={items.length} onClose={jest.fn()} onEdit={jest.fn()} onToggleFavorite={jest.fn()} />);
  const toolbar = screen.getByRole("group", { name: "일정 목록 도구" });
  fireEvent.change(within(toolbar).getByLabelText("목록 정렬"), { target: { value: "title" } });
  fireEvent.change(within(toolbar).getByLabelText("목록 진행 상태"), { target: { value: "completed" } });
  expect(within(toolbar).getByRole("status", { name: "목록 표시 건수" })).toHaveTextContent("표시 0건");
  expect(screen.getByText("선택한 진행 상태에 해당하는 업무 일정이 없습니다.")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "진행 상태 전체 보기" }));
  expect(within(toolbar).getByLabelText("목록 정렬")).toHaveValue("title");
  expect(within(toolbar).getByLabelText("목록 진행 상태")).toHaveValue("all");
  expect(within(toolbar).getByRole("status", { name: "목록 표시 건수" })).toHaveTextContent("표시 2건");
  expect(JSON.stringify(items)).toBe(original);
});

test("팀원이 등록돼 있어도 검색으로 행이 사라지면 조건 안내를 표시한다", async () => {
  saveSchedules([makeSchedule({ person: "김담당" })]);
  render(<ScheduleManager />);
  const roster = localStorage.getItem("made-mate-schedule-team");
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  fireEvent.change(screen.getByLabelText("일정 검색"), { target: { value: "없는검색결과" } });
  expect(screen.getByText("현재 조건에 표시할 팀원이 없습니다. 검색어나 필터를 변경해 주세요.")).toBeInTheDocument();
  expect(screen.queryByText("등록된 팀원이 없습니다. 팀원 목록에서 먼저 등록해 주세요.")).not.toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("일정 검색"), { target: { value: "" } });
  expect(screen.getByRole("region", { name: "담당자별 주간 일정표" })).toBeInTheDocument();
  expect(localStorage.getItem("made-mate-schedule-team")).toBe(roster);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("입력 오류를 해당 칸에 연결하고 값을 고치면 안내를 해제한다", async () => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  const title = screen.getByLabelText("일정 이름");
  fireEvent.invalid(title);
  expect(title).toHaveAttribute("aria-invalid", "true");
  expect(title).toHaveAccessibleDescription(/일정 이름을 입력해 주세요/);
  fireEvent.change(title, { target: { value: "[테스트] 오류 안내" } });
  expect(title).not.toHaveAttribute("aria-invalid");
  fireEvent.change(screen.getByLabelText("종료 시간"), { target: { value: "08:00" } });
  fireEvent.submit(screen.getByRole("form"));
  expect(screen.getByLabelText("종료 시간")).toHaveAttribute("aria-invalid", "true");
  expect(screen.getByLabelText("종료 시간")).toHaveAccessibleDescription("종료 시간은 시작 시간보다 늦게 입력해 주세요.");
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual([]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("접힌 반복 설정의 잘못된 횟수는 오류 안내와 함께 펼친다", async () => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 반복 오류" } });
  fireEvent.change(screen.getByLabelText("반복 설정"), { target: { value: "weekly:1" } });
  fireEvent.change(screen.getByLabelText("반복 종료", { exact: true }), { target: { value: "count" } });
  fireEvent.change(screen.getByLabelText("반복 횟수"), { target: { value: "0" } });
  fireEvent.submit(screen.getByRole("form"));
  const count = screen.getByLabelText("반복 횟수");
  expect(screen.getByRole("group", { name: "일정 추가 설정" })).toHaveAttribute("open");
  expect(count).toHaveAttribute("aria-invalid", "true");
  expect(count).toHaveAccessibleDescription("반복 횟수는 1~1000 사이의 정수로 입력해 주세요.");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("새 일정은 새로고침 후 임시 내용을 복구하며 실제 저장 뒤에는 임시 보관을 제거한다", async () => {
  const view = render(<ScheduleManager />);
  const before = localStorage.getItem(storageKey);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 새로고침 복구" } });
  fireEvent.change(screen.getByLabelText("날짜"), { target: { value: "2026-11-04" } });
  fireEvent.change(screen.getByLabelText("시작 시간"), { target: { value: "10:00" } });
  expect(JSON.parse(sessionStorage.getItem("made-mate-schedule-draft")).form.title).toBe("[테스트] 새로고침 복구");
  expect(localStorage.getItem(storageKey)).toBe(before);
  view.unmount();
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "이어서 작성" }));
  expect(screen.getByLabelText("일정 이름")).toHaveValue("[테스트] 새로고침 복구");
  expect(screen.getByLabelText("날짜")).toHaveValue("2026-11-04");
  expect(screen.getByLabelText("시작 시간")).toHaveValue("10:00");
  const confirm = jest.spyOn(window, "confirm").mockReturnValue(false);
  fireEvent.click(screen.getByRole("button", { name: "취소", exact: true }));
  expect(confirm).toHaveBeenCalled();
  expect(sessionStorage.getItem("made-mate-schedule-draft")).not.toBeNull();
  fireEvent.submit(screen.getByRole("form"));
  expect(sessionStorage.getItem("made-mate-schedule-draft")).toBeNull();
  expect(JSON.parse(localStorage.getItem(storageKey))).toHaveLength(1);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("닫기 확인을 취소하면 임시 보관을 유지하고 닫기를 승인하면 제거한다", async () => {
  const confirm = jest.spyOn(window, "confirm").mockReturnValue(false);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 임시 보관 취소" } });
  fireEvent.click(screen.getByRole("button", { name: "취소", exact: true }));
  expect(sessionStorage.getItem("made-mate-schedule-draft")).not.toBeNull();
  confirm.mockReturnValue(true);
  fireEvent.click(screen.getByRole("button", { name: "취소", exact: true }));
  expect(sessionStorage.getItem("made-mate-schedule-draft")).toBeNull();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("손상된 임시 보관은 자동 덮어쓰기 없이 안내하고 기존 일정 수정은 임시 저장하지 않는다", async () => {
  sessionStorage.setItem("made-mate-schedule-draft", "{broken");
  saveSchedules([makeSchedule({ title: "[테스트] 기존 원본" })]);
  render(<ScheduleManager />);
  expect(screen.getByRole("alert")).toHaveTextContent("임시 작성 내용을 읽지 못했습니다");
  expect(sessionStorage.getItem("made-mate-schedule-draft")).toBe("{broken");
  fireEvent.click(screen.getByRole("button", { name: "임시 보관 초기화" }));
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "[테스트] 기존 원본 일정 수정" }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 수정 중" } });
  expect(sessionStorage.getItem("made-mate-schedule-draft")).toBeNull();
  expect(JSON.parse(localStorage.getItem(storageKey))[0].title).toBe("[테스트] 기존 원본");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("목록 상태 필터는 개인 일정을 제외하고 페이지·건수를 다시 계산하며 원본을 유지한다", () => {
  const items = Array.from({ length: 21 }, (_, index) => makeStoredSchedule({ id: String(index), scope: "업무용", title: `[테스트] 예정 ${index}`, status: "pending" }));
  items.push(makeStoredSchedule({ id: "done", scope: "업무용", title: "[테스트] 완료", status: "completed" }), makeStoredSchedule({ id: "personal", title: "[테스트] 개인" }));
  const before = JSON.stringify(items);
  render(<ScheduleListModal items={items} totalCount={items.length} onEdit={jest.fn()} onClose={jest.fn()} onToggleFavorite={jest.fn()} />);
  fireEvent.click(screen.getByRole("button", { name: "다음 페이지" }));
  fireEvent.change(screen.getByLabelText("목록 진행 상태"), { target: { value: "completed" } });
  expect(screen.getAllByRole("article")).toHaveLength(1);
  expect(screen.getByText("전체 1건 · 1–1건")).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "[테스트] 완료 일정 수정" })).toBeInTheDocument();
  expect(screen.queryByRole("button", { name: "[테스트] 개인 일정 수정" })).not.toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("목록 진행 상태"), { target: { value: "pending" } });
  expect(screen.getByText("전체 21건 · 1–20건")).toBeInTheDocument();
  expect(JSON.stringify(items)).toBe(before);
});

test("선택 날짜로 새 일정을 열고 빠른 설정·공백 정리 결과를 그대로 저장한다", async () => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "다음 기간" }));
  const cell = screen.getByText("4", { selector: ".sm-day-num" });
  fireEvent.click(cell);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  const expected = new Date();
  expected.setMonth(expected.getMonth() + 1, 4);
  expect(screen.getByLabelText("날짜")).toHaveValue(dateKey(expected));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "  [테스트] 빠른 시간  " } });
  fireEvent.change(screen.getByPlaceholderText("작업 내용, 준비 사항, 전달할 메모 등을 입력하세요."), { target: { value: "  첫째 줄\n  둘째 줄  " } });
  fireEvent.change(screen.getByLabelText("시작 시간"), { target: { value: "23:30" } });
  fireEvent.click(screen.getByRole("button", { name: "1시간", exact: true }));
  expect(screen.getByLabelText("종료 시간")).toHaveValue("00:30");
  const nextDay = new Date(expected); nextDay.setDate(nextDay.getDate() + 1);
  expect(screen.getByLabelText("종료 날짜 (여러 날 일정)")).toHaveValue(dateKey(nextDay));
  fireEvent.submit(screen.getByRole("form"));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ date: dateKey(expected), endDate: dateKey(nextDay), endTime: "00:30", title: "[테스트] 빠른 시간", description: "첫째 줄\n  둘째 줄" });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("빠른 시간은 월말·연말을 넘기고 반복의 다음 날 종료를 막으며 종일에서는 숨긴다", () => {
  const form = { ...createEmptyForm(), date: "2026-12-31", time: "23:30" };
  expect(getScheduleDurationFields(form, 120)).toEqual({ endDate: "2027-01-01", endTime: "01:30" });
  expect(getScheduleDurationFields({ ...form, time: "10:00", endDate: "2027-01-02" }, 30)).toEqual({ endDate: "", endTime: "10:30" });
  expect(getScheduleDurationFields({ ...form, time: "" }, 60)).toBeNull();
  const props = { form: { ...form, repeatType: "weekly" }, teamMembers: [], onChange: jest.fn(), onSubmit: jest.fn(), onClose: jest.fn() };
  const { rerender } = render(<ScheduleFormModal {...props} />);
  expect(screen.getByRole("button", { name: "30분", exact: true })).toBeDisabled();
  rerender(<ScheduleFormModal {...props} form={{ ...form, isAllDay: true }} />);
  expect(screen.queryByRole("group", { name: "종료 시간 빠른 설정" })).not.toBeInTheDocument();
});

test.each(["none", "weekly"])("%s 일정 삭제를 되돌려 원본을 복구하고 다른 일정의 변경은 유지한다", async repeatType => {
  saveSchedules([makeSchedule({ title: "[테스트] 삭제 복원", repeatType }), makeSchedule({ id: "other", title: "[테스트] 다른 일정", date: "2027-06-01" })]);
  jest.spyOn(window, "confirm").mockReturnValue(true);
  render(<ScheduleManager />);
  const before = JSON.parse(localStorage.getItem(storageKey))[0];
  const section = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(section).getByRole("button", { name: "[테스트] 삭제 복원 일정 삭제" }));
  let saved = JSON.parse(localStorage.getItem(storageKey));
  const afterDelete = saved.find(item => item.id === before.id);
  expect(Boolean(afterDelete)).toBe(repeatType === "weekly");
  expect(afterDelete?.excludedDates.includes(before.date)).toBe(repeatType === "weekly" ? true : undefined);
  saved.find(item => item.id === "other").title = "[테스트] 다른 탭 수정";
  localStorage.setItem(storageKey, JSON.stringify(saved));
  fireEvent(window, new StorageEvent("storage", { key: storageKey }));
  fireEvent.click(screen.getByRole("button", { name: "삭제 되돌리기" }));
  saved = JSON.parse(localStorage.getItem(storageKey));
  expect(saved.find(item => item.id === before.id)).toEqual(before);
  expect(saved.find(item => item.id === "other").title).toBe("[테스트] 다른 탭 수정");
  expect(screen.queryByRole("button", { name: "삭제 되돌리기" })).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("반복 전체 삭제는 제외일·즐겨찾기까지 복구하며 새로고침 후에도 유지된다", async () => {
  saveSchedules([makeSchedule({ title: "[테스트] 전체 복원", repeatType: "monthly", excludedDates: ["2027-01-01"], isFavorite: true })]);
  jest.spyOn(window, "confirm").mockReturnValue(true);
  const view = render(<ScheduleManager />);
  const before = JSON.parse(localStorage.getItem(storageKey));
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "[테스트] 전체 복원 일정 수정" }));
  fireEvent.click(screen.getByRole("button", { name: "일정 삭제", exact: true }));
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual([]);
  fireEvent.click(screen.getByRole("button", { name: "삭제 되돌리기" }));
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual(before);
  view.unmount();
  render(<ScheduleManager />);
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual(before);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("되돌리기는 같은 ID의 재등록과 변경된 원본 반복을 덮어쓰지 않는다", () => {
  const before = makeSchedule({ repeatType: "weekly", excludedDates: [] });
  const after = excludeOccurrence(before, before.date);
  const changed = { ...after, title: "다른 탭 수정" };
  expect(restoreDeletedSchedule([changed], { before, after }).error).toBeTruthy();
  expect(restoreDeletedSchedule([changed], { before, after }).items).toEqual([changed]);
  expect(restoreDeletedSchedule([], { before, after }).error).toBeTruthy();
  expect(restoreDeletedSchedule([changed], { before, after: null }).error).toBeTruthy();
});

test("삭제 취소는 기록을 만들지 않고 연속 삭제는 최근 한 건만 복구하며 15초 후 만료된다", async () => {
  jest.useFakeTimers();
  saveSchedules([makeSchedule({ id: "one", title: "[테스트] 첫 삭제" }), makeSchedule({ id: "two", title: "[테스트] 둘 삭제" })]);
  const confirm = jest.spyOn(window, "confirm").mockReturnValue(false);
  render(<ScheduleManager />);
  const section = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(section).getByRole("button", { name: "[테스트] 첫 삭제 일정 삭제" }));
  expect(screen.queryByRole("button", { name: "삭제 되돌리기" })).not.toBeInTheDocument();
  confirm.mockReturnValue(true);
  fireEvent.click(within(section).getByRole("button", { name: "[테스트] 첫 삭제 일정 삭제" }));
  fireEvent.click(within(section).getByRole("button", { name: "[테스트] 둘 삭제 일정 삭제" }));
  fireEvent.click(screen.getByRole("button", { name: "삭제 되돌리기" }));
  expect(JSON.parse(localStorage.getItem(storageKey)).map(item => item.id)).toEqual(["two"]);
  fireEvent.click(within(section).getByRole("button", { name: "[테스트] 둘 삭제 일정 삭제" }));
  act(() => { jest.advanceTimersByTime(15000); });
  expect(screen.queryByRole("status", { name: "일정 삭제 안내" })).not.toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual([]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("검색·필터 초기화는 조건을 지우고 선택한 보기와 저장 데이터를 유지한다", async () => {
  saveSchedules([makeSchedule()]);
  render(<ScheduleManager />);
  const before = localStorage.getItem(storageKey);
  expect(screen.queryByRole("button", { name: "검색·필터 초기화" })).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("tab", { name: "주별" }));
  fireEvent.change(screen.getByLabelText("일정 검색"), { target: { value: "없는 검색어" } });
  fireEvent.change(screen.getByLabelText("공유 구분 필터"), { target: { value: "private" } });
  fireEvent.click(screen.getByRole("button", { name: "검색·필터 초기화" }));
  expect(screen.getByLabelText("일정 검색")).toHaveValue("");
  expect(screen.getByLabelText("공유 구분 필터")).toHaveValue("all");
  expect(screen.getByRole("tab", { name: "주별" })).toHaveAttribute("aria-selected", "true");
  expect(screen.queryByRole("button", { name: "검색·필터 초기화" })).not.toBeInTheDocument();
  expect(localStorage.getItem(storageKey)).toBe(before);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("목록은 20건씩 표시하고 페이지 이동 후에도 원래 일정으로 수정·즐겨찾기를 전달한다", () => {
  const items = Array.from({ length: 21 }, (_, index) => makeStoredSchedule({ id: String(index), title: `[테스트] ${String(index).padStart(2, "0")}` }));
  const onEdit = jest.fn();
  const onToggleFavorite = jest.fn();
  const props = { items, totalCount: 21, onClose: jest.fn(), onEdit, onToggleFavorite };
  const { rerender } = render(<ScheduleListModal {...props} />);
  expect(screen.getAllByRole("article")).toHaveLength(20);
  expect(screen.getByText("전체 21건 · 1–20건")).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "이전 페이지" })).toBeDisabled();
  fireEvent.click(screen.getByRole("button", { name: "다음 페이지" }));
  expect(screen.getAllByRole("article")).toHaveLength(1);
  expect(screen.getByText("전체 21건 · 21–21건")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "[테스트] 20 일정 수정" }));
  expect(onEdit).toHaveBeenCalledWith(items[20]);
  fireEvent.click(screen.getByRole("button", { name: "[테스트] 20 즐겨찾기 추가" }));
  expect(onToggleFavorite).toHaveBeenCalledWith(items[20]);
  fireEvent.change(screen.getByLabelText("목록 정렬"), { target: { value: "title" } });
  expect(screen.getByText("전체 21건 · 1–20건")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "다음 페이지" }));
  rerender(<ScheduleListModal {...props} items={items.slice(0, 2)} totalCount={2} />);
  expect(screen.getByText("전체 2건 · 1–2건")).toBeInTheDocument();
  expect(screen.queryByRole("button", { name: "다음 페이지" })).not.toBeInTheDocument();
});

test("반복 요약은 추가 설정을 접어도 주기·휴일 처리·종료 조건을 보여준다", () => {
  const form = { ...createEmptyForm(), date: "2026-11-11", repeatType: "monthly", monthlyRule: "weekday", monthlyOrdinal: 2, monthlyWeekday: 3, holidayRule: "nextWorkday", repeatEndType: "count", repeatCount: 6 };
  const props = { form, teamMembers: [], onChange: jest.fn(), onSubmit: jest.fn(), onClose: jest.fn() };
  const { rerender } = render(<ScheduleFormModal {...props} />);
  expect(screen.getByRole("group", { name: "일정 추가 설정" })).not.toHaveAttribute("open");
  expect(screen.getByLabelText("반복 설정 요약")).toHaveTextContent("매월 둘째 수요일");
  expect(screen.getByLabelText("반복 설정 요약")).toHaveTextContent("주말·공휴일은 다음 근무일 · 규칙 6회");
  rerender(<ScheduleFormModal {...props} form={{ ...form, holidayRule: "skip", repeatEndType: "until", repeatEndDate: "2027-01-31" }} />);
  expect(screen.getByLabelText("반복 설정 요약")).toHaveTextContent("주말·공휴일 건너뛰기 · 2027-01-31까지");
  expect(getRepeatSummary({ ...form, repeatType: "none" })).toBe("반복 없음");
});

test("업무의 달력·목록·상세는 같은 완료 배지를 사용하고 개인 일정은 상태를 표시하지 않는다", () => {
  const item = makeStoredSchedule({ scope: "업무용", status: "completed" });
  const props = { item, onSelect: jest.fn(), onEdit: jest.fn(), onDelete: jest.fn(), onStatusChange: jest.fn(), onToggleFavorite: jest.fn() };
  const { rerender } = render(<><ScheduleEvent {...props} compact /><ScheduleAgendaItem {...props} /><ScheduleListModal items={[item]} totalCount={1} onEdit={props.onEdit} onClose={jest.fn()} onToggleFavorite={props.onToggleFavorite} /></>);
  expect(screen.getAllByTitle("완료")).toHaveLength(3);
  expect(screen.getAllByTitle("완료").every(element => element.textContent === "완료")).toBe(true);
  rerender(<ScheduleAgendaItem {...props} item={{ ...item, scope: "개인 일정용" }} />);
  expect(screen.queryByTitle("완료")).toBeNull();
});

function makeStoredSchedule(overrides = {}) {
  return { ...createEmptyForm(), attendees: [], id: "fixture-schedule", scope: "개인 일정용", title: "[테스트] 일정", date: "2026-11-04", ...overrides };
}

test("겹침 경고를 취소하면 입력과 기존 저장 자료를 유지한다", async () => {
  saveSchedules([makeStoredSchedule({ date: getTodayKey(), scope: "업무용",
    person: "김담당", employeeId: 802, time: "09:00", endTime: "17:00" })]);
  render(<ScheduleManager />);
  const before = localStorage.getItem(storageKey);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  chooseWorkSchedule("회의");
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "겹침 취소 검증" } });
  chooseAssignee("김담당");
  const confirm = jest.spyOn(window, "confirm").mockReturnValue(false);
  fireEvent.click(screen.getByRole("button", { name: "일정 저장" }));
  expect(confirm).toHaveBeenCalledWith(expect.stringContaining("그래도 저장할까요?"));
  expect(screen.getByLabelText("일정 이름")).toHaveValue("겹침 취소 검증");
  expect(screen.getByRole("dialog", { name: "새 일정 등록" })).toBeInTheDocument();
  expect(localStorage.getItem(storageKey)).toBe(before);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("마우스 누름과 놓기로 수정창을 열고 내부 입력을 눌러도 유지한다", async () => {
  saveSchedules([makeStoredSchedule({ date: getTodayKey() })]);
  render(<ScheduleManager />);
  userEvent.click(screen.getByRole("button", { name: "[테스트] 일정 일정 수정" }));
  expect(screen.getByRole("dialog", { name: "일정 수정" })).toBeInTheDocument();
  userEvent.click(screen.getByLabelText("일정 이름"));
  expect(screen.getByRole("dialog", { name: "일정 수정" })).toBeInTheDocument();
  expect(screen.getByLabelText("일정 이름")).toHaveValue("[테스트] 일정");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("전체 목록은 날짜·이름·담당자로 정렬하며 원본 배열을 바꾸지 않는다", () => {
  const items = [
    makeStoredSchedule({ id: "a", title: "나 일정", date: "2026-11-03", person: "가 담당" }),
    makeStoredSchedule({ id: "b", title: "가 일정", date: "2026-11-01", person: "나 담당" }),
    makeStoredSchedule({ id: "c", title: "다 일정", date: "2026-11-02", person: "" }),
  ];
  const original = JSON.stringify(items);
  render(<ScheduleListModal items={items} totalCount={3} onClose={jest.fn()} onEdit={jest.fn()} onToggleFavorite={jest.fn()} />);
  const titles = () => screen.getAllByText(/일정$/, { selector: ".sm-list-item-info strong" }).map(element => element.textContent);
  expect(titles()).toEqual(["가 일정", "다 일정", "나 일정"]);
  fireEvent.change(screen.getByLabelText("목록 정렬"), { target: { value: "title" } });
  expect(titles()).toEqual(["가 일정", "나 일정", "다 일정"]);
  fireEvent.change(screen.getByLabelText("목록 정렬"), { target: { value: "person" } });
  expect(titles()).toEqual(["나 일정", "가 일정", "다 일정"]);
  expect(JSON.stringify(items)).toBe(original);
});

test.each([
  [{ repeatEndType: "until", repeatEndDate: "2026-11-18" }, ["2026-11-04", "2026-11-11", "2026-11-18"]],
  [{ repeatEndType: "count", repeatCount: 2 }, ["2026-11-04", "2026-11-11"]],
  [{ repeatEndType: "count", repeatCount: 2, excludedDates: ["2026-11-04"] }, ["2026-11-11"]],
])("주간 반복 종료는 먼 미래와 조회 범위가 달라도 원래 규칙 기준으로 계산한다: %j", (options, dates) => {
  const item = { id: "end-test", title: "[테스트] 종료", date: "2026-11-04", time: "09:00", repeatType: "weekly", repeatInterval: 1, ...options };
  expect(expandSchedules([item], "2026-11-01", "2027-12-31").map(entry => entry.date)).toEqual(dates);
  expect(expandSchedules([item], "2027-01-01", "2027-12-31")).toEqual([]);
});
test("월간 요일 반복은 시작일보다 앞선 이번 달 회차를 횟수에 포함하지 않는다", () => {
  const item = { id: "month-end-test", date: "2026-11-20", time: "09:00", repeatType: "monthly", repeatInterval: 1, monthlyRule: "weekday", monthlyOrdinal: 2, monthlyWeekday: 3, repeatEndType: "count", repeatCount: 2 };
  expect(expandSchedules([item], "2026-11-01", "2027-12-31").map(entry => entry.date)).toEqual(["2026-12-09", "2027-01-13"]);
  expect(expandSchedules([item], "2027-01-01", "2027-12-31").map(entry => entry.date)).toEqual(["2027-01-13"]);
});
test("휴일 건너뛰기도 횟수에 포함하고 종료일까지의 원래 회차는 다음 근무일로 이동할 수 있다", () => {
  const base = { id: "holiday-end", date: "2026-11-01", time: "09:00", repeatType: "monthly", repeatInterval: 1 };
  expect(expandSchedules([{ ...base, holidayRule: "skip", repeatEndType: "count", repeatCount: 2 }], "2026-11-01", "2027-01-31").map(item => item.date)).toEqual(["2026-12-01"]);
  expect(expandSchedules([{ ...base, holidayRule: "nextWorkday", repeatEndType: "until", repeatEndDate: "2026-11-01" }], "2026-11-02", "2026-11-02").map(item => item.date)).toEqual(["2026-11-02"]);
});
test.each([
  [{ repeatEndType: "count", repeatCount: 0 }, "반복 횟수"],
  [{ repeatEndType: "count", repeatCount: 1001 }, "반복 횟수"],
  [{ repeatEndType: "until", repeatEndDate: "2026-10-01" }, "반복 종료 날짜"],
])("반복 종료 입력을 검증한다: %j", (options, message) => {
  expect(validateScheduleForm({ ...createEmptyForm(), scope: "개인 일정용", title: "[테스트] 종료", date: "2026-11-01", repeatType: "weekly", ...options })).toContain(message);
});
test("반복 종료 조건은 저장 자료를 다시 읽거나 수정 폼을 열어도 유지된다", () => {
  saveSchedules([makeSchedule({ repeatType: "weekly", repeatEndType: "count", repeatCount: 3 })]);
  const loaded = loadSchedules().items[0];
  expect(createScheduleForm(loaded)).toMatchObject({ repeatEndType: "count", repeatCount: 3 });
  expect(createScheduleForm({ ...loaded, occurrenceDate: loaded.date })).toMatchObject({ repeatType: "none", repeatEndType: "none" });
});
test("일정 복사는 입력값과 반복 종료만 유지하고 저장 식별자·회차 예외는 복사하지 않는다", () => {
  const item = makeSchedule({ title: "[테스트] 원본", repeatType: "weekly", repeatEndType: "count", repeatCount: 3, isFavorite: true, excludedDates: ["2026-11-11"], status: "completed", replacesScheduleId: "other" });
  const before = JSON.stringify(item);
  const copy = createScheduleCopyForm(item);
  expect(copy).toMatchObject({ title: "[테스트] 원본 (복사)", status: "pending", repeatType: "weekly", repeatEndType: "count", repeatCount: 3 });
  for (const field of ["id", "isFavorite", "excludedDates", "replacesScheduleId"]) expect(copy).not.toHaveProperty(field);
  expect(JSON.stringify(item)).toBe(before);
});
test("수정창에서 복사하면 저장 전까지 원본을 유지하고 저장 시 새 ID를 생성한다", async () => {
  saveSchedules([makeSchedule({ scope: "개인 일정용", title: "[테스트] 복사 원본" })]);
  render(<ScheduleManager />);
  const before = JSON.parse(localStorage.getItem(storageKey));
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "[테스트] 복사 원본 일정 수정" }));
  fireEvent.click(screen.getByRole("button", { name: "일정 복사" }));
  expect(screen.getByLabelText("일정 이름")).toHaveValue("[테스트] 복사 원본 (복사)");
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual(before);
  fireEvent.click(screen.getByRole("button", { name: "일정 저장" }));
  const saved = JSON.parse(localStorage.getItem(storageKey));
  expect(saved).toHaveLength(2);
  expect(saved.find(item => item.id === before[0].id)).toEqual(before[0]);
  expect(saved.find(item => item.title.endsWith("(복사)")).id).not.toBe(before[0].id);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test.each(["until", "count"])("등록 폼에서 반복 종료 %s를 설정해 저장하고 수정 창에서 복원한다", async mode => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 종료 조건 저장" } });
  fireEvent.change(screen.getByLabelText("날짜"), { target: { value: "2026-11-04" } });
  fireEvent.change(screen.getByLabelText("반복 설정"), { target: { value: "weekly:1" } });
  fireEvent.change(screen.getByLabelText("반복 종료", { exact: true }), { target: { value: mode } });
  if (mode === "until") fireEvent.change(screen.getByLabelText("반복 종료 날짜"), { target: { value: "2026-11-18" } });
  else fireEvent.change(screen.getByLabelText("반복 횟수"), { target: { value: "3" } });
  fireEvent.submit(screen.getByRole("form"));
  const saved = JSON.parse(localStorage.getItem(storageKey));
  expect(saved[0].repeatEndType).toBe(mode);
  expect(expandSchedules(saved, "2026-11-01", "2027-12-31").map(item => item.date)).toEqual(["2026-11-04", "2026-11-11", "2026-11-18"]);
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "[테스트] 종료 조건 저장 일정 수정" }));
  expect(screen.getByLabelText("반복 종료", { exact: true })).toHaveValue(mode);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test("회의 등록은 저장 잠금이 풀릴 때까지 폼과 초안을 유지한 뒤 목록에 반영한다", async () => {
  const original = Object.getOwnPropertyDescriptor(navigator, "locks");
  const jobs = [];
  Object.defineProperty(navigator, "locks", { configurable: true, value: {
    request: jest.fn((name, callback) => {
      if (name === "made-mate-schedules-write") jobs.push(callback);
      else callback();
      return Promise.resolve();
    }),
  } });
  try {
    render(<ScheduleManager />);
    await act(async () => { jobs.shift()(); });
    fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
    chooseWorkSchedule("회의");
    chooseAssignee("김담당");
    fireEvent.click(screen.getByRole("checkbox", { name: "이언우 · 과장" }));
    fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "저장 대기 회의" } });
    fireEvent.click(screen.getByRole("button", { name: "일정 저장", exact: true }));
    expect(screen.getByRole("dialog")).toHaveTextContent("일정을 저장하는 중입니다.");
    expect(loadSchedules().items).toEqual([]);
    expect(sessionStorage.getItem("made-mate-schedule-draft")).toContain("저장 대기 회의");
    await act(async () => { jobs.shift()(); });
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(loadSchedules().items[0]).toMatchObject({ title: "저장 대기 회의", attendees: ["이언우"] });
    expect(sessionStorage.getItem("made-mate-schedule-draft")).toBeNull();
  } finally {
    if (original) Object.defineProperty(navigator, "locks", original);
    else delete navigator.locks;
  }
});

test("등록 저장 실패 시 목록에 추가하지 않고 입력을 유지해 한 번만 재등록한다", async () => {
  const originalSet = Storage.prototype.setItem;
  const write = jest.spyOn(Storage.prototype, "setItem").mockImplementation(function (key, value) {
    if (key === storageKey && value.includes("재시도 일정")) throw new Error("저장 실패");
    return originalSet.call(this, key, value);
  });
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "재시도 일정" } });
  fireEvent.click(screen.getByRole("button", { name: "일정 저장", exact: true }));
  expect(within(screen.getByRole("dialog")).getByRole("alert")).toHaveTextContent("다시 저장");
  expect(screen.getByLabelText("일정 이름")).toHaveValue("재시도 일정");
  expect(loadSchedules().items).toEqual([]);
  write.mockRestore();
  fireEvent.click(screen.getByRole("button", { name: "일정 저장", exact: true }));
  expect(loadSchedules().items.map(item => item.title)).toEqual(["재시도 일정"]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("저장 잠금을 기다리는 동안에는 완료가 아닌 저장 중으로 표시한다", async () => {
  const original = Object.getOwnPropertyDescriptor(navigator, "locks");
  const jobs = [];
  Object.defineProperty(navigator, "locks", { configurable: true, value: {
    request: jest.fn((name, callback) => { jobs.push(callback); return Promise.resolve(); }),
  } });
  let view;
  try {
    view = render(<ScheduleManager />);
    expect(screen.getByRole("status", { name: "일정 저장 상태" })).toHaveTextContent("저장 중");
    await act(async () => { jobs.shift()(); });
    expect(screen.getByRole("status", { name: "일정 저장 상태" })).toHaveTextContent("브라우저에 저장 완료");
  } finally {
    view?.unmount();
    if (original) Object.defineProperty(navigator, "locks", original);
    else delete navigator.locks;
  }
});
test("일정 저장 실패를 완료로 표시하지 않는다", async () => {
  const original = Storage.prototype.setItem;
  jest.spyOn(Storage.prototype, "setItem").mockImplementation(function(key, value) {
    if (key === storageKey) throw new Error("Storage unavailable");
    return original.call(this, key, value);
  });
  render(<ScheduleManager />);
  expect(screen.getByRole("status", { name: "일정 저장 상태" })).toHaveTextContent("저장 실패");
  expect(screen.getByRole("alert")).toHaveTextContent("저장하지 못했습니다");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test("손상된 저장 자료는 저장 중지 상태로 표시하고 원본을 유지한다", async () => {
  localStorage.setItem(storageKey, "{invalid-json");
  render(<ScheduleManager />);
  expect(screen.getByRole("status", { name: "일정 저장 상태" })).toHaveTextContent("저장 중지");
  expect(localStorage.getItem(storageKey)).toBe("{invalid-json");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test("읽기 실패 안내에서 정상 자료를 다시 불러오면 저장 중지와 경고를 해제한다", async () => {
  localStorage.setItem(storageKey, "{invalid-json");
  render(<ScheduleManager />);
  const reload = screen.getByRole("button", { name: "현재 변경을 버리고 저장된 일정 불러오기" });
  fireEvent.click(reload);
  expect(screen.getByRole("status", { name: "일정 저장 상태" })).toHaveTextContent("저장 중지");
  expect(localStorage.getItem(storageKey)).toBe("{invalid-json");
  // 실제 브라우저가 아닌 테스트 저장소에서 외부 접근 문제가 해결된 상황을 준비합니다.
  saveSchedules([makeSchedule()]);
  fireEvent.click(reload);
  expect(screen.getByRole("status", { name: "일정 저장 상태" })).toHaveTextContent("브라우저에 저장 완료");
  expect(screen.getByRole("button", { name: "전체 일정 (1)" })).toBeInTheDocument();
  expect(screen.queryByRole("button", { name: "현재 변경을 버리고 저장된 일정 불러오기" })).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test.each(["취소", "닫기", "배경", "Escape"])("작성 중 %s로 닫기를 시도하면 취소 시 입력을 유지하고 확인 시에만 닫는다", async action => {
  render(<ScheduleManager />);
  const opener = screen.getByRole("button", { name: "일정 등록", exact: true });
  opener.focus();
  fireEvent.click(opener);
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 작성 중 보호" } });
  const confirm = jest.spyOn(window, "confirm").mockReturnValue(false);
  const close = () => {
    const dialog = screen.getByRole("dialog");
    if (action === "배경") fireEvent.mouseDown(screen.getByLabelText("일정 팝업 배경"));
    else if (action === "Escape") fireEvent.keyDown(screen.getByLabelText("일정 이름"), { key: "Escape" });
    else fireEvent.click(within(dialog).getByRole("button", { name: action, exact: true }));
  };
  close();
  expect(confirm).toHaveBeenCalledTimes(1);
  expect(screen.getByLabelText("일정 이름")).toHaveValue("[테스트] 작성 중 보호");
  confirm.mockReturnValue(true);
  close();
  expect(confirm).toHaveBeenCalledTimes(2);
  expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  expect(opener).toHaveFocus();
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual([]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test("입력을 원래 값으로 돌리면 닫기 확인을 표시하지 않는다", async () => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  const title = screen.getByLabelText("일정 이름");
  fireEvent.change(title, { target: { value: "[테스트] 되돌리기" } });
  fireEvent.change(title, { target: { value: "" } });
  const confirm = jest.spyOn(window, "confirm").mockReturnValue(false);
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "취소" }));
  expect(confirm).not.toHaveBeenCalled();
  expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test("등록 팝업은 Tab을 순환하고 Escape로 닫은 뒤 등록 버튼에 초점을 돌려준다", async () => {
  render(<ScheduleManager />);
  const opener = screen.getByRole("button", { name: "일정 등록", exact: true });
  opener.focus();
  fireEvent.click(opener);
  const dialog = screen.getByRole("dialog");
  expect(within(dialog).getByLabelText("일정 이름")).toHaveFocus();
  const first = within(dialog).getByRole("button", { name: "닫기" });
  const last = within(dialog).getByRole("button", { name: "일정 저장" });
  last.focus();
  fireEvent.keyDown(last, { key: "Tab" });
  expect(first).toHaveFocus();
  fireEvent.keyDown(first, { key: "Tab", shiftKey: true });
  expect(last).toHaveFocus();
  fireEvent.keyDown(last, { key: "Escape" });
  expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  expect(opener).toHaveFocus();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test("전체 목록 팝업도 처음 초점을 받고 닫기 버튼으로 원래 위치에 복귀한다", async () => {
  render(<ScheduleManager />);
  const opener = screen.getByRole("button", { name: "전체 일정 (0)" });
  opener.focus();
  fireEvent.click(opener);
  const close = within(screen.getByRole("dialog")).getByRole("button", { name: "닫기" });
  expect(close).toHaveFocus();
  fireEvent.click(close);
  expect(opener).toHaveFocus();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
const overnightSchedule = {
  id: "overnight-test", title: "[테스트] 다음 날 오전 종료", date: "2026-11-04", endDate: "2026-11-05",
  time: "18:00", endTime: "09:00", repeatType: "none", scope: "업무용", person: "검사 담당자", status: "pending",
};
test.each([
  ["2026-11-04T17:00:00", 1],
  ["2026-11-05T08:59:00", 1],
  ["2026-11-05T09:00:00", 0],
  ["2026-11-06T00:00:00", 0],
])("여러 날 일정의 시작 전·종료 경계를 확인한다: %s", (now, count) => {
  expect(getUpcomingSchedules([overnightSchedule], new Date(now).getTime(), 5, 7)).toHaveLength(count);
});
test("종일 일정은 마지막 1분까지 유지되고 다음 날 자정에는 종료된다", () => {
  const item = { ...overnightSchedule, isAllDay: true };
  expect(getUpcomingSchedules([item], new Date("2026-11-05T23:59:30").getTime(), 5, 7)).toHaveLength(1);
  expect(getUpcomingSchedules([item], new Date("2026-11-06T00:00:00").getTime(), 5, 7)).toEqual([]);
});
test("여러 날 일정의 표시 시간과 구간 계산은 저장 원본을 바꾸지 않는다", () => {
  const original = JSON.stringify(overnightSchedule);
  const entries = expandSchedules([overnightSchedule], "2026-11-04", "2026-11-05");
  for (const item of entries) {
    const interval = getScheduleInterval(item, true);
    expect(interval.start).toBeLessThan(interval.end);
    getScheduleTime(item);
  }
  expect(JSON.stringify(overnightSchedule)).toBe(original);
});
test.each(["2026-11-04T19:00:00", "2026-11-05T08:00:00"])("여러 날 일정은 %s에도 진행 중으로 한 번만 표시한다", now => {
  const items = getUpcomingSchedules([overnightSchedule], new Date(now).getTime(), 5, 7);
  expect(items).toHaveLength(1);
  expect(items[0].id).toBe(overnightSchedule.id);
  expect(getScheduleInterval(items[0]).start).toBeLessThan(new Date(now).getTime());
});
test("여러 날 일정은 종료 시각 이후 다가오는 목록에서 제외한다", () => {
  expect(getUpcomingSchedules([overnightSchedule], new Date("2026-11-05T09:00:00").getTime(), 5, 7)).toEqual([]);
});
test.each([
  ["2026-11-04", "17:00", "17:30", false],
  ["2026-11-04", "20:00", "21:00", true],
  ["2026-11-05", "08:00", "08:30", true],
  ["2026-11-05", "09:00", "10:00", false],
])("여러 날 일정의 날짜별 실제 구간 충돌 %s %s~%s", (date, time, endTime, overlaps) => {
  const candidate = { ...overnightSchedule, id: "candidate-test", title: "[테스트] 구간 비교", date, time, endTime, endDate: "" };
  expect(findScheduleConflicts(candidate, [overnightSchedule], date, date, {}).length > 0).toBe(overlaps);
});
test("여러 날 카드 시간은 첫날과 마지막 날에 맞춰 표시한다", () => {
  const entries = expandSchedules([overnightSchedule], "2026-11-04", "2026-11-05");
  expect(entries.map(item => getScheduleTime(item))).toEqual(["18:00~24:00", "00:00~09:00"]);
});
test("종료 시간의 최소값은 같은 날짜에만 적용하고 다음 날 오전 종료를 허용한다", async () => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 다음 날 종료" } });
  fireEvent.change(screen.getByLabelText("날짜"), { target: { value: "2026-11-04" } });
  fireEvent.change(screen.getByLabelText("시작 시간"), { target: { value: "18:00" } });
  const end = screen.getByLabelText("종료 시간");
  expect(end).toHaveAttribute("min", "18:00");
  fireEvent.change(screen.getByLabelText("종료 날짜 (여러 날 일정)"), { target: { value: "2026-11-05" } });
  expect(end).not.toHaveAttribute("min");
  fireEvent.change(end, { target: { value: "09:00" } });
  fireEvent.submit(screen.getByRole("form"));
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual(expect.arrayContaining([
    expect.objectContaining({ title: "[테스트] 다음 날 종료", date: "2026-11-04", endDate: "2026-11-05", time: "18:00", endTime: "09:00" }),
  ]));
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
test.each([
  [{ scope: "개인 일정용", project: "예전 프로젝트", projectId: 1 }, null],
  [{ scope: "업무용", project: "", projectId: 1 }, null],
  [{ scope: "업무용", project: "프로젝트", projectId: "" }, null],
  [{ scope: "업무용", project: "프로젝트", projectId: {} }, null],
  [{ scope: "업무용", project: "프로젝트", projectId: 0 }, 0],
  [{ scope: "업무용", project: "프로젝트", projectId: "project-1" }, "project-1"],
])("프로젝트 연결 ID를 기존 자료형을 유지하며 선택값으로 처리한다: %j", (item, expected) => {
  expect(getScheduleProjectId(item)).toBe(expected);
});
test.each([
  ["이름 변경", null, "새 이름", 1],
  ["다른 프로젝트", "다른 이름", "다른 이름", 2],
  ["직접 입력", "자유 입력", "자유 입력", null],
  ["업무 분류 변경", "업무", "새 이름", 1],
  ["개인 전환", "개인 일정용", "", null],
  ["삭제된 프로젝트", null, "이전 이름", 1],
])("프로젝트 연결을 저장까지 유지하거나 명시적으로 변경한다: %s", async (mode, value, expectedName, expectedId) => {
  const projects = mode === "삭제된 프로젝트"
    ? [{ id: 2, name: "이전 이름" }]
    : [{ id: 1, name: "새 이름" }, { id: 2, name: "다른 이름" }];
  useERP.mockReturnValue({ projects, employees: [] });
  const originalProjects = JSON.stringify(projects);
  saveSchedules([makeSchedule({ scope: "업무용", category: "프로젝트", project: "이전 이름", projectId: 1 })]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "검증용 마감 일정 수정" }));
  expect(screen.getByLabelText("프로젝트")).toHaveValue(mode === "삭제된 프로젝트" ? "이전 이름" : "새 이름");
  if (mode === "업무 분류 변경" || mode === "개인 전환") {
    fireEvent.click(screen.getByRole("button", { name: value, exact: true }));
  } else if (value) {
    fireEvent.change(screen.getByLabelText("프로젝트"), { target: { value } });
  }
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ project: expectedName, projectId: expectedId });
  expect(JSON.stringify(projects)).toBe(originalProjects);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("편집창을 연 뒤 프로젝트 이름이 변경돼도 저장 시 ID와 최신 이름을 유지한다", async () => {
  useERP.mockReturnValue({ projects: [{ id: 1, name: "이전 이름" }], employees: [] });
  saveSchedules([makeSchedule({ scope: "업무용", category: "프로젝트", project: "이전 이름", projectId: 1 })]);
  const { rerender } = render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "검증용 마감 일정 수정" }));
  useERP.mockReturnValue({ projects: [{ id: 1, name: "편집 중 변경" }], employees: [] });
  rerender(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ project: "편집 중 변경", projectId: 1 });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("프로젝트 이름 변경 후 반복 한 회차를 수정해도 원본과 분리 회차의 연결을 유지한다", async () => {
  useERP.mockReturnValue({ projects: [{ id: 1, name: "새 이름" }], employees: [] });
  saveSchedules([makeSchedule({ scope: "업무용", category: "프로젝트", project: "이전 이름", projectId: 1, repeatType: "weekly" })]);
  render(<ScheduleManager />);
  const panel = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(panel).getByRole("button", { name: "검증용 마감 일정 수정" }));
  expect(screen.getByLabelText("프로젝트")).toHaveValue("새 이름");
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 분리 회차" } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  const saved = JSON.parse(localStorage.getItem(storageKey));
  expect(saved).toHaveLength(2);
  expect(saved.find(item => item.id === "test-schedule")).toMatchObject({ projectId: 1, excludedDates: [getTodayKey()] });
  expect(saved.find(item => item.title === "[테스트] 분리 회차")).toMatchObject({
    project: "새 이름", projectId: 1, repeatType: "none", replacesScheduleId: "test-schedule",
  });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test.each(["input", "change"])("날짜·시간 %s 이벤트 후 포커스를 옮기지 않고 제출해도 입력값을 저장한다", async eventType => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "[테스트] 즉시 저장" } });
  const date = screen.getByLabelText("날짜");
  const start = screen.getByLabelText("시작 시간");
  const end = screen.getByLabelText("종료 시간");
  fireEvent[eventType](date, { target: { value: "2026-11-04" } });
  fireEvent[eventType](start, { target: { value: "10:00" } });
  end.focus();
  fireEvent[eventType](end, { target: { value: "11:00" } });
  expect(end).toHaveFocus();
  fireEvent.submit(screen.getByRole("form"));
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual(expect.arrayContaining([
    expect.objectContaining({ title: "[테스트] 즉시 저장", date: "2026-11-04", time: "10:00", endTime: "11:00" }),
  ]));
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});
// 테스트 준비에서 일정의 담당자·참석자를 팀원 목록에도 미리 등록합니다.
// 실제 앱은 기존 일정 불러오기만으로 팀원을 만들지는 않으며, 새 업무일정 저장 시 새 이름을 등록합니다.
function saveSchedules(schedules) {
  localStorage.setItem(storageKey, JSON.stringify(schedules));
  const members = [];
  for (const schedule of schedules) {
    for (const name of getSchedulePeople(schedule)) {
      if (!members.includes(name)) members.push(name);
    }
  }
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(members));
}

function chooseAssignee(name) {
  const input = screen.getByRole("textbox", { name: "담당자", exact: true });
  fireEvent.change(input, { target: { value: name } });
  // 입력만으로는 담당자가 선택되지 않습니다. 같은 이름이 있다면 직원 정보에서 선택합니다.
  const results = screen.queryByRole("group", { name: "담당자 검색 결과" });
  if (results) fireEvent.click(within(results).getAllByRole("button")[0]);
}

function chooseWorkSchedule(category = "업무") {
  fireEvent.click(screen.getByRole("button", { name: "업무용", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: category, exact: true }));
}
// 기본 일정에 overrides를 마지막으로 펼쳐 테스트마다 필요한 속성만 바꿉니다.
const makeSchedule = (overrides = {}) => ({
  id: "test-schedule",
  date: getTodayKey(),
  time: "09:00",
  title: "검증용 마감",
  project: "테스트 프로젝트",
  person: "담당자",
  type: "마감",
  status: "pending",
  repeatType: "none",
  ...overrides,
});

test("고객관리 연결을 제거한 뒤에도 기존 일정과 담당자 정보를 유지한다", () => {
  const schedule = makeSchedule({
    person: "일정 담당자",
    connections: { customer: { name: "이전 고객사", phone: "010-0000-0000" } },
  });
  localStorage.setItem(storageKey, JSON.stringify([schedule]));

  const result = loadSchedules();

  expect(result.readError).toBe(false);
  expect(result.items).toHaveLength(1);
  expect(result.items[0]).toMatchObject({
    id: schedule.id,
    title: schedule.title,
    person: "일정 담당자",
  });
  expect(result.items[0]).not.toHaveProperty("connections");
});

// 코드 표현을 바꾼 뒤에도 공백·중복 이름 정리와 원본 보존이 유지되는지 확인합니다.
test("수정 폼과 제외 날짜를 만들 때 저장 원본을 바꾸지 않는다", () => {
  const attendees = [" 민수 ", null, "", "민수", "지수"];
  expect(normalizeAttendees(attendees)).toEqual(["민수", "지수"]);
  expect(normalizeAttendees(" 민수，지수\n민수,,")).toEqual(["민수", "지수"]);
  expect(attendees).toEqual([" 민수 ", null, "", "민수", "지수"]);

  const item = makeSchedule({ attendees, repeatType: "monthly", repeatInterval: 12, occurrenceDate: "2026-10-22", excludedDates: ["2026-10-22", "2026-10-22"] });
  const form = createScheduleForm(item);
  expect(form.attendees).toBe("민수, 지수");
  expect(form.repeatType).toBe("none");
  expect(form.repeatInterval).toBe(1);
  expect(form).not.toHaveProperty("id");
  expect(form).not.toHaveProperty("occurrenceDate");
  expect(excludeOccurrence(item, "2026-11-22").excludedDates).toEqual(["2026-10-22", "2026-11-22"]);
  expect(item.excludedDates).toEqual(["2026-10-22", "2026-10-22"]);
  expect(item.repeatType).toBe("monthly");
});

test("일반 일정 수정은 기존 ID를 유지하고 삭제는 선택한 일정만 제거한다", async () => {
  saveSchedules([
    makeSchedule({ id: "edit-target", title: "수정할 작업" }),
    makeSchedule({ id: "keep", title: "유지할 작업" }),
  ]);
  jest.spyOn(window, "confirm").mockReturnValue(true);
  render(<ScheduleManager />);
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(selected).getByRole("button", { name: "수정할 작업 일정 수정" }));
  fireEvent.change(screen.getByRole("textbox", { name: "일정 이름" }), { target: { value: "수정한 작업" } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));

  let saved = JSON.parse(localStorage.getItem(storageKey));
  expect(saved).toHaveLength(2);
  expect(saved.find((item) => item.id === "edit-target").title).toBe("수정한 작업");
  expect(within(selected).getByText("유지할 작업")).toBeInTheDocument();
  fireEvent.click(within(selected).getByRole("button", { name: "수정한 작업 일정 삭제" }));
  saved = JSON.parse(localStorage.getItem(storageKey));
  expect(saved).toHaveLength(1);
  expect(saved[0].id).toBe("keep");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

// 날짜별 더보기와 전체 목록이 같은 열기 함수를 사용해도 날짜 조건이 남지 않는지 확인합니다.
test("달력 더보기는 해당 날짜만 열고 전체 보기와 다시 열기에서는 모든 일정을 표시한다", async () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-23T12:00:00"));
  saveSchedules([
    makeSchedule({ id: "first", title: "첫 번째 일정" }),
    makeSchedule({ id: "second", title: "두 번째 일정" }),
    makeSchedule({ id: "third", title: "세 번째 일정" }),
    makeSchedule({ id: "other", date: "2026-10-24", title: "다른 날짜 일정" }),
  ]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "+ 더보기" }));
  let dialog = screen.getByRole("dialog");
  expect(within(dialog).getByRole("heading", { name: "2026.10.23 일정" })).toBeInTheDocument();
  expect(within(dialog).getAllByRole("article")).toHaveLength(3);
  expect(within(dialog).queryByText("다른 날짜 일정")).not.toBeInTheDocument();
  fireEvent.click(within(dialog).getByRole("button", { name: "전체 일정 보기" }));
  expect(within(dialog).getAllByRole("article")).toHaveLength(4);
  fireEvent.click(within(dialog).getByRole("button", { name: "닫기" }));
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (4)" }));
  dialog = screen.getByRole("dialog");
  expect(within(dialog).getAllByRole("article")).toHaveLength(4);
  expect(within(dialog).queryByRole("button", { name: "전체 일정 보기" })).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("월말 반복은 짧은 달의 말일에 표시하고 다음 달에는 원래 일자로 돌아온다", () => {
  const monthly = makeSchedule({ date: "2026-01-31", repeatType: "monthly", excludedDates: ["2026-03-31"] });
  const ordinary = makeSchedule({ id: "ordinary", date: "2026-02-15" });
  const result = expandSchedules([monthly, ordinary], "2026-02-01", "2026-05-31");
  expect(result.map((item) => item.date)).toEqual(["2026-02-15", "2026-02-28", "2026-04-30", "2026-05-31"]);
  expect(monthly.date).toBe("2026-01-31");
});

test("monthly weekday rules repeat on the chosen ordinal weekday", () => {
  const monthly = makeSchedule({
    date: "2026-10-14",
    time: "10:00",
    endTime: "11:00",
    repeatType: "monthly",
    monthlyRule: "weekday",
    monthlyOrdinal: 2,
    monthlyWeekday: 3,
  });
  const result = expandSchedules([monthly], "2026-10-01", "2027-01-31");
  expect(result.map((item) => item.date)).toEqual([
    "2026-10-14", "2026-11-11", "2026-12-09", "2027-01-13",
  ]);
  expect(getRepeatLabel(monthly)).toBe("매월 둘째 수요일 10:00~11:00");

  const lastFriday = makeSchedule({
    date: "2026-10-30",
    repeatType: "monthly",
    monthlyRule: "weekday",
    monthlyOrdinal: -1,
    monthlyWeekday: 5,
  });
  expect(expandSchedules([lastFriday], "2026-10-01", "2026-11-30").map((item) => item.date))
    .toEqual(["2026-10-30", "2026-11-27"]);
});

beforeEach(() => {
  useERP.mockReturnValue({ projects: [], employees: [
    { id: 801, name: "담당자", department: "생산관리팀", position: "사원", status: "재직" },
    { id: 802, name: "김담당", department: "영업팀", position: "대리", status: "재직" },
    { id: 803, name: "이언우", department: "경영지원팀", position: "과장", status: "재직" },
    { id: 804, name: "김신규", department: "물류팀", position: "사원", status: "재직" },
  ] });
  // 테스트끼리 저장 데이터를 공유하지 않도록 비웁니다.
  // 실제 공휴일 서버 대신 빈 정상 응답을 사용해 인터넷 상태가 결과에 영향을 주지 않게 합니다.
  localStorage.clear();
  sessionStorage.clear();
  jest.spyOn(global, "fetch").mockResolvedValue({
    ok: true,
    json: async () => [],
  });
});

afterEach(() => {
  // 가짜 시간과 가짜 함수를 원래대로 되돌려 다음 테스트에 영향을 주지 않게 합니다.
  jest.restoreAllMocks();
  jest.useRealTimers();
});

// 현재 입력 목록은 '프로젝트' 한 가지이므로 프로젝트 목록의 이동 경로를 검사합니다. 팀원 경로까지 검사하는 것은 아닙니다.


test("프로젝트 이동 날짜는 반복 제외일을 건너뛰고 미래 일정이 없으면 최근 과거로 정한다", () => {
  // 주간 제외일 두 건, 연간 간격의 월간 반복, 모두 과거인 일반 일정을 각각 확인합니다.
  expect(getNextScheduleDate([makeSchedule({ date: "2026-10-01", repeatType: "weekly", excludedDates: ["2026-10-22", "2026-10-29"] })], "2026-10-22")).toBe("2026-11-05");
  expect(getNextScheduleDate([makeSchedule({ date: "2025-01-31", repeatType: "monthly", repeatInterval: 12, excludedDates: ["2027-01-31"] })], "2026-10-22")).toBe("2028-01-31");
  expect(getNextScheduleDate([makeSchedule({ date: "2026-10-01" }), makeSchedule({ date: "2026-10-15" })], "2026-10-22")).toBe("2026-10-15");
});

test.each([
  ["오늘의 작업 일별 보기", "일별"],
])("%s는 오늘로 이동하고 검색과 필터를 해제한다", async (name, view) => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "다음 기간" }));
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "검색" } });
  fireEvent.change(screen.getByRole("combobox", { name: "공유 구분 필터" }), { target: { value: "private" } });
  fireEvent.click(screen.getByRole("button", { name }));
  expect(screen.getByRole("tab", { name: view })).toHaveAttribute("aria-selected", "true");
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  expect(selected).toHaveTextContent(getTodayKey().replaceAll("-", "."));
  expect(screen.getByRole("textbox", { name: "일정 검색" })).toHaveValue("");
  expect(screen.getByRole("combobox", { name: "공유 구분 필터" })).toHaveValue("all");
  expect(screen.queryByRole("combobox", { name: "업무 상태 필터" })).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("팀원 목록 진입점은 숨기고 담당자별 일정에는 일정에 등록된 사람을 표시한다", async () => {
  saveSchedules([makeSchedule({ person: "김담당", attendees: ["이참석"] })]);
  render(<ScheduleManager />);
  expect(screen.queryByRole("button", { name: "등록된 팀원 목록 보기" })).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  expect(screen.getByRole("button", { name: "김담당 일정 펼치기" })).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "이참석 일정 펼치기" })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("프로젝트·담당자·참석자 검색은 달력에 반영하고 별도 검색 목록은 만들지 않는다", async () => {
  // 가짜 시계로 날짜를 고정합니다. 오늘이 바뀌어도 같은 10월 화면을 검사할 수 있습니다.
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T12:00:00"));
  saveSchedules([
    makeSchedule({ id: "later", date: "2026-10-25", title: "두 번째 작업", project: "검색 프로젝트", person: "김담당", attendees: ["이참석"] }),
    makeSchedule({ id: "first", date: "2026-10-05", title: "첫 번째 작업", project: "검색 프로젝트", person: "김담당", attendees: ["이참석"] }),
    makeSchedule({ id: "outside", date: "2026-11-01", title: "다음 달 작업", project: "검색 프로젝트", person: "김담당" }),
    makeSchedule({ id: "unrelated", title: "다른 작업" }),
  ]);
  render(<ScheduleManager />);
  expect(screen.queryByRole("region", { name: "검색한 일정" })).not.toBeInTheDocument();
  for (const query of [" 검색 프로젝트 ", "김담당", "이참석"]) {
    fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: query } });
    const results = screen.getByRole("region", { name: "일정 달력" });
    expect(within(results).getByText("검색 결과 2건")).toBeInTheDocument();
    expect(within(results).getAllByRole("button", { name: /선택한 날짜 일정에서 보기$/ }).map((element) => within(element).getByText(/작업$/, { selector: "strong" }).textContent)).toEqual(["첫 번째 작업", "두 번째 작업"]);
    expect(within(results).queryByText("다음 달 작업")).not.toBeInTheDocument();
  }
  const calendar = screen.getByRole("region", { name: "일정 달력" });
  fireEvent.click(within(calendar).getByText("5", { selector: ".sm-day-num" }));
  expect(screen.getByRole("region", { name: "선택한 날짜 일정" })).toHaveTextContent("2026.10.05");
  fireEvent.click(screen.getByRole("button", { name: "검색 초기화" }));
  expect(screen.getByRole("textbox", { name: "일정 검색" })).toHaveValue("");
  expect(screen.queryByRole("region", { name: "검색한 일정" })).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("달력 검색은 보기 기간과 공개 필터를 따르고 결과 건수를 표시한다", async () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T12:00:00"));
  saveSchedules([
    makeSchedule({ id: "today", title: "검색 오늘", visibility: "shared" }),
    makeSchedule({ id: "week", date: "2026-10-23", title: "검색 내일", visibility: "private", status: "completed" }),
    makeSchedule({ id: "month", date: "2026-10-05", title: "검색 월초", visibility: "shared" }),
  ]);
  render(<ScheduleManager />);
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "검색" } });
  const count = () => screen.getByText(/^검색 결과 \d+건$/);
  expect(count()).toHaveTextContent("3건");
  fireEvent.click(screen.getByRole("tab", { name: "주별" }));
  expect(count()).toHaveTextContent("2건");
  fireEvent.click(screen.getByRole("tab", { name: "일별" }));
  expect(count()).toHaveTextContent("1건");
  fireEvent.change(screen.getByRole("combobox", { name: "공유 구분 필터" }), { target: { value: "private" } });
  expect(count()).toHaveTextContent("0건");
  fireEvent.click(screen.getByRole("tab", { name: "주별" }));
  expect(count()).toHaveTextContent("1건");
  expect(screen.queryByRole("combobox", { name: "업무 상태 필터" })).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("검색한 반복 일정도 선택 날짜에서 상태 변경·수정·삭제하면 해당 발생일에 적용된다", async () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T12:00:00"));
  saveSchedules([makeSchedule({ date: "2026-10-01", repeatType: "weekly" })]);
  render(<ScheduleManager />);
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "검증용" } });
  const calendar = screen.getByRole("region", { name: "일정 달력" });
  fireEvent.click(within(calendar).getByText("1", { selector: ".sm-day-num" }));
  const results = screen.getByRole("region", { name: "선택한 날짜 일정" });
  expect(screen.getByText("검색 결과 5건")).toBeInTheDocument();
  fireEvent.change(within(results).getAllByRole("combobox")[0], { target: { value: "completed" } });
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual(expect.arrayContaining([
    expect.objectContaining({ date: "2026-10-01", repeatType: "none", status: "completed" }),
    expect.objectContaining({ id: "test-schedule", excludedDates: ["2026-10-01"] }),
  ]));
  fireEvent.click(within(calendar).getByText("8", { selector: ".sm-day-num" }));
  jest.spyOn(window, "confirm").mockReturnValue(true);
  fireEvent.click(within(results).getByRole("button", { name: "검증용 마감 일정 삭제" }));
  expect(screen.getByText("검색 결과 4건")).toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey)).find((entry) => entry.id === "test-schedule").excludedDates).toContain("2026-10-08");
  fireEvent.click(within(calendar).getByText("15", { selector: ".sm-day-num" }));
  fireEvent.click(within(results).getByRole("button", { name: "검증용 마감 일정 수정" }));
  expect(screen.getByLabelText("날짜")).toHaveValue("2026-10-15");
  expect(screen.getByText("선택한 날짜의 일정만 수정합니다. 다른 반복 일정은 유지됩니다.")).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

// 월을 넘는 한 주도 달력에서 양쪽 달을 함께 검색해야 합니다.
test.each(["주별", "담당자별 주간"])("%s는 월 경계 양쪽 일정을 달력에 함께 표시한다", async (view) => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-01T12:00:00"));
  saveSchedules([
    makeSchedule({ id: "previous-month", date: "2026-09-30", title: "경계 작업 전월" }),
    makeSchedule({ id: "current-month", date: "2026-10-02", title: "경계 작업 당월" }),
  ]);
  render(<ScheduleManager />);
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "경계 작업" } });
  fireEvent.click(screen.getByRole("tab", { name: view }));
  if (view === "담당자별 주간") {
    fireEvent.click(screen.getByRole("button", { name: "담당자 일정 펼치기" }));
  }
  const results = screen.getByRole("region", { name: "일정 달력" });
  expect(within(results).getByText("검색 결과 2건")).toBeInTheDocument();
  for (const [date, title] of [["2026-09-30", "경계 작업 전월"], ["2026-10-02", "경계 작업 당월"]]) {
    expect(screen.getByRole("button", { name: `${date} 09:00~17:00 ${title} 선택한 날짜 일정에서 보기` })).toBeInTheDocument();
    expect(within(results).getByText(title)).toBeInTheDocument();
  }
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

// test.each는 같은 검사에 입력값만 바꿔 월말·연말 사례를 각각 실행합니다.
test.each([
  ["2026-10-31", "2026-11-01", "2026년 10월", "2026년 11월"],
  ["2026-12-31", "2027-01-01", "2026년 12월", "2027년 1월"],
])("%s 자정에는 오늘을 보고 있을 때만 선택 날짜와 표시 월을 함께 이동한다", async (today, tomorrow, oldLabel, nextLabel) => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date(`${today}T23:59:59`));
  render(<ScheduleManager />);
  expect(screen.getByRole("heading", { name: oldLabel })).toBeInTheDocument();
  // act는 시계 이동으로 발생한 React 상태 변경까지 반영한 후 다음 검사를 진행하게 합니다.
  await act(async () => { jest.advanceTimersByTime(1500); });
  expect(screen.getByRole("heading", { name: nextLabel })).toBeInTheDocument();
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  expect(within(selected).getByText(new RegExp(tomorrow.replaceAll("-", "\\.")))).toBeInTheDocument();
});

test.each([
  ["2026-10-31", "2026년 10월"],
  ["2026-12-31", "2026년 12월"],
])("%s 자정에 다른 날짜를 보고 있으면 선택 날짜와 표시 월을 유지한다", async (today, label) => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date(`${today}T23:59:59`));
  render(<ScheduleManager />);
  const day = screen.getByText("15", { selector: ".sm-day-num" });
  fireEvent.click(day);
  await act(async () => { jest.advanceTimersByTime(1500); });
  expect(screen.getByRole("heading", { name: label })).toBeInTheDocument();
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  expect(within(selected).getByText(new RegExp(`${today.slice(0, 7).replaceAll("-", "\\.")}\\.15`))).toBeInTheDocument();
  // 화면을 유지해도 '오늘' 표시는 다음 날을 기준으로 갱신됩니다.
  expect(screen.queryByLabelText(getTodayKey())).toBeNull();
});

test("월 이동 후 모든 보기와 신규 등록은 이동한 날짜를 사용한다", async () => {
  const today = new Date(`${getTodayKey()}T00:00:00`);
  const next = new Date(today.getFullYear(), today.getMonth() + 1, 1);
  const lastDay = new Date(next.getFullYear(), next.getMonth() + 1, 0).getDate();
  next.setDate(Math.min(today.getDate(), lastDay));
  const nextKey = dateKey(next);
  saveSchedules([makeSchedule({ date: nextKey })]);
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(["담당자", "김담당"]));
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "다음 기간" }));
  for (const view of ["일별", "주별", "담당자별 주간"]) {
    fireEvent.click(screen.getByRole("tab", { name: view }));
    if (view === "담당자별 주간") {
      fireEvent.click(screen.getByRole("button", { name: "담당자 일정 펼치기" }));
    }
    expect(screen.getByRole("button", { name: `${nextKey} 09:00~17:00 검증용 마감 선택한 날짜 일정에서 보기` })).toBeInTheDocument();
  }
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  chooseWorkSchedule("업무");
  expect(screen.getByLabelText("날짜")).toHaveValue(nextKey);
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "새 작업" } });
  fireEvent.change(screen.getByLabelText("프로젝트"), { target: { value: "새 프로젝트" } });
  chooseAssignee("김담당");
  fireEvent.click(screen.getByRole("button", { name: "일정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))).toEqual(expect.arrayContaining([
    expect.objectContaining({ title: "새 작업", date: nextKey }),
  ]));
  await screen.findByRole("tab", { name: "월별" });
});

test.each(["{broken-json", '{"unexpected":true}'])("읽을 수 없는 원본을 자동 저장으로 덮어쓰지 않는다: %s", async (raw) => {
  localStorage.setItem(storageKey, raw);
  render(<ScheduleManager />);
  expect(screen.getByRole("alert")).toHaveTextContent("자동 저장을 중지");
  expect(localStorage.getItem(storageKey)).toBe(raw);
  fireEvent.click(screen.getByRole("button", { name: "다음 기간" }));
  expect(localStorage.getItem(storageKey)).toBe(raw);
  await screen.findByRole("tab", { name: "월별" });
});

test("일부 잘못된 항목은 원본 백업 후 정상 항목만 불러온다", async () => {
  const raw = JSON.stringify([makeSchedule(), { title: "잘못된 항목" }]);
  localStorage.setItem(storageKey, raw);
  render(<ScheduleManager />);
  const backupKey = Object.keys(localStorage).find((key) => key.startsWith(`${storageKey}-backup-`));
  expect(localStorage.getItem(backupKey)).toBe(raw);
  expect(JSON.parse(localStorage.getItem(storageKey))).toHaveLength(1);
  await screen.findByRole("tab", { name: "월별" });
});

test("완료된 마감은 다가오는 일정에서 제외하고 선택 날짜에서는 유지한다", async () => {
  saveSchedules([makeSchedule({ status: "completed" })]);
  render(<ScheduleManager />);
  const upcoming = screen.getByRole("region", { name: "다가오는 일정" });
  expect(within(upcoming).getByText("오늘부터 7일 이내에 진행 중이거나 시작할 미완료 일정이 없습니다.")).toBeInTheDocument();
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  expect(within(selected).getByText("검증용 마감")).toBeInTheDocument();
  await screen.findByRole("tab", { name: "월별" });
});

test("다가오는 일정은 시작 전·진행 중인 미완료 작업 5건을 시간순으로 표시한다", () => {
  const now = new Date("2026-10-22T12:00:00").getTime();
  const schedules = [
    makeSchedule({ id: "past", date: "2026-10-22", time: "11:00", endTime: "12:00", title: "지난 작업" }),
    makeSchedule({ id: "started", date: "2026-10-22", time: "12:00", title: "이미 시작" }),
    makeSchedule({ id: "done", date: "2026-10-22", time: "12:10", status: "completed" }),
    makeSchedule({ id: "design", date: "2026-10-22", time: "12:30", type: "디자인" }),
    makeSchedule({ id: "repeat", date: "2026-10-22", time: "09:00", endTime: "11:00", type: "기획", repeatType: "weekly", excludedDates: ["2026-10-29"] }),
    makeSchedule({ id: "far", date: "2026-11-01", time: "09:00", type: "검수" }),
  ];
  expect(getUpcomingSchedules(schedules, now).map((item) => `${item.id}/${item.date}`)).toEqual([
    "started/2026-10-22", "design/2026-10-22", "far/2026-11-01", "repeat/2026-11-05", "repeat/2026-11-12",
  ]);
});

test("다가오는 일정은 시작 시 예정에서 진행 중으로 바뀌고 종료 시 자동으로 제거한다", async () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T12:59:30"));
  saveSchedules([
    makeSchedule({ id: "first", date: "2026-10-22", time: "13:00", endTime: "13:01", title: "곧 시작하는 디자인", type: "디자인" }),
    makeSchedule({ id: "next", date: "2026-10-22", time: "14:00", endTime: "14:01", title: "오후 회의", type: "기타" }),
  ]);
  render(<ScheduleManager />);
  const upcoming = screen.getByRole("region", { name: "다가오는 일정" });
  expect(within(upcoming).getByText("곧 시작하는 디자인")).toBeInTheDocument();
  expect(within(upcoming).getByText(/10.22 13:00/)).toBeInTheDocument();
  await act(async () => { jest.advanceTimersByTime(30000); });
  expect(within(upcoming).getByRole("button", { name: /곧 시작하는 디자인/ })).toHaveTextContent("진행 중");
  await act(async () => { jest.advanceTimersByTime(60000); });
  expect(within(upcoming).queryByText("곧 시작하는 디자인")).not.toBeInTheDocument();
  expect(within(upcoming).getByText("오후 회의")).toBeInTheDocument();
  jest.setSystemTime(new Date("2026-10-22T14:01:00"));
  fireEvent(document, new Event("visibilitychange"));
  expect(within(upcoming).getByText("오늘부터 7일 이내에 진행 중이거나 시작할 미완료 일정이 없습니다.")).toBeInTheDocument();
});

test("등록 폼은 고유명사 맞춤법 검사를 끄고 이름 입력값은 그대로 유지한다", async () => {
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(["이언우"]));
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  chooseWorkSchedule();
  const name = screen.getByRole("textbox", { name: "담당자" });
  expect(screen.getByRole("form")).toHaveAttribute("spellcheck", "false");
  expect(screen.getByRole("form")).toHaveAttribute("autocorrect", "off");
  chooseAssignee("이언우");
  expect(name).toHaveValue("이언우");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("기존 일정은 17시 종료로 보완하고 수정한 종료 시간을 저장·표시한다", async () => {
  saveSchedules([makeSchedule()]);
  render(<ScheduleManager />);
  expect(JSON.parse(localStorage.getItem(storageKey))[0].endTime).toBe("17:00");
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  expect(within(selected).getByText("09:00~17:00")).toBeInTheDocument();
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 일정 수정" }));
  expect(screen.getByLabelText("시작 시간")).toHaveValue("09:00");
  expect(screen.getByLabelText("종료 시간")).toHaveValue("17:00");
  fireEvent.change(screen.getByLabelText("종료 시간"), { target: { value: "15:30" } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0].endTime).toBe("15:30");
  expect(within(selected).getByText("09:00~15:30")).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("새 일정은 종료 시간이 시작 시간보다 늦어야 저장한다", async () => {
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(["담당자"]));
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  chooseWorkSchedule();
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "시간 범위 작업" } });
  chooseAssignee("담당자");
  const start = screen.getByLabelText("시작 시간");
  const end = screen.getByLabelText("종료 시간");
  fireEvent.change(start, { target: { value: "10:00" } });
  for (const invalid of ["09:00", "10:00"]) {
    fireEvent.change(end, { target: { value: invalid } });
    fireEvent.submit(screen.getByRole("form"));
    expect(screen.getByRole("alert")).toHaveTextContent("종료 시간은 시작 시간보다 늦게");
    expect(JSON.parse(localStorage.getItem(storageKey))).toHaveLength(0);
  }
  fireEvent.change(end, { target: { value: "18:00" } });
  fireEvent.click(screen.getByRole("button", { name: "일정 저장" }));
  const saved = JSON.parse(localStorage.getItem(storageKey))[0];
  expect(saved.time).toBe("10:00");
  expect(saved.endTime).toBe("18:00");
  expect(screen.getByRole("button", { name: /10:00~18:00 시간 범위 작업 선택한 날짜 일정에서 보기/ })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("월을 넘는 주간 제목은 월과 일을 두 자리씩 표시한다", async () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T12:00:00"));
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("tab", { name: "주별" }));
  fireEvent.click(screen.getByRole("button", { name: "다음 기간" }));
  expect(screen.getByRole("heading", { name: "10/26 – 11/01" })).toBeInTheDocument();
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  expect(screen.getByRole("heading", { name: "10/26 – 11/01" })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("담당자별 주간에서 이름 검색은 해당 사람의 행과 담당·참석 일정을 보여준다", async () => {
  saveSchedules([
    makeSchedule({ id: "shared", title: "복어 회사 작업", person: "복어", attendees: ["가람"], visibility: "shared" }),
    makeSchedule({ id: "private", title: "개인 준비", person: "복어", visibility: "private" }),
    makeSchedule({ id: "attend", title: "공동 회의", person: "가람", attendees: ["복어"], visibility: "shared" }),
    makeSchedule({ id: "other", title: "다른 작업", person: "나래", visibility: "shared" }),
  ]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "복어" } });
  const table = screen.getByRole("region", { name: "담당자별 주간 일정표" });
  const headers = within(table).getAllByRole("rowheader");
  expect(headers).toHaveLength(1);
  expect(headers[0]).toHaveTextContent("복어");
  expect(headers[0]).toHaveTextContent("3건");
  const shared = within(table).getByRole("button", { name: /복어 회사 작업 선택한 날짜 일정에서 보기/ });
  const privateSchedule = within(table).getByRole("button", { name: /개인 준비 선택한 날짜 일정에서 보기/ });
  expect(within(shared).getByText("회사 공유")).toBeInTheDocument();
  expect(within(privateSchedule).getByText("개인 표시")).toBeInTheDocument();
  expect(within(table).getByRole("button", { name: /공동 회의 선택한 날짜 일정에서 보기/ })).toHaveTextContent("참석");
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "테스트 프로젝트" } });
  const projectTable = screen.getByRole("region", { name: "담당자별 주간 일정표" });
  expect(within(projectTable).getAllByRole("rowheader")).toHaveLength(3);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("이름 부분 검색에서는 이름 전체가 일치하는 사람을 먼저 표시한다", async () => {
  saveSchedules([
    makeSchedule({ id: "partial", person: "가복어" }),
    makeSchedule({ id: "exact", person: "복어" }),
    makeSchedule({ id: "other", person: "다른 사람" }),
  ]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "복어" } });
  const table = screen.getByRole("region", { name: "담당자별 주간 일정표" });
  const headers = within(table).getAllByRole("rowheader");
  expect(headers).toHaveLength(2);
  expect(headers[0]).toHaveTextContent(/^복어/);
  expect(headers[1]).toHaveTextContent(/^가복어/);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("즐겨찾기는 검색·월 이동과 무관하게 유지하고 새로고침 후에도 복원한다", async () => {
  saveSchedules([makeSchedule()]);
  const view = render(<ScheduleManager />);
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 즐겨찾기 추가" }));
  let favorites = screen.getByRole("region", { name: "★ 즐겨찾기" });
  expect(within(favorites).getByText("검증용 마감")).toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))[0].isFavorite).toBe(true);
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "없는 검색" } });
  fireEvent.click(screen.getByRole("button", { name: "다음 기간" }));
  expect(within(favorites).getByText("검증용 마감")).toBeInTheDocument();
  expect(screen.queryByRole("region", { name: "검색한 일정" })).not.toBeInTheDocument();
  view.unmount();
  render(<ScheduleManager />);
  favorites = screen.getByRole("region", { name: "★ 즐겨찾기" });
  expect(within(favorites).getByText("검증용 마감")).toBeInTheDocument();
  fireEvent.click(within(favorites).getByRole("button", { name: "검증용 마감 즐겨찾기 해제" }));
  expect(within(favorites).getByRole("status")).toHaveTextContent("0건");
  expect(JSON.parse(localStorage.getItem(storageKey))[0].isFavorite).toBe(false);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("전체 목록에서 즐겨찾기에 추가하고 수정·삭제한 내용은 고정 목록에 즉시 반영한다", async () => {
  saveSchedules([makeSchedule({ date: "2025-01-01" })]);
  jest.spyOn(window, "confirm").mockReturnValue(true);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "검증용 마감 즐겨찾기 추가" }));
  fireEvent.click(screen.getByRole("button", { name: "닫기" }));
  const favorites = screen.getByRole("region", { name: "★ 즐겨찾기" });
  fireEvent.click(within(favorites).getByRole("button", { name: "검증용 마감 일정 수정" }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "새 제목" } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(within(favorites).getByText("새 제목")).toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))[0].isFavorite).toBe(true);
  fireEvent.click(within(favorites).getByRole("button", { name: "새 제목 즐겨찾기 일정으로 이동" }));
  expect(screen.getByRole("tab", { name: "일별" })).toHaveAttribute("aria-selected", "true");
  expect(screen.getByRole("region", { name: "선택한 날짜 일정" })).toHaveTextContent("2025.01.01");
  fireEvent.click(within(favorites).getByRole("button", { name: "새 제목 일정 수정" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "일정 삭제" }));
  expect(within(favorites).getByRole("status")).toHaveTextContent("0건");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("반복 일정의 즐겨찾기는 원본 한 건만 고정하고 한 번의 상태 변경으로 복제되지 않는다", async () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T12:00:00"));
  saveSchedules([makeSchedule({ date: "2026-10-01", repeatType: "weekly" })]);
  render(<ScheduleManager />);
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 즐겨찾기 추가" }));
  const favorites = screen.getByRole("region", { name: "★ 즐겨찾기" });
  expect(within(favorites).getAllByRole("article")).toHaveLength(1);
  fireEvent.change(within(selected).getByRole("combobox"), { target: { value: "completed" } });
  expect(within(favorites).getAllByRole("article")).toHaveLength(1);
  expect(JSON.parse(localStorage.getItem(storageKey)).filter((item) => item.isFavorite)).toHaveLength(1);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("담당자별 주간은 접힌 건수로 시작하고 한 사람씩 펼치거나 다시 접는다", async () => {
  saveSchedules([
    makeSchedule({ id: "a", person: "김담당", title: "김 작업" }),
    makeSchedule({ id: "b", person: "이담당", title: "이 작업" }),
  ]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  const table = screen.getByRole("region", { name: "담당자별 주간 일정표" });
  expect(within(table).queryAllByRole("button", { name: /선택한 날짜 일정에서 보기$/ })).toHaveLength(0);
  const first = within(table).getByRole("button", { name: "김담당 일정 펼치기" });
  expect(first).toHaveAttribute("aria-expanded", "false");
  fireEvent.click(first);
  expect(first).toHaveAttribute("aria-expanded", "true");
  expect(within(table).getByRole("button", { name: /김 작업 선택한 날짜 일정에서 보기/ })).toBeInTheDocument();
  fireEvent.click(within(table).getByRole("button", { name: "이담당 일정 펼치기" }));
  expect(within(table).queryByRole("button", { name: /김 작업 선택한 날짜 일정에서 보기/ })).not.toBeInTheDocument();
  expect(within(table).getByRole("button", { name: /이 작업 선택한 날짜 일정에서 보기/ })).toBeInTheDocument();
  fireEvent.click(within(table).getByRole("button", { name: "이담당 일정 접기" }));
  expect(within(table).queryAllByRole("button", { name: /선택한 날짜 일정에서 보기$/ })).toHaveLength(0);
  fireEvent.click(within(table).getByRole("button", { name: `김담당 ${getTodayKey()} 일정 1건 펼치기` }));
  expect(within(table).getByRole("button", { name: /김 작업 선택한 날짜 일정에서 보기/ })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("이름 검색은 자동으로 펼치고 검색 초기화 시 전체를 접은 목록으로 돌아온다", async () => {
  saveSchedules([
    makeSchedule({ id: "a", person: "김담당", title: "김 작업" }),
    makeSchedule({ id: "b", person: "이담당", title: "이 작업" }),
  ]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  fireEvent.change(screen.getByRole("textbox", { name: "일정 검색" }), { target: { value: "김담당" } });
  const table = screen.getByRole("region", { name: "담당자별 주간 일정표" });
  expect(within(table).getByRole("button", { name: "김담당 일정 접기" })).toHaveAttribute("aria-expanded", "true");
  expect(within(table).getByRole("button", { name: /김 작업 선택한 날짜 일정에서 보기/ })).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "검색 초기화" }));
  const resetTable = screen.getByRole("region", { name: "담당자별 주간 일정표" });
  expect(within(resetTable).getAllByRole("rowheader")).toHaveLength(2);
  expect(within(resetTable).queryAllByRole("button", { name: /선택한 날짜 일정에서 보기$/ })).toHaveLength(0);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("기존 일정의 임의 담당자와 참석자 이름을 편집해도 자동 팀원 등록하지 않는다", async () => {
  localStorage.setItem(storageKey, JSON.stringify([makeSchedule({ person: "임의 이름", attendees: ["외부 참석자"] })]));
  render(<ScheduleManager />);
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 일정 수정" }));
  expect(screen.getByRole("textbox", { name: "담당자", exact: true })).toHaveValue("임의 이름");
  expect(screen.getByRole("checkbox", { name: "외부 참석자" })).toBeChecked();
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0].person).toBe("임의 이름");
  expect(JSON.parse(localStorage.getItem(storageKey))[0].attendees).toEqual(["외부 참석자"]);
  expect(JSON.parse(localStorage.getItem("made-mate-schedule-team"))).toEqual([]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("회의 참석자는 재직 직원을 부서별로 표시하고 동명이인 선택을 각각 저장한다", async () => {
  const erp = useERP();
  useERP.mockReturnValue({ ...erp, employees: [...erp.employees,
    { id: 901, name: "이참석", department: "영업팀", position: "사원", status: "재직" },
    { id: 902, name: "이참석", department: "물류팀", position: "사원", status: "재직" },
    { id: 903, name: "휴직 직원", department: "물류팀", position: "사원", status: "휴직" },
  ] });
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  chooseWorkSchedule("회의");
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "팀 회의" } });
  chooseAssignee("김담당");
  const sales = within(screen.getByRole("group", { name: /영업팀 ·/ })).getByRole("checkbox", { name: "이참석 · 사원" });
  const logistics = within(screen.getByRole("group", { name: /물류팀 ·/ })).getByRole("checkbox", { name: "이참석 · 사원" });
  fireEvent.click(sales);
  expect(logistics).not.toBeChecked();
  fireEvent.click(logistics);
  expect(screen.queryByRole("checkbox", { name: /휴직 직원/ })).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "일정 저장" }));
  const saved = JSON.parse(localStorage.getItem(storageKey))[0];
  expect(saved.person).toBe("김담당");
  expect(saved.attendees).toEqual(["이참석"]);
  expect(saved.attendeeEmployees).toEqual([{ id: 901, name: "이참석" }, { id: 902, name: "이참석" }]);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("담당자별 주간은 등록된 일정 사람을 표시한다", async () => {
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(["김담당"]));
  render(<ScheduleManager />);
  expect(screen.queryByRole("button", { name: "등록된 팀원 목록 보기" })).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  expect(screen.getByRole("button", { name: "김담당 일정 펼치기" })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("팀원 관리 진입점은 숨겨도 담당자별 주간 일정 보기는 유지한다", async () => {
  saveSchedules([makeSchedule({ person: "김담당" })]);
  render(<ScheduleManager />);
  expect(screen.queryByRole("button", { name: "등록된 팀원 목록 보기" })).not.toBeInTheDocument();
  fireEvent.click(screen.getByRole("tab", { name: "담당자별 주간" }));
  expect(screen.getByRole("button", { name: "김담당 일정 펼치기" })).toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))[0].person).toBe("김담당");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("월간 일정 박스의 별은 상세창이나 선택 날짜를 바꾸지 않고 즐겨찾기를 전환한다", async () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T12:00:00"));
  saveSchedules([makeSchedule({ date: "2026-10-23" })]);
  render(<ScheduleManager />);
  const calendar = screen.getByRole("region", { name: "일정 달력" });
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  const star = within(calendar).getByRole("button", { name: "검증용 마감 즐겨찾기 추가" });
  fireEvent.click(star);
  expect(star).toHaveAttribute("aria-pressed", "true");
  expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  expect(selected).toHaveTextContent("2026.10.22");
  const favorites = screen.getByRole("region", { name: "★ 즐겨찾기" });
  expect(within(favorites).getByText("검증용 마감")).toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))[0].isFavorite).toBe(true);
  fireEvent.click(star);
  expect(star).toHaveAttribute("aria-pressed", "false");
  expect(within(favorites).getByRole("status")).toHaveTextContent("0건");
  fireEvent.click(within(calendar).getByRole("button", { name: /검증용 마감 선택한 날짜 일정에서 보기/ }));
  expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  expect(selected).toHaveTextContent("2026.10.23");
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 일정 수정" }));
  expect(screen.getByRole("dialog")).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("공백 이름은 막고 업무 분류의 프로젝트 연결은 보존·수정할 수 있다", async () => {
  saveSchedules([makeSchedule()]);
  render(<ScheduleManager />);
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 일정 수정" }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "   " } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(screen.getByRole("alert")).toHaveTextContent("일정 이름");
  fireEvent.click(within(screen.getByRole("group", { name: "일정 분류" })).getByRole("button", { name: "업무", exact: true }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "  새 이름  " } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ title: "새 이름", project: "테스트 프로젝트", category: "업무" });
  fireEvent.click(within(selected).getByRole("button", { name: "새 이름 일정 수정" }));
  fireEvent.click(within(screen.getByRole("group", { name: "일정 분류" })).getByRole("button", { name: "업무", exact: true }));
  fireEvent.change(screen.getByLabelText("프로젝트"), { target: { value: "  새 프로젝트  " } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ title: "새 이름", project: "새 프로젝트", category: "업무" });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test.each(["즐겨찾기"])("%s 이동은 이미 끝난 오늘 일정 대신 다음 유효 일정 날짜를 연다", async (source) => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-10-22T18:00:00"));
  saveSchedules([makeSchedule({ date: "2026-10-22", time: "09:00", endTime: "17:00", repeatType: "weekly", isFavorite: true })]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "검증용 마감 즐겨찾기 일정으로 이동" }));
  expect(screen.getByRole("region", { name: "선택한 날짜 일정" })).toHaveTextContent("2026.10.29");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("잘못된 날짜·시간은 백업 후 제외하고 손상된 반복 제외일·종료 시간은 안전하게 보완한다", async () => {
  const raw = JSON.stringify([
    makeSchedule({ id: "bad-date", date: "2026-02-31" }),
    makeSchedule({ id: "bad-time", time: "25:90" }),
    makeSchedule({ id: "safe-repeat", repeatType: "weekly", excludedDates: {}, endTime: "wrong" }),
  ]);
  localStorage.setItem(storageKey, raw);
  render(<ScheduleManager />);
  const saved = JSON.parse(localStorage.getItem(storageKey));
  expect(saved).toHaveLength(1);
  expect(saved[0]).toMatchObject({ id: "safe-repeat", endTime: "17:00", excludedDates: [] });
  const backup = Object.keys(localStorage).find((key) => key.startsWith(storageKey + "-backup-"));
  expect(localStorage.getItem(backup)).toBe(raw);
  expect(screen.getByRole("region", { name: "일정 달력" })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

// 기능을 줄인 뒤에도 과거 상태를 읽고 상세 창에서 삭제를 취소·확정할 수 있어야 합니다.
test("단순화한 화면은 기존 상태를 예정으로 읽고 관리 기능을 상세 창에서 제공한다", async () => {
  saveSchedules([makeSchedule({ status: "in_progress", isFavorite: true })]);
  const confirm = jest.spyOn(window, "confirm").mockReturnValue(false);
  render(<ScheduleManager />);
  expect(screen.queryByRole("tab", { name: "시간대별" })).not.toBeInTheDocument();
  expect(screen.getAllByRole("tab")).toHaveLength(4);
  expect(screen.queryByRole("button", { name: "이번 주 마감 주별 보기" })).not.toBeInTheDocument();
  expect(screen.queryByRole("button", { name: "일정 등록 프로젝트 목록 보기" })).not.toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))[0].status).toBe("pending");
  const favorites = screen.getByRole("region", { name: "★ 즐겨찾기" });
  expect(within(favorites).queryByRole("combobox")).not.toBeInTheDocument();
  fireEvent.click(within(favorites).getByRole("button", { name: "검증용 마감 일정 수정" }));
  const dialog = screen.getByRole("dialog");
  expect(within(dialog).queryByLabelText("새 팀원 이름")).not.toBeInTheDocument();
  expect(within(dialog).getByLabelText("프로젝트")).not.toBeRequired();
  expect(within(within(dialog).getByLabelText("일정 상태")).getAllByRole("option").map(option => option.textContent)).toEqual(["예정", "완료"]);
  fireEvent.click(within(dialog).getByRole("button", { name: "일정 삭제" }));
  expect(dialog).toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))).toHaveLength(1);
  confirm.mockReturnValue(true);
  fireEvent.click(within(dialog).getByRole("button", { name: "일정 삭제" }));
  expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))).toHaveLength(0);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("담당자 새 이름은 입력만으로 등록되지 않고 일정 저장 시 함께 등록된다", async () => {
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  chooseWorkSchedule();
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "새 담당자 작업" } });
  const assignee = screen.getByRole("textbox", { name: "담당자", exact: true });
  fireEvent.change(assignee, { target: { value: "  김신규  " } });
  expect(JSON.parse(localStorage.getItem("made-mate-schedule-team"))).toEqual([]);
  expect(screen.queryByRole("button", { name: "팀원 추가" })).not.toBeInTheDocument();
  // 실제 HR 직원 검색 결과를 눌러야 저장됩니다.
  fireEvent.click(within(screen.getByRole("group", { name: "담당자 검색 결과" })).getByRole("button", { name: /김신규/ }));
  fireEvent.click(screen.getByRole("button", { name: "일정 저장" }));
  expect(JSON.parse(localStorage.getItem("made-mate-schedule-team"))).toEqual(["김신규"]);
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ person: "김신규", employeeId: 804 });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test.each(["shared", "private"])("수정 창의 추가 설정은 접힌 채 기존 값 %s를 보존하고 펼쳐서 수정할 수 있다", async (visibility) => {
  saveSchedules([makeSchedule({ type: "검수", visibility })]);
  render(<ScheduleManager />);
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 일정 수정" }));
  const dialog = screen.getByRole("dialog");
  for (const label of ["공유 구분", "반복 설정"]) {
    expect(within(dialog).getByLabelText(label)).not.toBeVisible();
  }
  fireEvent.click(within(dialog).getByText("추가 설정 · 공유 구분·반복·알림"));
  fireEvent.change(within(dialog).getByLabelText("일정 이름"), { target: { value: "간단히 수정" } });
  fireEvent.click(within(dialog).getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ title: "간단히 수정", type: "검수", visibility, repeatType: "none" });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test.each(["2026-10-15T12:00:00", "2026-11-15T12:00:00", "2026-08-15T12:00:00"])("월간 달력은 일요일 시작이며 월 첫날의 위치와 주말 색상이 맞는다: %s", async (now) => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date(now));
  render(<ScheduleManager />);
  const headings = screen.getAllByText(/^[일월화수목금토]$/, { selector: ".sm-weekday" });
  expect(headings.map(day => day.textContent)).toEqual(["일", "월", "화", "수", "목", "금", "토"]);
  expect(headings[0]).toHaveClass("sunday");
  expect(headings[6]).toHaveClass("saturday");
  // 빈 칸은 접근성 트리에서 제외하므로 월 시작 위치의 구조 검사는 전용 표식으로 찾습니다.
  const cells = screen.getAllByTestId("sm-calendar-day");
  const offset = new Date(new Date(now).getFullYear(), new Date(now).getMonth(), 1).getDay();
  expect(cells.findIndex(cell => within(cell).queryByText(/^\d+$/, { selector: ".sm-day-num" }))).toBe(offset);
  expect(within(cells[offset]).getByText("1", { selector: ".sm-day-num" })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("다가오는 일정 7일 제한은 오늘을 포함한 7일만 보이고 이동용 조회는 먼 미래도 유지한다", () => {
  const now = new Date("2026-10-22T12:00:00").getTime();
  const items = [makeSchedule({ id: "near", date: "2026-10-28" }), makeSchedule({ id: "far", date: "2026-10-29" })];
  expect(getUpcomingSchedules(items, now, 5, 7).map(item => item.id)).toEqual(["near"]);
  expect(getUpcomingSchedules(items, now).map(item => item.id)).toEqual(["near", "far"]);
});

test("기존 사용자 지정 반복은 보존하며 간단한 반복 선택으로 바꿀 수 있다", async () => {
  saveSchedules([makeSchedule({ repeatType: "monthly", repeatInterval: 12 })]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "검증용 마감 일정 수정" }));
  fireEvent.click(screen.getByText("추가 설정 · 공유 구분·반복·알림"));
  const repeat = screen.getByLabelText("반복 설정");
  expect(repeat).toHaveValue("monthly:12");
  expect(within(repeat).getAllByRole("option")).toHaveLength(5);
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0].repeatInterval).toBe(12);
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "검증용 마감 일정 수정" }));
  fireEvent.click(screen.getByText("추가 설정 · 공유 구분·반복·알림"));
  fireEvent.change(screen.getByLabelText("반복 설정"), { target: { value: "weekly:2" } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ repeatType: "weekly", repeatInterval: 2 });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("팀원 관리 진입 버튼은 일정 화면에 표시하지 않는다", async () => {
  localStorage.setItem("made-mate-schedule-team", JSON.stringify(["제외할 사람"]));
  render(<ScheduleManager />);
  expect(screen.queryByRole("button", { name: "등록된 팀원 목록 보기" })).not.toBeInTheDocument();
  expect(screen.queryByRole("region", { name: "팀원 목록" })).not.toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("다른 탭에서 추가한 일정을 기존 탭의 저장이 덮어쓰지 않는다", async () => {
  saveSchedules([makeSchedule()]);
  render(<ScheduleManager />);
  const remote = makeSchedule({ id: "remote", title: "다른 탭 추가" });
  const saved = JSON.parse(localStorage.getItem(storageKey));
  localStorage.setItem(storageKey, JSON.stringify([...saved, remote]));
  fireEvent.click(screen.getAllByRole("button", { name: "검증용 마감 즐겨찾기 추가" })[0]);
  expect(JSON.parse(localStorage.getItem(storageKey)).map(item => item.id)).toContain("remote");
  expect(JSON.parse(localStorage.getItem(storageKey)).find(item => item.id === "test-schedule").isFavorite).toBe(true);
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("다른 탭에서 편집 중인 일정을 변경하면 덮어쓰기를 중지한다", async () => {
  saveSchedules([makeSchedule()]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "검증용 마감 일정 수정" }));
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "내 변경" } });
  const remote = JSON.parse(localStorage.getItem(storageKey));
  remote[0].title = "다른 탭 변경";
  localStorage.setItem(storageKey, JSON.stringify(remote));
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0].title).toBe("다른 탭 변경");
  expect(screen.getByLabelText("일정 이름")).toHaveValue("내 변경");
  expect(screen.getByText(/편집 중인 일정이 다른 탭에서/)).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("같은 일정의 동시 변경과 삭제 충돌을 감지하고 다른 일정 변경은 병합한다", () => {
  const a = makeSchedule({ id: "a" });
  const b = makeSchedule({ id: "b" });
  expect(mergeScheduleChanges([a], [{ ...a, title: "내 수정" }], [{ ...a, title: "상대 수정" }]).conflict).toBe(true);
  expect(mergeScheduleChanges([a], [{ ...a, title: "내 수정" }], []).conflict).toBe(true);
  const merged = mergeScheduleChanges([a, b], [a], [a, { ...b, title: "상대 수정" }]);
  expect(merged.conflict).toBe(true);
  expect(mergeScheduleChanges([a, b], [{ ...a, title: "내 수정" }, b], [a]).items)
    .toEqual([{ ...a, title: "내 수정" }]);
});

test("다른 탭 저장 이벤트를 받으면 화면에 최신 일정을 반영한다", async () => {
  saveSchedules([makeSchedule()]);
  render(<ScheduleManager />);
  const remote = JSON.parse(localStorage.getItem(storageKey));
  remote[0].title = "외부에서 갱신한 일정";
  localStorage.setItem(storageKey, JSON.stringify(remote));
  fireEvent(window, new StorageEvent("storage", { key: storageKey }));
  expect(screen.getByRole("button", { name: "외부에서 갱신한 일정 일정 수정" })).toBeInTheDocument();
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("업무에서 개인으로 전환하면 숨겨진 담당자와 상태를 초기화한다", async () => {
  saveSchedules([makeSchedule({ person: "담당자", status: "completed" })]);
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "전체 일정 (1)" }));
  fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "검증용 마감 일정 수정" }));
  fireEvent.click(screen.getByRole("button", { name: "개인 일정용", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "업무용", exact: true }));
  expect(screen.getByRole("textbox", { name: "담당자", exact: true })).toHaveValue("");
  expect(screen.getByLabelText("일정 상태")).toHaveValue("pending");
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("다음 근무일 탐색 범위를 넘는 연속 휴일은 휴일에 일정을 표시하지 않는다", () => {
  const holidays = {};
  for (let day = 1; day <= 20; day += 1) holidays[`2026-11-${String(day).padStart(2, "0")}`] = "휴일";
  const items = [makeSchedule({ date: "2026-11-01", repeatType: "monthly", holidayRule: "nextWorkday" })];
  expect(expandSchedules(items, "2026-11-01", "2026-11-30", holidays)).toEqual([]);
});


test("HR 직원 이름이 정확히 일치해야 검색 결과가 나오고 클릭 전에는 저장되지 않는다", async () => {
  useERP.mockReturnValue({ projects: [], employees: [
    { id: 101, name: "김민수", department: "생산관리팀", position: "사원", status: "재직" },
    { id: 102, name: "김민수", department: "영업팀", position: "과장", status: "재직" },
    { id: 103, name: "김민지", department: "물류팀", position: "사원", status: "휴직" },
  ] });
  render(<ScheduleManager />);
  fireEvent.click(screen.getByRole("button", { name: "일정 등록", exact: true }));
  chooseWorkSchedule();
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "직원 검색 검사" } });
  const input = screen.getByRole("textbox", { name: "담당자", exact: true });
  fireEvent.change(input, { target: { value: "김" } });
  expect(screen.queryByRole("group", { name: "담당자 검색 결과" })).not.toBeInTheDocument();
  fireEvent.change(input, { target: { value: "김민지" } });
  expect(screen.queryByRole("group", { name: "담당자 검색 결과" })).not.toBeInTheDocument();
  fireEvent.change(input, { target: { value: "김민수" } });
  const choices = within(screen.getByRole("group", { name: "담당자 검색 결과" })).getAllByRole("button");
  expect(choices).toHaveLength(2);
  fireEvent.submit(screen.getByRole("form"));
  expect(screen.getByText(/검색 결과에서 선택해 주세요/)).toBeInTheDocument();
  expect(JSON.parse(localStorage.getItem(storageKey))).toHaveLength(0);
  fireEvent.click(choices[1]);
  fireEvent.click(screen.getByRole("button", { name: "일정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ person: "김민수", employeeId: 102 });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});

test("기존 퇴사 담당자의 일정은 이름·ID를 유지한 채 다른 항목 수정 가능", async () => {
  useERP.mockReturnValue({ projects: [], employees: [
    { id: 20, name: "김기존", department: "영업팀", position: "과장", status: "퇴사" },
  ] });
  saveSchedules([makeSchedule({ person: "김기존", employeeId: 20 })]);
  render(<ScheduleManager />);
  const selected = screen.getByRole("region", { name: "선택한 날짜 일정" });
  fireEvent.click(within(selected).getByRole("button", { name: "검증용 마감 일정 수정" }));
  expect(screen.getByText(/기존 일정 담당자입니다/)).toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("일정 이름"), { target: { value: "예전 일정 수정" } });
  fireEvent.click(screen.getByRole("button", { name: "수정 저장" }));
  expect(JSON.parse(localStorage.getItem(storageKey))[0]).toMatchObject({ person: "김기존", employeeId: 20, title: "예전 일정 수정" });
  await act(async () => { expect(fetch).toHaveBeenCalled(); });
});


test("전체 목록은 여러 날 일정의 전체 날짜와 시간을 표시하고 원본을 편집한다", () => {
  const timed = makeSchedule({ id: "night", title: "야간 점검", date: "2026-12-04", time: "23:30", endDate: "2026-12-05", endTime: "00:30" });
  const allDay = makeSchedule({ id: "leave", title: "종일 휴가", date: "2026-11-30", endDate: "2026-12-02", isAllDay: true });
  const items = [timed, allDay];
  const original = JSON.stringify(items);
  const onEdit = jest.fn();
  render(<ScheduleListModal items={items} totalCount={2} onEdit={onEdit} onClose={() => {}} />);
  expect(screen.getByRole("button", { name: "야간 점검 일정 수정" })).toHaveTextContent("2026.12.04 23:30 ~ 2026.12.05 00:30");
  expect(screen.getByRole("button", { name: "종일 휴가 일정 수정" })).toHaveTextContent("2026.11.30 ~ 2026.12.02 · 종일");
  fireEvent.click(screen.getByRole("button", { name: "야간 점검 일정 수정" }));
  expect(onEdit.mock.calls[0][0]).toBe(timed);
  expect(JSON.stringify(items)).toBe(original);
});

test("전체 반복 목록은 마지막 요일과 휴일 이동을 반영한 다음 회차를 기준일과 구분한다", () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-11-16T12:00:00"));
  const monthly = makeSchedule({ id: "last-weekday", title: "월간 정리", date: "2026-11-18", repeatType: "monthly", monthlyRule: "weekday", monthlyOrdinal: -1, monthlyWeekday: 3 });
  const weekly = makeSchedule({ id: "holiday-shift", title: "휴일 이동", date: "2026-11-21", repeatType: "weekly", holidayRule: "nextWorkday", repeatEndType: "count", repeatCount: 1 });
  render(<ScheduleListModal items={[monthly, weekly]} totalCount={2} holidayDates={{ "2026-11-23": "검증 휴일" }} onClose={() => {}} />);
  const monthlyRow = screen.getByRole("button", { name: "월간 정리 일정 수정" });
  expect(monthlyRow).toHaveTextContent("다음 회차 · 2026.11.25");
  expect(monthlyRow).toHaveTextContent("반복 기준일 · 2026.11.18");
  const weeklyRow = screen.getByRole("button", { name: "휴일 이동 일정 수정" });
  expect(weeklyRow).toHaveTextContent("다음 회차 · 2026.11.24");
  expect(weeklyRow).toHaveTextContent("반복 기준일 · 2026.11.21");
});

test("남은 회차가 없는 반복은 기준 날짜를 다음 회차로 표시하지 않는다", () => {
  jest.useFakeTimers("modern");
  jest.setSystemTime(new Date("2026-11-16T12:00:00"));
  const item = makeSchedule({ title: "종료된 반복", date: "2026-11-01", repeatType: "weekly", repeatEndType: "count", repeatCount: 1 });
  render(<ScheduleListModal items={[item]} totalCount={1} onClose={() => {}} />);
  const row = screen.getByRole("button", { name: "종료된 반복 일정 수정" });
  expect(row).toHaveTextContent("남은 회차 없음 · 기준일 · 2026.11.01");
  expect(row).not.toHaveTextContent("다음 회차");
});

test("전체 기간 시간 행은 야간 종료 시각을 표시하고 날짜별 시간 행은 분할을 유지한다", () => {
  const item = makeSchedule({ date: "2026-12-04", time: "23:30", endDate: "2026-12-05", endTime: "00:30" });
  const { rerender } = render(<ScheduleTimeRow item={item} wholePeriod />);
  expect(screen.getByText("23:30~00:30")).toBeInTheDocument();
  rerender(<ScheduleTimeRow item={item} />);
  expect(screen.getByText("23:30~24:00")).toBeInTheDocument();
});
