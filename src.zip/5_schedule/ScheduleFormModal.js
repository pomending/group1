/* [파일 안내] 일정 입력·전체 목록·공통 모달
 * 읽는 순서: ScheduleFormModal → 날짜·시간/추가 설정 부품 → ScheduleListModal → ScheduleModal
 * 입력 흐름: input의 name/value → onChange → Manager.updateForm → 새 form 전달
 * 제출 흐름: onSubmit → Manager.addSchedule에서 검증·저장
 * 목록 항목 선택: onEdit(item) → Manager가 수정 폼을 열어 저장값을 표시합니다.
 */

/* 폼·목록은 공통 ScheduleModal을 사용합니다. 날짜·시간과 추가 설정은 이 파일의 전용 부품으로 분리합니다. */
import React, { useLayoutEffect, useRef, useState } from "react";
import { ScheduleAgendaItem, ScheduleFavorite, ScheduleAttendees, ScheduleVisibility, ScheduleStatus } from "./ScheduleItemParts";
import {
  compareSchedules,
  getScheduleListDate,
  getTodayKey,

  getRepeatLabel,
  getRepeatEndLabel,
  getRepeatSummary,
  getScheduleDurationFields,
  getScheduleFormError,
  scheduleCategories,
  scheduleScopes,
  scheduleStatuses,
  normalizeAttendees,
  normalizeStatus,
} from "./scheduleData";

/* 입력값은 부모의 form state를 표시하며, 변경·저장은 부모 콜백으로 전달합니다. */
// 입력값·저장은 부모가 관리하고, 공통 모달은 배경 클릭·제목·닫기 버튼을 담당합니다.
// isOccurrence이면 반복 중 특정 날짜만 수정하므로 반복 선택창을 숨기고 해당 날짜의 정보만 바꿉니다.
export default function ScheduleFormModal({
  form,
  returnFocusRef,
  saving = false,
  canCreatePrivate = true,
  employees = [],
  originalAssignee = null,
  onSelectAssignee,
  projectSuggestions = [],
  projectWarning = "",
  onToggleAttendee,
  onToggleAttendeeEmployee,
  error,
  onChange,
  onSubmit,
  onClose,
  onDelete,
  onCopy,
  isEditing,
  isOccurrence,
  isRestoredDraft = false,
}) {
  const initialFormRef = useRef(JSON.stringify(form));
  const formRef = useRef(null);
  const [nativeError, setNativeError] = useState(null);
  const validation = error ? getScheduleFormError(form) : null;
  const fieldError = validation?.message === error ? validation : nativeError;
  useLayoutEffect(() => { setNativeError(null); }, [form]);
  useLayoutEffect(() => {
    const name = fieldError?.field === "repeatInterval" ? "repeatPreset" : fieldError?.field;
    const details = name && formRef.current?.elements.namedItem(name)?.closest("details");
    if (details) details.open = true;
  }, [fieldError]);
  function canDiscardChanges() {
    const unchanged = JSON.stringify(form) === initialFormRef.current;
    if (!isRestoredDraft && unchanged) return true;
    return window.confirm("작성 중인 변경 내용을 저장하지 않고 닫을까요?");
  }
  // 입력이 처음 값과 다르거나 임시 보관을 복구한 폼이면 폐기를 확인합니다. 복구한 내용은 변경하지 않았어도 확인합니다.
  // 실제 저장·삭제와 폼 닫기는 부모 콜백에서 처리합니다.
  function requestClose() {
    if (saving) return;
    if (!canDiscardChanges()) return;
    onClose();
  }
  // 문구를 먼저 정해 두면 아래 JSX에서는 화면 배치에 집중할 수 있습니다.
  // 조건 ? A : B는 조건이 참이면 A, 아니면 B를 고릅니다. 간단한 문구 선택에만 사용합니다.
  const title = isEditing ? "일정 수정" : "새 일정 등록";
  const description = isEditing ? "일정 정보를 수정하고 저장하세요." : "일정 종류를 선택해 정보를 입력하세요.";
  const submitText = isEditing ? "수정 저장" : "일정 저장";

  const selectedAttendees = normalizeAttendees(form.attendees);
  const selectedStaff = form.attendeeEmployees || [];
  const attendeeDepartments = [];
  for (const employee of employees) {
    if (employee.status !== "재직") continue;
    const department = employee.department || "부서 미지정";
    let group = attendeeDepartments.find(group => group.department === department);
    if (!group) {
      group = { department, staff: [] };
      attendeeDepartments.push(group);
    }
    group.staff.push(employee);
  }
  const unavailableAttendees = selectedStaff.filter(person =>
    !employees.some(employee => employee.id === person.id && employee.status === "재직")
  );
  const assigneeName = form.person.trim();
  const selectedEmployee = employees.find(employee =>
    employee.id === form.employeeId && employee.name.trim() === assigneeName
  );
  // 성만 입력했을 때는 결과를 표시하지 않습니다. 동명이인은 모두 보여 ID로 구분합니다.
  const matchingEmployees = assigneeName && !selectedEmployee
    ? employees.filter(employee => employee.status === "재직" && employee.name.trim() === assigneeName)
    : [];
  const isUnlinkedExistingAssignee = Boolean(
    isEditing && !selectedEmployee && originalAssignee &&
    originalAssignee.person?.trim() === assigneeName &&
    (originalAssignee.employeeId ?? null) === (form.employeeId ?? null)
  );
  // 선택값 하나만 전달합니다. Manager.updateForm이 관련 업무 입력값도 한 번의 상태 갱신으로 비웁니다.
  function selectScope(scope) {
    if (form.scope === scope) return;
    onChange({ target: { name: "scope", value: scope } });
  }
  // 분류 변경 시 필요한 프로젝트명·참석자 초기화도 Manager에서 함께 처리합니다.
  function selectCategory(category) {
    onChange({ target: { name: "category", value: category } });
  }

  return (
    <ScheduleModal
      id="sm-form-title"
      title={title}
      description={description}
      onClose={requestClose}
      returnFocusRef={returnFocusRef}
    >
      {/* 이름·프로젝트명은 사전에 없는 고유명사가 많으므로 브라우저 맞춤법 검사를 끕니다.
          spellCheck=false는 입력 내용을 바꾸지 않고 맞춤법 표시만 제어하며 자식 입력창에 상속됩니다.
          한글을 조합하는 동안 운영체제가 표시하는 입력기 밑줄과는 별개의 브라우저 설정입니다. */}
      {saving && <p className="sm-form-note" role="status">일정을 저장하는 중입니다.</p>}
      <form ref={formRef} className="sm-form" aria-labelledby="sm-form-title" onSubmit={onSubmit} spellCheck={false} autoCorrect="off" inert={saving || undefined}
        onInvalid={event => setNativeError(getScheduleFormError(form) || { field: event.target.name, message: event.target.validationMessage })}>
        {/* 입력값은 부모 form에서 받으며 onChange로 갱신합니다. 브라우저 입력 제한과 별개로 저장 시에도 검증합니다. */}
        {/* 각 입력창을 직접 작성해 name과 form의 속성이 어떻게 연결되는지 바로 볼 수 있습니다.
            예: name="person" 입력 → 부모의 onChange → form.person 변경 → value에 다시 표시. */}
        <div className="sm-category-picker sm-form-wide">
          <span className="sm-category-label">일정 종류</span>
          <div className="sm-category-tabs" role="group" aria-label="일정 종류" {...fieldErrorProps(fieldError, "scope")}>
            {scheduleScopes.map(scope => (
              <button type="button" key={scope}
                disabled={scope === "개인 일정용" && !canCreatePrivate}
                aria-pressed={form.scope === scope}
                className={form.scope === scope ? "sm-category-tab active" : "sm-category-tab"}
                onClick={() => selectScope(scope)}>
                {scope}
              </button>
            ))}
          </div>
        </div>
        <ScheduleFieldError error={fieldError} fields={["scope"]} />
        {!canCreatePrivate && <p className="sm-form-note sm-form-wide">개인 일정과 개인 표시는 로그인 후 사용할 수 있습니다.</p>}
        <label className="sm-form-wide">
          일정 이름
          <input name="title" value={form.title} onChange={onChange} autoFocus required maxLength={80} {...fieldErrorProps(fieldError, "title")} />
        </label>
        <ScheduleFieldError error={fieldError} fields={["title"]} />
        {/* 날짜 입력의 value는 YYYY-MM-DD, 시간은 HH:mm 형식입니다.
              반복 일정에서는 이 날짜가 기준일이고 시간은 각 발생 항목에 그대로 복사됩니다. */}
        {/* 날짜는 한 줄 전체에 두고, 시간은 두 칸으로 묶어 기본 입력 행을 맞춥니다. */}
        <ScheduleDateTimeFields form={form} onChange={onChange} fieldError={fieldError} />
        {form.scope === "업무용" && <div className="sm-category-picker sm-form-wide">
          <span className="sm-category-label">업무 분류</span>
          <div className="sm-category-tabs" role="group" aria-label="일정 분류" {...fieldErrorProps(fieldError, "category")}>
            {scheduleCategories.map(category => (
              <button type="button" key={category}
                aria-pressed={form.category === category}
                className={form.category === category ? "sm-category-tab active" : "sm-category-tab"}
                onClick={() => selectCategory(category)}>
                {category}
              </button>
            ))}
          </div>
        </div>}
        <ScheduleFieldError error={fieldError} fields={["category"]} />
        {form.scope === "업무용" && form.category === "업무" && (
          <div className="sm-project-fields sm-form-wide">
            <label>프로젝트
              <input list="sm-project-suggestions" name="project" value={form.project} onChange={onChange} autoComplete="off"
                placeholder="연결할 프로젝트명 (선택)" maxLength={60} {...fieldErrorProps(fieldError, "project")} />
            </label>
            <datalist id="sm-project-suggestions">
              {projectSuggestions.map(name => <option key={name} value={name} />)}
            </datalist>
          </div>
        )}
        <ScheduleFieldError error={fieldError} fields={["project"]} />
        {projectWarning && <div className="sm-storage-warning sm-form-wide" role="status" aria-label="프로젝트 연결 안내">
          {projectWarning}
          <button type="button" className="sm-secondary-btn" onClick={() => onChange({ target: { name: "project", value: "" } })}>프로젝트 다시 선택</button>
          <p>버튼을 누르면 입력창의 연결을 비웁니다. 새 프로젝트를 선택하고 저장해야 반영됩니다.</p>
        </div>}
        {form.scope === "업무용" && <div className="sm-assignee-field sm-form-wide">
          <label htmlFor="sm-assignee">담당자</label>
          <input id="sm-assignee" name="person" value={form.person} autoComplete="off"
            onChange={onChange} placeholder="직원 이름을 정확히 입력하세요" maxLength={30} required {...fieldErrorProps(fieldError, "person")} />
          {selectedEmployee ? (
            <div className="sm-assignee-selected">
              <strong>{selectedEmployee.name} · 선택됨</strong>
              <span>{selectedEmployee.department} · {selectedEmployee.position} · {selectedEmployee.status}</span>
              {selectedEmployee.status !== "재직" && <small>기존 일정 담당자입니다. 새 담당자로는 선택할 수 없습니다.</small>}
            </div>
          ) : matchingEmployees.length > 0 ? (
            <div className="sm-assignee-matches" role="group" aria-label="담당자 검색 결과">
              <p className="sm-form-note">일치하는 직원입니다. 아래 정보를 눌러 선택하세요.</p>
              {matchingEmployees.map(employee => (
                <button type="button" key={employee.id} className="sm-assignee-match"
                  onClick={() => onSelectAssignee(employee)}>
                  <strong>{employee.name}</strong>
                  <span>{employee.department} · {employee.position} · {employee.status}</span>
                </button>
              ))}
            </div>
          ) : isUnlinkedExistingAssignee ? (
            <p className="sm-form-note">이전 일정의 담당자 이름을 유지합니다. 새 담당자로 바꾸려면 재직 직원을 검색해 선택하세요.</p>
          ) : assigneeName ? (
            <p className="sm-form-note">정확히 일치하는 재직 직원이 없습니다. HR 직원 이름을 확인해 주세요.</p>
          ) : (
            <p className="sm-form-note">부서에 관계없이 재직 중인 직원만 선택할 수 있습니다.</p>
          )}
        </div>}
        <ScheduleFieldError error={fieldError} fields={["person"]} />
        {/* 회의 분류를 선택하면 참석자 선택을 표시합니다. */}
        {form.scope === "업무용" && form.category === "회의" && (
          <fieldset className="sm-team-options sm-form-wide sm-meeting-attendees">
            <legend>참석자 추가</legend>
            <p className="sm-form-note">부서별로 재직 직원을 선택하세요.</p>
            {attendeeDepartments.map(({ department, staff }) => (
              <fieldset className="sm-team-options" key={department}>
                <legend>{department} · {staff.length}명</legend>
                {staff.map(employee => (
                  <label key={employee.id}>
                    <input type="checkbox" checked={selectedStaff.some(person => person.id === employee.id)}
                      onChange={() => onToggleAttendeeEmployee(employee)} />
                    {employee.name}{employee.position ? " · " + employee.position : ""}
                  </label>
                ))}
              </fieldset>
            ))}
            {(selectedAttendees.length > 0 || unavailableAttendees.length > 0) && <p className="sm-form-note">기존 참석자</p>}
            {selectedAttendees.map(name => (
              <label key={name}>
                <input type="checkbox" checked onChange={() => onToggleAttendee(name)} />
                {name}
              </label>
            ))}
            {unavailableAttendees.map(employee => (
              <label key={employee.id}>
                <input type="checkbox" checked onChange={() => onToggleAttendeeEmployee(employee)} />
                {employee.name} · 기존 직원
              </label>
            ))}
            {attendeeDepartments.length === 0 && <p className="sm-form-note">선택할 수 있는 재직 직원이 없습니다.</p>}
          </fieldset>
        )}
        {form.scope === "업무용" && <label className="sm-form-wide">일정 상태
          <select name="status" className={`sm-status-select ${form.status}`} value={form.status} onChange={onChange} {...fieldErrorProps(fieldError, "status")}>
            {scheduleStatuses.map(({ value, label }) => <option key={value} value={value}>{label}</option>)}
          </select>
        </label>}
        <ScheduleFieldError error={fieldError} fields={["status", "attendees"]} />
        {/* 상세 내용은 최대 3,000자이며 줄바꿈을 저장합니다. 표시 시 CSS로 줄바꿈을 유지합니다. */}
        <label className="sm-form-wide">
          상세 내용
          <textarea
            name="description"
            value={form.description}
            onChange={onChange}
            rows={5}
            maxLength={3000}
            {...fieldErrorProps(fieldError, "description")}
            placeholder="작업 내용, 준비 사항, 전달할 메모 등을 입력하세요."
          />
          <span className="sm-form-note">
            {form.description.length} / 3,000자
          </span>
        </label>
        <ScheduleFieldError error={fieldError} fields={["description"]} />
        {/* 기본 입력 뒤에 선택 설정을 둡니다. 공유 구분·종일·알림은 신규와 수정에서 변경할 수 있습니다. */}
        <ScheduleExtraSettings form={form} onChange={onChange} isOccurrence={isOccurrence} fieldError={fieldError} canCreatePrivate={canCreatePrivate} />
        {!isOccurrence && form.repeatType !== "none" && <p className="sm-repeat-summary sm-form-wide" aria-label="반복 설정 요약">{getRepeatSummary(form)}</p>}
        {isOccurrence && <p className="sm-form-note sm-form-wide">선택한 날짜의 일정만 수정합니다. 다른 반복 일정은 유지됩니다.</p>}
        {/* 취소는 type=button이라 제출하지 않습니다. 저장은 submit이라 form의 onSubmit을 실행합니다.
              부모가 preventDefault로 기본 페이지 이동을 막고 state에 내용을 반영합니다. */}
        <div className="sm-form-actions">
          {isEditing && onCopy && <button type="button" className="sm-secondary-btn" onClick={() => { if (canDiscardChanges()) onCopy(); }}>일정 복사</button>}
          {isEditing && <button type="button" className="sm-delete-btn" onClick={onDelete}>일정 삭제</button>}
          <button type="button" className="sm-cancel" onClick={requestClose}>
            취소
          </button>
          <button type="submit" className="sm-btn">
            {submitText}
          </button>
        </div>
        {error && <p className="sm-form-error sm-form-wide" role="alert">{error}</p>}
      </form>
    </ScheduleModal>
  );
}

// 날짜·시간 입력 전용 부품입니다. 상태는 부모 form을 사용하고 변경은 그대로 onChange로 전달합니다.
function ScheduleDateTimeFields({ form, onChange, fieldError }) {
  // 다음 날 이후 종료는 오전 시간도 허용합니다. 같은 날짜만 최소 시각을 제한합니다.
  const endsOnLaterDate = form.repeatType === "none" && form.endDate > form.date;
  return (
  <div className="sm-date-time-fields sm-form-wide">
    <label>
      날짜
      <input type="date" name="date" value={form.date} onChange={onChange} required {...fieldErrorProps(fieldError, "date")} />
    </label>
    {/* 종일 일정은 시간 입력을 숨기며, 저장된 기본 시간은 폼 값에 계속 보관합니다. */}
    {!form.isAllDay && <>
      <label>시작 시간
        <input type="time" name="time" value={form.time} onChange={onChange} required {...fieldErrorProps(fieldError, "time")} />
      </label>
      <label>종료 시간
        <input type="time" name="endTime" value={form.endTime} onChange={onChange} min={endsOnLaterDate ? undefined : form.time} required {...fieldErrorProps(fieldError, "endTime")} />
      </label>
      <div className="sm-duration-options" role="group" aria-label="종료 시간 빠른 설정">
        <span>시작부터</span>
        {[[30, "30분"], [60, "1시간"], [120, "2시간"]].map(([minutes, label]) => (
          <button type="button" key={minutes} className="sm-secondary-btn"
            disabled={!getScheduleDurationFields(form, minutes)}
            title="시작 시간 기준으로 종료 날짜와 시간을 변경합니다. 반복 일정은 자정을 넘길 수 없습니다."
            onClick={() => onChange({ target: { name: "durationMinutes", value: minutes } })}>{label}</button>
        ))}
      </div>
    </>}
    <ScheduleFieldError error={fieldError} fields={["date", "time", "endTime"]} />
  </div>
  );
}

// 종일·기간·알림·공유 구분·반복 규칙을 한 구역에서 관리합니다. 별도 상태를 복제하지 않습니다.
function ScheduleExtraSettings({ form, onChange, isOccurrence, fieldError, canCreatePrivate }) {
  const repeatValue = form.repeatType + ":" + form.repeatInterval;
  // 사용자 지정 간격을 수정 없이 저장해도 기존 규칙이 바뀌지 않도록 선택지에 남깁니다.
  const commonRepeat = ["none:1", "weekly:1", "weekly:2", "monthly:1"].includes(repeatValue);
  return (
  <details className="sm-extra-settings sm-form-wide" aria-label="일정 추가 설정">
    <summary>추가 설정 · 공유 구분·반복·알림</summary>
    <div className="sm-extra-fields">
      {/* 종일 선택 시 위의 시작·종료 시간 입력란은 숨기지만 기존 값은 저장용으로 유지합니다. */}
      <label className="sm-form-check">종일 일정
        <span className="sm-form-check-control"><input type="checkbox" name="isAllDay" checked={Boolean(form.isAllDay)} onChange={onChange} {...fieldErrorProps(fieldError, "isAllDay")} /></span>
      </label>
      {/* 종료 날짜는 반복 없는 일정에서만 열어 여러 날 범위를 지정할 수 있습니다. */}
      {form.repeatType === "none" && <label>종료 날짜 (여러 날 일정)
        <input type="date" name="endDate" value={form.endDate || ""} min={form.date} onChange={onChange} {...fieldErrorProps(fieldError, "endDate")} />
      </label>}
      {/* 선택한 분 단위는 일정 시작 전에 화면 알림을 표시하는 데 사용합니다. */}
      <label>알림
        <select name="reminderMinutes" value={form.reminderMinutes || 0} onChange={onChange} {...fieldErrorProps(fieldError, "reminderMinutes")}>
          <option value={0}>알림 없음</option><option value={10}>10분 전</option><option value={30}>30분 전</option><option value={1440}>하루 전</option>
        </select>
      </label>
      <label>공유 구분
        <select name="visibility" value={form.scope === "개인 일정용" ? "private" : form.visibility}
          disabled={form.scope === "개인 일정용"} onChange={onChange} {...fieldErrorProps(fieldError, "visibility")}>
          <option value="shared">회사 공유</option><option value="private" disabled={!canCreatePrivate}>개인 표시</option>
        </select>
      </label>
      {!isOccurrence && <label className={form.repeatType === "none" ? "sm-extra-field-wide" : ""}>반복 설정
        <select name="repeatPreset" value={repeatValue} onChange={onChange} {...fieldErrorProps(fieldError, "repeatInterval")}>
          <option value="none:1">반복 없음</option><option value="weekly:1">매주</option>
          <option value="weekly:2">격주</option><option value="monthly:1">매월</option>
          {!commonRepeat && <option value={repeatValue}>기존 설정 · {getRepeatLabel(form)}</option>}
        </select>
      </label>}
      {/* 휴일 처리 규칙은 반복 일정에서만 선택할 수 있습니다. */}
      {!isOccurrence && form.repeatType !== "none" && <>
        <label>반복 종료
          <select name="repeatEndType" value={form.repeatEndType || "none"} onChange={onChange} {...fieldErrorProps(fieldError, "repeatEndType")}>
            <option value="none">종료일 없음</option>
            <option value="until">날짜 지정</option>
            <option value="count">횟수 지정</option>
          </select>
        </label>
        {form.repeatEndType === "until" && <label>반복 종료 날짜
          <input type="date" name="repeatEndDate" value={form.repeatEndDate || ""} min={form.date} onChange={onChange} required {...fieldErrorProps(fieldError, "repeatEndDate")} />
        </label>}
        {form.repeatEndType === "count" && <label>반복 횟수
          <input type="number" name="repeatCount" min={1} max={1000} step={1} value={form.repeatCount} onChange={onChange} required {...fieldErrorProps(fieldError, "repeatCount")} />
        </label>}
      </>}
      {form.repeatType !== "none" && <label>주말·공휴일 처리
        <select name="holidayRule" value={form.holidayRule || "keep"} onChange={onChange} {...fieldErrorProps(fieldError, "holidayRule")}>
          <option value="keep">기준일에 진행</option><option value="skip">건너뛰기</option><option value="nextWorkday">다음 근무일로 이동</option>
        </select>
      </label>}
      {form.repeatType === "monthly" && (
        <>
          <label>매월 기준
            <select name="monthlyRule" value={form.monthlyRule} onChange={onChange} {...fieldErrorProps(fieldError, "monthlyRule")}>
              <option value="date">같은 날짜</option>
              <option value="weekday">몇째 주 요일</option>
            </select>
          </label>
          {form.monthlyRule === "weekday" && (
            <>
              <label>주차
                <select name="monthlyOrdinal" value={form.monthlyOrdinal} onChange={onChange} {...fieldErrorProps(fieldError, "monthlyOrdinal")}>
                  <option value={1}>첫째 주</option>
                  <option value={2}>둘째 주</option>
                  <option value={3}>셋째 주</option>
                  <option value={4}>넷째 주</option>
                  <option value={-1}>마지막 주</option>
                </select>
              </label>
              <label>요일
                <select name="monthlyWeekday" value={form.monthlyWeekday} onChange={onChange} {...fieldErrorProps(fieldError, "monthlyWeekday")}>
                  <option value={1}>월요일</option>
                  <option value={2}>화요일</option>
                  <option value={3}>수요일</option>
                  <option value={4}>목요일</option>
                  <option value={5}>금요일</option>
                </select>
              </label>
            </>
          )}
        </>
      )}
    </div>
    <ScheduleFieldError error={fieldError} fields={["endDate", "repeatInterval", "repeatEndDate", "repeatCount", "isAllDay", "reminderMinutes", "visibility", "repeatEndType", "holidayRule", "monthlyRule", "monthlyOrdinal", "monthlyWeekday"]} />
    <p className="sm-form-note">개인 일정과 개인 표시는 작성 계정에서만 확인할 수 있습니다.</p>
    {!canCreatePrivate && <p className="sm-form-note">개인 일정을 등록하려면 로그인해 주세요.</p>}
    {form.repeatType !== "none" && form.repeatEndType === "count" && <p className="sm-form-note">횟수는 규칙상 발생 횟수입니다. 휴일로 건너뛰거나 삭제한 회차도 포함합니다.</p>}
    {form.repeatType !== "none" && form.repeatEndType === "until" && <p className="sm-form-note">이동 전 규칙 날짜가 종료일 이내인 회차까지 포함합니다. 휴일 이동 결과는 종료일을 넘을 수 있습니다.</p>}
    {form.repeatType === "monthly" && form.monthlyRule === "weekday" && (
      <p className="sm-form-note">주말·공휴일 일정은 위의 휴일 규칙에 따라 건너뛰거나 다음 근무일로 옮길 수 있습니다.</p>
    )}
  </details>
  );
}

// 오류가 난 입력만 aria-invalid로 표시하고, 아래 오류 문구의 ID를 aria-describedby로 연결합니다.
function fieldErrorProps(error, field) {
  return error?.field === field ? { "aria-invalid": true, "aria-describedby": `sm-error-${field}` } : {};
}

// 담당하는 필드의 첫 오류만 가까운 위치에 표시합니다. 하단의 저장·충돌 오류 안내와는 별개입니다.
function ScheduleFieldError({ error, fields }) {
  return error && fields.includes(error.field)
    ? <p className="sm-field-error sm-form-wide" id={`sm-error-${error.field}`}>{error.message}</p> : null;
}

// 전체 목록은 원본 반복 규칙을, 날짜 목록은 부모가 펼친 해당 날짜의 발생 항목을 받습니다.
// 수정 버튼은 전달받은 item을 그대로 넘겨 원본 전체와 한 회차의 수정 범위를 유지합니다.
// 정렬·진행 상태 필터·페이지는 팝업 내부 표시 상태이며, 저장된 일정 배열은 변경하지 않습니다.
// totalCount는 전체 원본 건수이고 items는 현재 목록 범위입니다. 상태 필터 후의 페이지 건수는 별도로 계산합니다.
export function ScheduleListModal({
  items,
  holidayDates = {},
  filterDate,
  totalCount,
  hasActiveFilter = false,
  onClearDateFilter,
  onEdit,
  onClose,
  onToggleFavorite,
}) {
  const [sortOrder, setSortOrder] = useState("date");
  const [statusFilter, setStatusFilter] = useState("all");
  // 개인 일정에는 업무 진행 상태가 없으므로 예정·완료 필터에서 제외합니다.
  const matchingItems = statusFilter === "all" ? items
    : items.filter(item => {
      if (item.scope === "개인 일정용" || item.isQuotationExpiry) return false;
      if (item.isTaskDeadline) {
        const taskStatus = item.taskProgress === "완료" ? "completed" : "pending";
        return taskStatus === statusFilter;
      }
      return normalizeStatus(item.status) === statusFilter;
    });
  const [page, setPage] = useState(1);
  const listContentRef = useRef(null);
  const pageSize = 20;
  const pageCount = Math.max(1, Math.ceil(matchingItems.length / pageSize));
  // 삭제로 페이지가 줄어들면 마지막 유효 페이지를 표시합니다. 날짜·정렬·진행 상태 필터 변경은 첫 페이지로 돌아갑니다.
  const currentPage = Math.min(page, pageCount);
  useLayoutEffect(() => { setPage(current => Math.min(current, pageCount)); }, [pageCount]);
  useLayoutEffect(() => { setPage(1); }, [filterDate, statusFilter]);
  useLayoutEffect(() => { if (listContentRef.current) listContentRef.current.scrollTop = 0; }, [currentPage, sortOrder, filterDate, statusFilter]);
  const todayKey = getTodayKey();
  const createListEntry = (item) => {
    const dateInfo = getScheduleListDate(item, todayKey, holidayDates, filterDate ? null : Date.now());

    // 표시 문구를 여기서 완성해 JSX에서는 배치만 담당하도록 합니다.
    const category = item.category === "프로젝트" ? "업무" : item.category || "업무";
    const detailLabel = item.scope === "개인 일정용"
      ? "개인 일정용"
      : [category, item.project || item.person].filter(Boolean).join(" · ");

    return { item, ...dateInfo, detailLabel };

  };
  // 날짜 계산 결과를 항목에 함께 담아 정렬과 화면 표시에서 재사용합니다.
  const sortedItems = matchingItems
    .map(createListEntry)
    .sort((left, right) => {
      const byDate = left.displayDate.localeCompare(right.displayDate) || compareSchedules(left.item, right.item);
      if (sortOrder === "title") return left.item.title.localeCompare(right.item.title, "ko") || byDate;
      if (sortOrder === "person") {
        const first = left.item.person || "";
        const second = right.item.person || "";
        return Number(!first) - Number(!second) || first.localeCompare(second, "ko") || byDate;
      }
      return byDate;
    });
  let title = "전체 일정";
  let description = `등록된 일정 ${totalCount}건`;
  let emptyMessage = "등록된 일정이 없습니다. 목록을 닫고 일정 등록 버튼으로 추가해 보세요.";
  if (filterDate) {
    title = `${filterDate.replaceAll("-", ".")} 일정`;
    description = `${items.length}건 · 직접 등록 전체 ${totalCount}건`;
    emptyMessage = "선택한 날짜에 일정이 없습니다. 목록을 닫고 일정 등록 버튼으로 추가해 보세요.";
    if (hasActiveFilter) emptyMessage = "선택한 날짜에 조건과 일치하는 일정이 없습니다. 검색어나 필터를 변경해 주세요.";
  }
  // 원래 목록이 비었다면 상태 필터 탓으로 안내하지 않습니다. 상태로 걸러진 경우에만 해제를 제안합니다.
  const isStatusEmpty = items.length > 0 && statusFilter !== "all" && matchingItems.length === 0;
  return (
    <ScheduleModal
      id="sm-list-title"
      className="sm-list-modal"
      title={title}
      description={description}
      onClose={onClose}
      headerExtra={
        filterDate && (
          <button
            type="button"
            className="sm-list-all-btn"
            onClick={onClearDateFilter}
          >
            전체 일정 보기
          </button>
        )
      }
    >
      <div className="sm-list-content" ref={listContentRef}>
        {/* 정렬·상태·표시 건수는 한 영역에 두되 모두 현재 팝업의 표시만 바꿉니다. */}
        <div className="sm-list-toolbar" role="group" aria-label="일정 목록 도구">
        <label className="sm-list-sort">목록 정렬
          <select value={sortOrder} onChange={event => { setSortOrder(event.target.value); setPage(1); }}>
            <option value="date">날짜순</option><option value="title">이름순</option><option value="person">담당자순</option>
          </select>
        </label>
        <label className="sm-list-sort">목록 진행 상태
          <select value={statusFilter} onChange={event => setStatusFilter(event.target.value)}>
            <option value="all">진행 상태 전체</option><option value="pending">예정 업무</option><option value="completed">완료 업무</option>
          </select>
        </label>
        <span className="sm-list-summary" role="status" aria-label="목록 표시 건수">표시 {matchingItems.length}건</span>
        </div>
        {statusFilter !== "all" && <p className="sm-form-note">진행 상태는 업무 일정과 세부 작업에 적용됩니다. 개인 일정과 견적은 전체에서 확인하세요.</p>}
        {sortedItems.length ? (
          sortedItems.slice((currentPage - 1) * pageSize, currentPage * pageSize).map(
            ({ item, dateLabel, basisLabel, detailLabel }) => (
              item.isProjectMilestone
              ? <ScheduleAgendaItem key={item.id} item={item} />
              :

              <article className="sm-list-item" key={item.id}>
                {/* 목록 제목은 item을 그대로 전달해 수정 창을 엽니다. 별 버튼은 즐겨찾기만 바꿉니다. */}
                <button
                  type="button"
                  className="sm-list-item-info"
                  aria-label={`${item.title} 일정 수정`}
                  onClick={() => onEdit(item)}
                >
                  <span className="sm-list-date">
                    {dateLabel}
                  </span>
                  <strong>{item.title}</strong>
                  {basisLabel && <small>{basisLabel}</small>}
                  <ScheduleVisibility visibility={item.visibility} />
                  {!item.isProjectMilestone && item.scope !== "개인 일정용" && <ScheduleStatus status={item.status} />}
                  {item.repeatType !== "none" && (
                    <small>{getRepeatLabel(item)} · {getRepeatEndLabel(item)}</small>
                  )}
                  <small>{detailLabel}</small>
                  <ScheduleAttendees item={item} />
                </button>
                <ScheduleFavorite item={item} onToggleFavorite={onToggleFavorite} />
              </article>
            )
          )
        ) : (
          <div className="sm-empty">
            <p>{isStatusEmpty ? "선택한 진행 상태에 해당하는 업무 일정이 없습니다." : emptyMessage}</p>
            {isStatusEmpty && <button type="button" className="sm-list-all-btn" onClick={() => setStatusFilter("all")}>진행 상태 전체 보기</button>}
          </div>
        )}
        {matchingItems.length > 0 && <nav className="sm-list-pagination" aria-label="일정 목록 페이지">
          <span role="status">전체 {matchingItems.length}건 · {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, matchingItems.length)}건</span>
          {pageCount > 1 && <>
            <button type="button" className="sm-list-all-btn" disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)}>이전 페이지</button>
            <span>{currentPage} / {pageCount}</span>
            <button type="button" className="sm-list-all-btn" disabled={currentPage === pageCount} onClick={() => setPage(currentPage + 1)}>다음 페이지</button>
          </>}
        </nav>}
      </div>
    </ScheduleModal>
  );
}

function getModalFocusTargets(dialog) {
  return [...dialog.querySelectorAll(
    'button, input, select, textarea, a[href], summary, [tabindex]'
  )].filter(element => {
    if (element.matches(':disabled, input[type="hidden"]') || element.tabIndex < 0) return false;
    for (let parent = element; parent && parent !== dialog; parent = parent.parentElement) {
      const style = window.getComputedStyle(parent);
      if (parent.hidden || style.display === "none" || style.visibility === "hidden") return false;
      // 접힌 추가 설정에서는 summary만 키보드 이동 대상으로 남깁니다.
      if (parent.tagName === "DETAILS" && !parent.open && !parent.querySelector("summary")?.contains(element)) return false;
    }
    return true;
  });
}

/* 모달은 제목·닫기·키보드 이동을 제공하고, 폼이나 목록을 children으로 표시합니다. */
function ScheduleModal({
  id,
  title,
  description,
  onClose,
  children,
  headerExtra,
  className = "",
  returnFocusRef,
}) {
  const dialogRef = useRef(null);
  // 자동 초점이 적용되기 전, 팝업을 연 버튼을 기억합니다.
  const openerRef = useRef(document.activeElement);

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    const opener = returnFocusRef?.current || openerRef.current;
    // 등록·수정 폼의 기존 autoFocus는 유지하고, 목록은 첫 조작 요소에 초점을 둡니다.
    if (!dialog.contains(document.activeElement)) (getModalFocusTargets(dialogRef.current)[0] || dialog).focus();
    return () => {
      if (opener?.isConnected) opener.focus();
      else document.querySelector('.schedule-app button')?.focus();
    };
  }, [returnFocusRef]);

  function handleKeyDown(event) {
    // 목록 위에 수정창이 열려 있으면 가장 위의 팝업만 키보드 입력을 처리합니다.
    const dialogs = document.querySelectorAll('.sm-modal[role="dialog"]');
    if (dialogs[dialogs.length - 1] !== dialogRef.current || event.nativeEvent.isComposing || event.defaultPrevented) return;
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      onClose();
    } else if (event.key === "Tab") {
      const targets = getModalFocusTargets(dialogRef.current);
      const first = targets[0];
      const last = targets[targets.length - 1];
      if (!first) {
        event.preventDefault();
        dialogRef.current.focus();
      } else if (event.shiftKey && (document.activeElement === first || document.activeElement === dialogRef.current)) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialogRef.current)) {
        event.preventDefault();
        first.focus();
      }
    }
  }
  // 팝업 안쪽 입력·버튼 클릭은 유지하고, 팝업 바깥 반투명 배경을 눌렀을 때만 닫습니다.
  // target은 실제 누른 요소, currentTarget은 이 핸들러가 연결된 배경 요소입니다.
  function handleBackgroundClick(event) {
    // 입력창 같은 안쪽 요소를 누르면 target과 currentTarget이 달라 닫지 않습니다.
    if (event.target === event.currentTarget) onClose();
  }
  return (
    <div
      className="sm-modal-backdrop"
      aria-label="일정 팝업 배경"
      onMouseDown={handleBackgroundClick}
    >
      <section
        ref={dialogRef}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
        className={`sm-modal ${className}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={id}
      >
        <div className="sm-modal-head">
          <div>
            <h2 id={id}>{title}</h2>
            <p>{description}</p>
            {headerExtra}
          </div>
          <button
            type="button"
            className="sm-close"
            aria-label="닫기"
            onClick={onClose}
          >
            ×
          </button>
        </div>
        {children}
      </section>
    </div>
  );
}
