import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useERP } from "../context/ERPContext";
import {
    formatQuotationId,
    formatCustomerName,
    formatProductName,
    formatPrice
} from "../utils/formatUtils";
import "./QuotationDetail.css"
import { getQuotationPriceDetails } from "../utils/quotationUtils";

function QuotationDetail() {

    const { id } = useParams();
    const navi = useNavigate();

    const {
        quotations,
        updateQuotation,
        deleteQuotation,
        customers,
        products,
        employees
    } = useERP();

    const [newEmployeeId, setNewEmployeeId] = useState("");

    useEffect(() => {
        setNewEmployeeId("");
    }, [id]);

    // URL의 견적 ID와 일치하는 견적서 찾기
    const quotation = quotations.find(
        q => q.id === Number(id)
    );

    if (!quotation) {
        return <div>견적서를 찾을 수 없습니다.</div>;
    }

    //옵션 포함 단가 계산
    const priceDetails = getQuotationPriceDetails(quotation);

    //옵션 추가 단가
    const optionUnitPrice = priceDetails.optionUnitPrice;

    //옵션 포함 최종 단가
    const finalUnitPrice = priceDetails.finalUnitPrice;

    //공급가액 계산
    const supplyAmount = Number(quotation.quantity || 0) * finalUnitPrice;

    //부가세 및 최종 금액
    const vat = supplyAmount * 0.1;
    const finalPrice = supplyAmount + vat;

    // 담당자 이름 찾기
    const employee = employees.find(
        e => e.id === quotation.employeeId
    );

    // 기존 담당자의 업무 수행 가능 여부
    const isValidEmployee =
        employee?.status === "재직" &&
        employee?.department === "영업팀";

    // 새로 선택할 수 있는 담당자
    const availableEmployees = employees.filter(e =>
        e.status === "재직" &&
        e.department === "영업팀"
    );

    //거래처 찾는 코드
    const customer = customers.find(
        c => c.id === quotation.customerId
    )

    // 승인 완료 처리
    const handleApprove = () => {
        const result = updateQuotation({
            id: quotation.id,
            status: "승인 완료"
        })

        if (!result.ok) {
            alert(result.message)
            return;
        }

        alert("견적서가 승인 완료되었습니다.");
    };

    // 반려 처리
    const handleReject = () => {
        const result = updateQuotation({
            id: quotation.id,
            status: "반려"
        })

        if (!result.ok) {
            alert(result.message)
            return;
        }

        alert("견적서가 반려되었습니다.");
    };

    // 재검토 요청 처리
    const handleReview = () => {

        // 기존 담당자가 유효하지 않으면 새 담당자 선택 필수
        if (!isValidEmployee && !newEmployeeId) {
            alert("새로운 담당자를 선택해주세요.");
            return;
        }

        const result = updateQuotation({
            id: quotation.id,
            employeeId: isValidEmployee
                ? quotation.employeeId
                : Number(newEmployeeId),
            status: "승인 대기"
        });

        if (!result.ok) {
            alert(result.message);
            return;
        }

        setNewEmployeeId("");
        alert("재검토 요청이 완료되었습니다.");
    };

    //견적서 수정
    const handleEdit = () => {

        if (!window.confirm("견적서를 수정하시겠습니까?")) {
            return;
        }

        if (quotation.status === "승인 완료" ||
            quotation.status === "반려"
        ) {
            alert("수정할 수 없는 견적서입니다.")
            return;
        }

        navi("/quotation/create", {
            state: {
                editId: quotation.id,
                fromDetail: true
            }
        })
    }

    //견적서 삭제
    const handleDelete = () => {

        if (!window.confirm("이 견적서를 삭제하시겠습니까?\n삭제한 견적서는 복구할 수 없습니다.")) {
            return;
        }

        const result = deleteQuotation(quotation.id);

        if (!result.ok) {
            alert(result.message);
            return;
        }

        alert("견적서가 삭제되었습니다.");
        navi("/quotation");

    }

    return (
        <div className="quotation-detail">

            <header className="detail-header">
                <div>
                    <h1>견적 상세 정보</h1>
                    <p>견적 번호: {formatQuotationId(quotation.id)}</p>
                </div>
            </header>

            <main className="detail-content">

                <section className="detail-info">
                    <h2>견적 정보</h2>

                    <div className="detail-info-grid">
                        <div className="detail-item">
                            <span>거래처</span>
                            <strong>{formatCustomerName(customers, quotation.customerId)}</strong>
                        </div>

                        <div className="detail-item">
                            <span>거래처 담당자</span>
                            <strong>{customer?.customerManager || "-"}</strong>
                        </div>

                        <div className="detail-item">
                            <span>거래처 연락처</span>
                            <strong>{customer?.phone || "-"}</strong>
                        </div>

                        <div className="detail-item">
                            <span>상품</span>
                            <strong>{formatProductName(products, quotation.productId)}</strong>
                        </div>

                        <div className="detail-item">
                            <span>내부 담당자</span>
                            <strong>{employee?.name || "-"}</strong>
                        </div>

                        <div className="detail-item">
                            <span>작성일</span>
                            <strong>{quotation.createdAt}</strong>
                        </div>

                        <div className="detail-item">
                            <span>납품 예정일</span>
                            <strong>{quotation.deliveryDate || "-"}</strong>
                        </div>

                        <div className="detail-item">
                            <span>견적 유효기간</span>
                            <strong>{quotation.validUntil || "-"}</strong>
                        </div>

                        <div className="detail-item">
                            <span>수량</span>
                            <strong>{quotation.quantity?.toLocaleString()}개</strong>
                        </div>

                        <div className="detail-item">
                            <span>기본 단가</span>
                            <strong>{formatPrice(priceDetails.baseUnitPrice)}</strong>
                        </div>

                        <div className="detail-item option-detail-item">
                            <span>제작 옵션</span>

                            <div className="detail-option-list">
                                {(quotation.options ?? []).length === 0 ? (
                                    <strong>없음</strong>
                                ) : (
                                    quotation.options.map((option, index) => (
                                        <div className="detail-option-item" key={index}>
                                            <span className="option-name" >
                                                {option.name}
                                            </span>
                                            <strong className="option-price">
                                                {Number(option.unitPrice ?? 0).toLocaleString()}원
                                            </strong>
                                        </div>
                                    ))
                                )}
                            </div>

                        </div>

                        <div className="detail-item">
                            <span>옵션 포함 최종 단가</span>
                            <strong>{formatPrice(finalUnitPrice)}</strong>
                        </div>

                    </div>
                </section>

                <section className="detail-price">
                    <h2>견적 금액</h2>

                    <div className="price-row">
                        <span>공급가액</span>
                        <strong>{formatPrice(supplyAmount)}</strong>
                    </div>

                    <div className="price-row">
                        <span>부가세 (10%)</span>
                        <strong>{formatPrice(vat)}</strong>
                    </div>

                    <div className="price-divider"></div>

                    <div className="price-info">
                        <span>총 견적 금액 (부가세 포함)</span>
                        <strong>
                            {formatPrice(finalPrice)}
                        </strong>
                    </div>
                </section>

                <section className="detail-status">
                    <h2>진행 상태</h2>
                    <span className={`detail-status-badge ${quotation.status === "승인 완료" ? "approved" :
                        quotation.status === "승인 대기" ? "pending" :
                            quotation.status === "반려" ? "rejected" : "temporary"
                        }`}>
                        {quotation.status}
                    </span>
                </section>

                <section className="detail-memo">
                    <h2>메모</h2>
                    <p>{quotation.memo || "등록된 메모가 없습니다."}</p>
                </section>

            </main>

            {quotation.status === "반려" && !isValidEmployee && (
                <div className="review-notice">
                    <strong>담당자 변경이 필요합니다.</strong>
                    <p>
                        기존 담당자가 업무를 수행할 수 없는 상태입니다.
                        새로운 담당자를 지정한 후 재검토를 요청해주세요.
                    </p>
                </div>
            )}

            <div className="detail-actions">

                <div className="detail-process">
                    {quotation.status === "승인 대기" && (
                        <>
                            <button className="approve-btn" onClick={handleApprove}>
                                승인 완료
                            </button>

                            <button className="reject-btn" onClick={handleReject}>
                                반려
                            </button>
                        </>
                    )}

                    {(quotation.status === "승인 완료" ||
                        quotation.status === "반려") && (
                            <>
                                {quotation.status === "반려" && !isValidEmployee && (
                                    <div className="review-employee">
                                        <label>새 담당자</label>

                                        <select
                                            value={newEmployeeId}
                                            onChange={(e) => setNewEmployeeId(e.target.value)}
                                        >
                                            <option value="">담당자를 선택해주세요</option>

                                            {availableEmployees.map(e => (
                                                <option key={e.id} value={e.id}>
                                                    {e.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}

                                <button
                                    className="review-btn"
                                    onClick={handleReview}
                                    disabled={!isValidEmployee && !newEmployeeId}
                                >
                                    재검토 요청
                                </button>
                            </>
                        )}

                </div>

                <div className="detail-manage">
                    {(quotation.status !== "승인 완료" &&
                        quotation.status !== "반려") && (
                            <button className="edit-btn" onClick={handleEdit}>
                                수정
                            </button>
                        )}

                    {quotation.status !== "승인 완료" && (
                        <button className="delete-btn" onClick={handleDelete}>
                            삭제
                        </button>
                    )}
                    <button className="back-btn" onClick={() => navi("/quotation")}>
                        목록으로
                    </button>
                </div>

            </div>
        </div>
    );
}

export default QuotationDetail;