
import React, { useEffect, useState } from "react";
import { Link, useLocation, useSearchParams } from "react-router-dom";
import "./Dashboard.css";

import DashboardToday from "./DashboardToday";

// 같은 6번 폴더에 있는 프로젝트 관리 화면
import ProjectPage, { readProjects } from "./ProjectPage";

// 커뮤니티 페이지
import CommunityPage from "./CommunityPage";
import CommunityWritePage from "./CommunityWritePage";
import CommunityDetailPage from "./CommunityDetailPage";

// 공지사항 페이지
import NoticePage from "./NoticePage";
import NoticeWritePage from "./NoticeWritePage";
import NoticeDetailPage from "./NoticeDetailPage";


// 대시보드 안에서 프로젝트 관리 화면을 여는 주소
const PROJECT_PATH = "/?page=project";


function DashboardPage() {

    const location = useLocation();
    const [searchParams] = useSearchParams();

    // 현재 화면 구분
    const page = searchParams.get("page");


    // ==========================
    // 커뮤니티 게시글
    // ==========================

    const [posts, setPosts] = useState(() => {

        const saved = localStorage.getItem("communityPosts");

        if (!saved) return [];

        try {
            const data = JSON.parse(saved);
            return Array.isArray(data) ? data : [];
        } catch {
            return [];
        }
    });


    // ==========================
    // 공지사항
    // ==========================

    const [noticePosts, setNoticePosts] = useState(() => {

        const saved = localStorage.getItem("noticePosts");

        if (!saved) return [];

        try {
            const data = JSON.parse(saved);
            return Array.isArray(data) ? data : [];
        } catch {
            return [];
        }
    });


    // 일반 공지사항 최신 3개
    const recentNotices = [...noticePosts]
        .filter((post) => post.type === "normal")
        .sort((a, b) => Number(b.id) - Number(a.id))
        .slice(0, 3);


    // 중요공지 최신 1개
    const importantNotice = [...noticePosts]
        .filter((post) => post.type === "important")
        .sort((a, b) => Number(b.id) - Number(a.id))[0];


    // 커뮤니티 최신 3개
    const recentPosts = [...posts]
        .sort((a, b) => Number(b.id) - Number(a.id))
        .slice(0, 3);


    // ==========================
    // 프로젝트 관리
    // ==========================

    // 같은 폴더의 ProjectPage가 사용하는 데이터
    const [projects, setProjects] = useState(readProjects);


    // 대시보드로 돌아왔을 때 다시 불러오기
    useEffect(() => {
        setProjects(readProjects());
    }, [location.key]);


    // 저장된 프로젝트가 바뀌면 새 목록을 가져오기
    useEffect(() => {

        const refresh = () => {
            setProjects(readProjects());
        };

        // 다른 탭에서 프로젝트를 변경했을 때
        const onStorage = (e) => {
            if (e.key === "moduProjects" || e.key === null) {
                refresh();
            }
        };

        window.addEventListener("focus", refresh);
        window.addEventListener("storage", onStorage);

        // 같은 탭에서 프로젝트를 변경했을 때
        window.addEventListener("moduProjectsChanged", refresh);

        return () => {
            window.removeEventListener("focus", refresh);
            window.removeEventListener("storage", onStorage);
            window.removeEventListener("moduProjectsChanged", refresh);
        };

    }, []);


    // 가장 최근 등록한 프로젝트 3개만 표시
    // 프로젝트 등록 시 ID가 증가하는 기존 방식 사용
    const recentProjects = [...projects]
        .sort((a, b) => Number(b.id) - Number(a.id))
        .slice(0, 3);


    // ==========================
    // 프로젝트 관리 화면 연결
    // ==========================

    if (page === "project") {
        return <ProjectPage />;
    }


    // ==========================
    // 커뮤니티 화면
    // ==========================

    if (page === "community") {
        return <CommunityPage posts={posts} />;
    }

    if (page === "write") {
        return (
            <CommunityWritePage
                posts={posts}
                setPosts={setPosts}
            />
        );
    }

    if (page === "detail") {
        return (
            <CommunityDetailPage
                posts={posts}
                setPosts={setPosts}
                postId={searchParams.get("id")}
            />
        );
    }


    // ==========================
    // 공지사항 화면
    // ==========================

    if (page === "notice") {
        return <NoticePage posts={noticePosts} />;
    }

    if (page === "notice-write") {
        return (
            <NoticeWritePage
                posts={noticePosts}
                setPosts={setNoticePosts}
            />
        );
    }

    if (page === "notice-detail") {
        return (
            <NoticeDetailPage
                key={searchParams.get("id")}
                posts={noticePosts}
                setPosts={setNoticePosts}
                postId={searchParams.get("id")}
            />
        );
    }


    // ==========================
    // 대시보드 메인
    // ==========================

    return (
        <div className="dashboard">

            <h1>대시보드</h1>


            {/* 중요공지 */}
            <div className="dashboard-banner">

                <strong>NOTICE</strong>

                {importantNotice ? (
                    <Link
                        to={"/?page=notice-detail&id=" + importantNotice.id}
                        className="notice-banner-link"
                    >
                        {importantNotice.title}
                    </Link>
                ) : (
                    <span>등록된 중요공지가 없습니다.</span>
                )}

            </div>


            {/* 프로젝트 관리 카드 */}
            <div className="dashboard-card dashboard-project-card">

                {/* 빈 공간은 프로젝트 관리 목록으로 이동 */}
                <Link
                    to={PROJECT_PATH}
                    className="dashboard-project-cover"
                    aria-label="프로젝트 관리 목록으로 이동"
                />

                <h3>프로젝트 관리</h3>


                {/* 프로젝트가 없으면 안내문 표시 */}
                {recentProjects.length === 0 ? (
                    <p>등록된 프로젝트가 없습니다.</p>
                ) : (

                    recentProjects.map((project) => (

                        <div
                            className="dashboard-post"
                            key={project.id}
                        >

                            {/* 클릭한 프로젝트의 상세 화면으로 이동 */}
                            <Link
                                className="dashboard-post-link dashboard-project-link"
                                to={
                                    PROJECT_PATH +
                                    "&projectId=" +
                                    encodeURIComponent(project.id)
                                }
                            >

                                <span className="dashboard-post-title">
                                    {project.name}
                                </span>

                                <span className="dashboard-post-writer">
                                    {project.status}
                                </span>

                                <span className="dashboard-post-date">
                                    {project.dueDate || "미정"}
                                </span>

                            </Link>

                        </div>
                    ))
                )}

            </div>


            {/* 공지사항 / 커뮤니티 / 오늘의 일정 */}
            <div className="dashboard-grid">

                <div className="dashboard-left">

                    {/* 일반 공지사항 */}
                    <div className="dashboard-card">

                        <Link
                            to="/?page=notice"
                            className="dashboard-community-heading"
                        >
                            <h3>공지사항</h3>
                        </Link>

                        {recentNotices.length === 0 ? (
                            <p>등록된 공지사항이 없습니다.</p>
                        ) : (

                            recentNotices.map((post) => (

                                <div
                                    className="dashboard-post"
                                    key={post.id}
                                >

                                    <Link
                                        className="dashboard-post-link"
                                        to={"/?page=notice-detail&id=" + post.id}
                                    >

                                        <span className="dashboard-post-title">
                                            {post.title}
                                        </span>

                                        <span className="dashboard-post-writer">
                                            {post.writer}
                                        </span>

                                        <span className="dashboard-post-date">
                                            {post.date}
                                        </span>

                                    </Link>

                                </div>
                            ))
                        )}

                    </div>


                    {/* 사내 커뮤니티 */}
                    <div className="dashboard-card">

                        <Link
                            to="/?page=community"
                            className="dashboard-community-heading"
                        >
                            <h3>사내 커뮤니티</h3>
                        </Link>

                        {recentPosts.length === 0 ? (
                            <p>등록된 게시글이 없습니다.</p>
                        ) : (

                            recentPosts.map((post) => (

                                <div
                                    className="dashboard-post"
                                    key={post.id}
                                >

                                    <Link
                                        className="dashboard-post-link"
                                        to={"/?page=detail&id=" + post.id}
                                    >

                                        <span className="dashboard-post-title">
                                            {post.title}
                                        </span>

                                        <span className="dashboard-post-writer">
                                            {post.writer}
                                        </span>

                                        <span className="dashboard-post-date">
                                            {post.date}
                                        </span>

                                    </Link>

                                </div>
                            ))
                        )}

                    </div>

                </div>


                {/* 기존 오늘의 일정 */}
                <div className="dashboard-right">

                    <div className="dashboard-card schedule-card">

                        <Link
                            to="/schedule"
                            className="dashboard-community-heading"
                        >
                            <h3>오늘의 일정</h3>
                        </Link>

                        <DashboardToday />

                    </div>

                </div>

            </div>

        </div>
    );
}

export default DashboardPage;
