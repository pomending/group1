
import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import "./projects.css";

import ProjectList from "./ProjectList";
import ProjectForm from "./ProjectForm";
import ProjectDetail from "./ProjectDetail";
import ProjectEdit from "./ProjectEdit";

import { quotations, customers, employees } from "../data/mockData";


// 원래 ProjectPage에 들어 있던 기존 프로젝트
// 새 프로젝트를 여기에 직접 적을 필요는 없음
const initialProjects = [
    {
        id: 1,
        name: "ABC대학교 텀블러 제작",
        quotationId: 1,
        customerId: 1,
        managerId: 1,
        startDate: "2026-10-21",
        dueDate: "2026-11-20",
        completedDate: null,
        status: "진행 중",
        description: "창립기념 텀블러 300개 제작"
    },
    {
        id: 2,
        name: "미래전자 에코백 제작",
        quotationId: 2,
        customerId: 2,
        managerId: 2,
        startDate: "2026-10-25",
        dueDate: "2026-11-15",
        completedDate: null,
        status: "대기",
        description: "홍보용 에코백 500개 제작"
    }
];


// 프로젝트를 저장할 때 사용하는 이름
const STORAGE_KEY = "moduProjects";


// 저장된 프로젝트 목록 불러오기
// 대시보드에서도 사용하는 함수
export function readProjects() {

    try {
        const saved = localStorage.getItem(STORAGE_KEY);

        // 처음 실행했을 때는 원래 프로젝트 목록 사용
        if (saved === null) {
            return initialProjects;
        }

        const data = JSON.parse(saved);

        // 저장된 배열이 있다면 그 목록을 사용
        // []도 그대로 인정해서 삭제한 프로젝트를 되살리지 않음
        return Array.isArray(data) ? data : initialProjects;

    } catch {
        return initialProjects;
    }
}


function ProjectPage() {

    // 기존 프로젝트와 새로 등록한 프로젝트를 관리
    const [projects, setProjects] = useState(readProjects);

    // 기존 검색 기능
    const [search, setSearch] = useState("");
    const [searchstat, setSearchStat] = useState("");


    // 주소에서 프로젝트 번호 가져오기
    // 예: /?page=project&projectId=3
    const [searchParams, setSearchParams] = useSearchParams();
    const requestedId = searchParams.get("projectId");


    // 처음 화면 결정
    const [page, setPage] = useState(
        requestedId ? "detail" : "list"
    );

    // 현재 선택한 프로젝트 번호
    const [selectedProjectId, setSelectedProjectId] = useState(
        requestedId ? Number(requestedId) : ""
    );


    // 프로젝트가 등록, 수정, 삭제되면 저장
    useEffect(() => {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(projects)
        );

        // 대시보드에도 변경된 사실을 알림
        window.dispatchEvent(
            new Event("moduProjectsChanged")
        );

    }, [projects]);


    // 대시보드에서 프로젝트를 클릭한 경우
    // 해당 프로젝트 상세 화면으로 이동
    useEffect(() => {

        if (requestedId) {
            setSelectedProjectId(Number(requestedId));
            setPage("detail");

        } else {
            setPage("list");
        }

    }, [requestedId]);


    // 프로젝트 관리 안에서 화면 이동
    const changePage = (nextPage) => {

        setPage(nextPage);

        // 상세에서 목록으로 돌아가면 주소의 번호 삭제
        if (nextPage === "list" && requestedId) {

            const params = new URLSearchParams(searchParams);

            params.delete("projectId");

            setSearchParams(params, { replace: true });
        }
    };


    return (
        <div>

            {/* 프로젝트 목록 */}
            {page === "list" && (
                <ProjectList
                    projects={projects}
                    page={page}
                    setPage={changePage}
                    search={search}
                    setSearch={setSearch}
                    searchstat={searchstat}
                    setSearchStat={setSearchStat}
                    selectedProjectId={selectedProjectId}
                    setSelectedProjectId={setSelectedProjectId}
                />
            )}


            {/* 새 프로젝트 등록 */}
            {page === "newproject" && (
                <ProjectForm
                    page={page}
                    setPage={changePage}
                    projects={projects}
                    setProjects={setProjects}
                    quotations={quotations}
                    customers={customers}
                    employees={employees}
                />
            )}


            {/* 프로젝트 상세 */}
            {page === "detail" && (
                <ProjectDetail
                    key={selectedProjectId}
                    page={page}
                    setPage={changePage}
                    projects={projects}
                    selectedProjectId={selectedProjectId}
                    setProjects={setProjects}
                    quotations={quotations}
                    customers={customers}
                    employees={employees}
                />
            )}


            {/* 프로젝트 수정 */}
            {page === "edit" && (
                <ProjectEdit
                    page={page}
                    setPage={changePage}
                    projects={projects}
                    selectedProjectId={selectedProjectId}
                    quotations={quotations}
                    customers={customers}
                    employees={employees}
                    setProjects={setProjects}
                />
            )}

        </div>
    );
}

export default ProjectPage;
