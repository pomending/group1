import React, { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import "./HomeTopbar.css";

function HomeTopbar({ onPageChange, onMasterChange }){
    
    const navi = useNavigate()
    const [searchParams, setSearchParams] = useSearchParams()

    //현재 선택된 메뉴
    const currentPage = searchParams.get("page") || "home"

    //마스터 모드 관련 상태
    const [clickCount, setClickCount] = useState(0)
    const [showMasterInput, setShowMasterInput] = useState(false)
    const [masterNumber, setMasterNumber] = useState("")
    const [masterError, setMasterError] = useState("")
    const [isMaster, setIsMaster] = useState(false)

    const menus = [
        { name: "홈", page: "home" },
        { name: "제작 상품", page: "products" },
        { name: "클레임 문의", page: "claim" }
    ]

    //홈페이지 메뉴 이동
    function movePage(page){
        if(page === "home"){
            setSearchParams({})
        }else{
            setSearchParams({page:page})
        }

        if(onPageChange){
            onPageChange(page)
        }
    }

    //상자 로고 5회 클릭시 마스터 번호 입력창 표시
    function LogoClick(){
        if(isMaster)return

        if(clickCount === 4){
            setShowMasterInput(true)
            setClickCount(0)
            setMasterNumber("")
            setMasterError("")
        }else{
            setClickCount(clickCount + 1)
        }
    }

    //마스터 번호 확인
    function checkMaster(event){
        event.preventDefault()

        //마스터 번호
        if(masterNumber === "2468"){
            setIsMaster(true)
            setShowMasterInput(false)
            setMasterNumber("")
            setMasterError("")
            
            if(onMasterChange){
                onMasterChange(true)
            }
        }else{
            setMasterError("마스터 번호가 일치하지 않습니다.")
        }
        
    }

    //마스터 모드 종료
    function exitMaster(){
        setIsMaster(false)
        setShowMasterInput(false)
        setClickCount(0)

        if(onMasterChange){
            onMasterChange(false)
        }
    }

    //기존 대시보드로 이동
    function goDashboard(){
        navi("/")
    }
    
    return (
        <>
            <header className="home-topbar">
                <div className="home-topbar-inner">

                    {/* 홈페이지 로고 */}
                    <div className="home-topbar-brand">
                        <button
                            type="button"
                            className="home-topbar-logo"
                            onClick={LogoClick}
                            aria-label="GOODS 로고"
                        >
                            📦
                        </button>

                        <div className="home-topbar-name">
                            <strong>GOODS</strong>
                            <span>CUSTOM GOODS STUDIO</span>
                        </div>
                    </div>

                    {/* 마스터 모드 버튼 */}
                    <div className="home-topbar-right">
                        {isMaster ? (
                            <>
                                <button
                                    type="button"
                                    className="home-master-dashboard"
                                    onClick={goDashboard}
                                >
                                    대시보드
                                </button>

                                <button
                                    type="button"
                                    className="home-master-exit"
                                    onClick={exitMaster}
                                >
                                    마스터 종료
                                </button>
                            </>
                        ) : (
                            <span className="home-customer-label">
                                기업 고객 전용
                            </span>
                        )}
                    </div>
                </div>

                {/* 홈페이지 메뉴 */}
                <nav className="home-topbar-nav">
                    <div className="home-topbar-menu">
                        {menus.map((menu) => (
                            <button
                                key={menu.page}
                                type="button"
                                className={
                                    currentPage === menu.page
                                        ? "home-menu-button active"
                                        : "home-menu-button"
                                }
                                onClick={() => movePage(menu.page)}
                            >
                                {menu.name}
                            </button>
                        ))}
                    </div>
                </nav>
            </header>

            {/* 마스터 번호 입력창 */}
            {showMasterInput && (
                <div className="home-master-overlay">
                    <form
                        className="home-master-dialog"
                        onSubmit={checkMaster}
                    >
                        <h2>마스터 번호 입력</h2>

                        <p>
                            마스터 번호를 입력하면
                            관리 기능을 사용할 수 있습니다.
                        </p>

                        <input
                            type="password"
                            value={masterNumber}
                            onChange={(event) => {
                                setMasterNumber(event.target.value);
                                setMasterError("");
                            }}
                            placeholder="마스터 번호"
                            autoFocus
                        />

                        {masterError && (
                            <p className="home-master-error">
                                {masterError}
                            </p>
                        )}

                        <div className="home-master-actions">
                            <button
                                type="button"
                                onClick={() => setShowMasterInput(false)}
                            >
                                취소
                            </button>

                            <button
                                type="submit"
                                disabled={!masterNumber.trim()}
                            >
                                확인
                            </button>
                        </div>
                    </form>
                </div>
            )}
        </>
    );
}


export default HomeTopbar