
import React, { useLayoutEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useERP } from "../context/ERPContext";
import { productImages, findProductImage } from "../10_product/productImages";
import "./HomeProduct.css";

// 상품 관리에서 설정한 이미지를 먼저 사용합니다.
function getImg(item) {
    let value = item.productImageUrl || "";
    let saved = null;

    try {
        saved = localStorage.getItem("erp_product_image:" + item.id);
    } catch {
        // 저장된 이미지가 없으면 기본 이미지를 확인합니다.
    }

    if (saved !== null) value = saved;
    if (saved === "") return "";
    if (value.startsWith("catalog:")) return findProductImage(value)?.src || "";

    const file = productImages.find(img => img.id === value);
    if (file) return file.src;
    if (/^(https?:\/\/|\/(?!\/)|data:image\/)/i.test(value)) return value;
    if (value) return "";

    return productImages.find(img => img.name === item.productName ||
        (item.productName === "세라믹 머그컵" && img.id === "03-ceramic-mug.jpg"))?.src || "";
}

function Photo({ item }) {
    const src = getImg(item);
    const [broken, setBroken] = useState("");

    return src && broken !== src ? (
        <img src={src} alt={item.productName} loading="lazy" onError={() => setBroken(src)} />
    ) : (
        <span className="shop-no-img" aria-label="상품 이미지 없음">📦</span>
    );
}

function HomeProduct() {
    const { products } = useERP();
    const location = useLocation();

    // 홈 미리보기에서 전달한 상품번호
    const selected = new URLSearchParams(location.search).get("product");

    const [search, setSearch] = useState("");
    const [openId, setOpenId] = useState(null);

    // 판매 중인 상품만 보여줍니다.
    const list = (products || []).filter(item =>
        item.productStatus === "판매 중" &&
        item.productName.toLowerCase().includes(search.trim().toLowerCase())
    );

    // 미리보기에서 누른 상품으로 이동합니다.
    useLayoutEffect(() => {
        const card = selected
            ? document.getElementById("shop-" + selected)
            : null;

        if (card) {
            card.scrollIntoView({
                block: "start",
                behavior: "auto"
            });
        } else {
            window.scrollTo(0, 0);
        }
    }, [selected, products]);

    // 상품 정보 열기 또는 닫기
    function toggle(id) {
        setOpenId(openId === id ? null : id);
    }

    return (
        <main className="shop">
            <div className="shop-inner">
                {/* 페이지 제목 */}
                <header className="shop-head">
                    <p>GOODS / PRODUCTS</p>
                    <h1>제작 상품</h1>
                    <span>브랜드와 행사에 어울리는 다양한 굿즈를 만나보세요.</span>
                </header>

                {/* 상품 검색 */}
                <div className="shop-search">
                    <input
                        type="search"
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        placeholder="상품명을 검색하세요."
                        aria-label="상품명 검색"
                    />
                    <span>
                        총 <strong>{list.length}</strong>개 상품
                    </span>
                </div>

                {/* 상품 목록 */}
                {list.length === 0 ? (
                    <div className="shop-empty">
                        <div aria-hidden="true">📦</div>
                        <h2>검색되는 상품이 없습니다.</h2>
                        <p>
                            {search
                                ? "다른 상품명으로 검색해 보세요."
                                : "판매 중인 상품이 등록되면 표시됩니다."}
                        </p>

                        {search && (
                            <button
                                type="button"
                                onClick={() => setSearch("")}
                            >
                                검색 초기화
                            </button>
                        )}
                    </div>
                ) : (
                    <div className="shop-list">
                        {list.map(item => (
                            <article
                                id={"shop-" + item.id}
                                className="shop-card"
                                key={item.id}
                            >
                                <div className="shop-img">
                                    <Photo item={item} />
                                </div>

                                <div className="shop-info">
                                    <small>GOODS / CUSTOM MADE</small>
                                    <h2>{item.productName}</h2>
                                    <strong>
                                        {Number(item.productPrice).toLocaleString("ko-KR")}원
                                    </strong>

                                    <button
                                        type="button"
                                        onClick={() => toggle(item.id)}
                                    >
                                        {openId === item.id
                                            ? "정보 닫기 −"
                                            : "상품 정보 +"}
                                    </button>

                                    {openId === item.id && (
                                        <div className="shop-detail">
                                            <p>상품번호: {item.id}</p>
                                            <p>상품명: {item.productName}</p>
                                            <p>
                                                기본 단가: {Number(item.productPrice).toLocaleString("ko-KR")}원
                                            </p>
                                            <p>판매 상태: {item.productStatus}</p>
                                        </div>
                                    )}
                                </div>
                            </article>
                        ))}
                    </div>
                )}
            </div>
        </main>
    );
}

export default HomeProduct;
