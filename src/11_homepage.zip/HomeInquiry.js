
import React, { useEffect, useRef, useState } from "react";
import "./HomeInquiry.css";

// 저장된 문의글을 불러옵니다.
function load() {
    try {
        const data = JSON.parse(localStorage.getItem("home_inquiries"));
        return Array.isArray(data) ? data.filter(item => item && typeof item === "object") : [];
    } catch (error) {
        return [];
    }
}

function HomeInquiry({ isMaster = false }) {
    const [sharedMaster, setSharedMaster] = useState(() => sessionStorage.getItem("homepage_master") === "true");
    const master = isMaster || sharedMaster;
    const [list, setList] = useState(load);
    const [page, setPage] = useState("list");
    const [editing, setEditing] = useState(false);
    const [companyName, setCompanyName] = useState("");
    const [customerManager, setCustomerManager] = useState("");
    const [contact, setContact] = useState("");
    const [orderNo, setOrderNo] = useState("");
    const [inquiryType, setInquiryType] = useState("제품 불량");
    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");
    const [photo, setPhoto] = useState("");
    const [photoLoading, setPhotoLoading] = useState(false);
    const photoReader = useRef(null);
    const [selected, setSelected] = useState(null);
    const [checkNo, setCheckNo] = useState("");
    const [verified, setVerified] = useState(false);
    const [error, setError] = useState("");

    // 상단바에서 마스터 모드가 변경되면 문의 화면에도 반영합니다.
    useEffect(() => {
        function updateMaster() {
            setSharedMaster(sessionStorage.getItem("homepage_master") === "true");
        }
        window.addEventListener("homepage-master-changed", updateMaster);
        return () => window.removeEventListener("homepage-master-changed", updateMaster);
    }, []);

    // 마스터 모드가 종료되면 주문번호 확인을 초기화합니다.
    useEffect(() => {
        if (!master) setVerified(false);
    }, [master]);

    // 마스터 모드에서는 이미 열어 둔 수정 화면도 닫습니다.
    useEffect(() => {
        if (master && editing) {
            setEditing(false);
            setPage("detail");
        }
    }, [master, editing]);

    useEffect(() => {
        return () => {
            if (photoReader.current) photoReader.current.abort();
        };
    }, []);

    // 사진을 지우거나 다른 사진을 고를 때 읽기를 중단합니다.
    function removePhoto() {
        if (photoReader.current) photoReader.current.abort();
        photoReader.current = null;
        setPhoto("");
        setPhotoLoading(false);
    }

    // 새 문의 작성
    function write() {
        setEditing(false);
        setCompanyName("");
        setCustomerManager("");
        setContact("");
        setOrderNo("");
        setInquiryType("제품 불량");
        setTitle("");
        setContent("");
        removePhoto();
        setError("");
        setPage("write");
    }

    // 일반 고객만 주문번호 확인 후 수정할 수 있습니다.
    function edit() {
        if (!selected || master || !verified) return;

        setEditing(true);
        setCompanyName(selected.companyName || selected.company || "");
        setCustomerManager(selected.customerManager || selected.manager || "");
        setContact(selected.phone || selected.email || selected.contact || "");
        setOrderNo(selected.orderNo || "");
        setInquiryType(selected.inquiryType || selected.type || "제품 불량");
        setTitle(selected.title || "");
        setContent(selected.content || "");
        removePhoto();
        setPhoto(selected.photo || "");
        setError("");
        setPage("write");
    }

    // 사진은 JPG, PNG, WEBP 중 한 장만 선택합니다.
    function addPhoto(e) {
        const file = e.target.files[0];
        if (!file) return;
        e.target.value = "";

        if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
            setError("JPG, PNG, WEBP 사진만 첨부할 수 있습니다.");
            return;
        }

        if (file.size > 1024 * 1024) {
            setError("사진은 1MB 이하만 첨부할 수 있습니다.");
            return;
        }

        removePhoto();
        setError("");
        setPhotoLoading(true);

        const reader = new FileReader();
        photoReader.current = reader;

        reader.onload = function () {
            if (photoReader.current !== reader) return;
            setPhoto(reader.result);
            setPhotoLoading(false);
            photoReader.current = null;
        };

        reader.onerror = function () {
            if (photoReader.current !== reader) return;
            setError("사진을 불러오지 못했습니다.");
            setPhotoLoading(false);
            photoReader.current = null;
        };

        reader.readAsDataURL(file);
    }

    // 새 글은 등록하고, 수정 중이면 기존 글을 덮어씁니다.
    function save(e) {
        e.preventDefault();

        if (!customerManager.trim() || !contact.trim() || !orderNo.trim() || !title.trim() || !content.trim()) {
            setError("필수 항목을 입력해 주세요.");
            return;
        }

        if (photoLoading) return;

        if (editing && (!selected || master || !verified)) {
            setError("수정 권한을 다시 확인해 주세요.");
            return;
        }

        let id = 1;
        list.forEach(item => {
            if (Number(item.id) >= id) id = Number(item.id) + 1;
        });

        const item = {
            ...(editing ? selected : {}),
            id: editing ? selected.id : id,
            companyName: companyName.trim(),
            customerManager: customerManager.trim(),
            phone: contact.includes("@") ? "" : contact.trim(),
            email: contact.includes("@") ? contact.trim() : "",
            orderNo: orderNo.trim(),
            inquiryType: inquiryType,
            title: title.trim(),
            content: content.trim(),
            photo: photo,
            status: editing ? selected.status : "접수",
            createdAt: editing ? (selected.createdAt || selected.date) : new Date().toLocaleDateString("sv-SE")
        };

        const next = editing ? list.map(post => post.id === selected.id ? item : post) : [item, ...list];

        try {
            localStorage.setItem("home_inquiries", JSON.stringify(next));
        } catch (error) {
            setError("저장하지 못했습니다. 사진 크기나 저장 공간을 확인해 주세요.");
            return;
        }

        setList(next);
        setSelected(editing ? item : null);
        setPage(editing ? "detail" : "list");
        setEditing(false);
        setError("");
    }

    // 일반 고객은 인증 후, 마스터는 바로 삭제할 수 있습니다.
    function remove() {
        if (!selected || (!master && !verified)) return;
        if (!window.confirm("이 문의글을 삭제하시겠습니까?")) return;

        const next = list.filter(item => item.id !== selected.id);

        try {
            localStorage.setItem("home_inquiries", JSON.stringify(next));
        } catch (error) {
            setError("문의글을 삭제하지 못했습니다.");
            return;
        }

        setList(next);
        back();
    }

    // 게시글 상세 화면을 엽니다.
    function open(item) {
        setSelected(item);
        setVerified(false);
        setCheckNo("");
        setError("");
        setPage("detail");
    }

    // 일반 고객의 주문번호를 확인합니다.
    function check(e) {
        e.preventDefault();

        if (selected && checkNo.trim() && checkNo.trim() === selected.orderNo) {
            setVerified(true);
            setError("");
        } else {
            setError("주문번호가 일치하지 않습니다.");
        }
    }

    // 이전 화면으로 돌아갑니다.
    function back() {
        removePhoto();
        setError("");

        if (editing && selected) {
            setEditing(false);
            setPage("detail");
        } else {
            setSelected(null);
            setVerified(false);
            setPage("list");
        }
    }

    return (
        <main className="inq">
            <div className="inq-inner">
                {/* 문의 목록 */}
                {page === "list" && (
                    <section>
                        <header className="inq-head">
                            <p>GOODS / CLAIM</p>
                            <h1>클레임 문의</h1>
                            <span>등록된 문의를 확인하거나 새로운 문의를 작성할 수 있습니다.</span>
                        </header>

                        <div className="inq-bar">
                            <h2>문의 목록</h2>
                            <button type="button" onClick={write}>문의 작성 +</button>
                        </div>

                        <table className="inq-table">
                            <thead>
                                <tr><th>제목</th><th>처리 상태</th><th>등록일</th></tr>
                            </thead>
                            <tbody>
                                {list.length === 0 && (
                                    <tr><td className="inq-empty" colSpan={3}>등록된 문의가 없습니다.</td></tr>
                                )}

                                {list.map(item => (
                                    <tr className="inq-row" key={item.id} role="button" tabIndex={0}
                                        onClick={() => open(item)}
                                        onKeyDown={e => {
                                            if (e.key === "Enter" || e.key === " ") {
                                                e.preventDefault();
                                                open(item);
                                            }
                                        }}>
                                        <td>{item.title}</td>
                                        <td><span className="inq-status">{item.status || "접수"}</span></td>
                                        <td>{item.createdAt || item.date}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </section>
                )}

                {/* 문의 작성 및 수정 */}
                {page === "write" && (
                    <section>
                        <header className="inq-write-head">
                            <div>
                                <h1>{editing ? "클레임 수정" : "클레임 글쓰기"}</h1>
                                <p>제작 및 납품 관련 문의 내용을 작성합니다.</p>
                            </div>
                            <button type="button" onClick={back}>취소</button>
                        </header>

                        <form onSubmit={save}>
                            <div className="inq-box">
                                <h2>업체 및 주문 정보</h2>

                                <label>업체명
                                    <input value={companyName} onChange={e => setCompanyName(e.target.value)} placeholder="업체명" />
                                </label>

                                <div className="inq-two">
                                    <label>작성자 *
                                        <input value={customerManager} onChange={e => setCustomerManager(e.target.value)} placeholder="문의글 작성자 이름" required />
                                    </label>

                                    <label>연락처 *
                                        <input value={contact} onChange={e => setContact(e.target.value)} placeholder="전화번호 또는 이메일" required />
                                    </label>
                                </div>

                                <label>주문번호 *
                                    <input value={orderNo} onChange={e => setOrderNo(e.target.value)} placeholder="예: GO-3001" required />
                                </label>

                                <small>게시글 상세 열람에 사용됩니다.</small>
                            </div>

                            <div className="inq-box">
                                <h2>문의 내용</h2>

                                <label>문의 유형
                                    <select value={inquiryType} onChange={e => setInquiryType(e.target.value)}>
                                        <option>제품 불량</option>
                                        <option>수량 부족</option>
                                        <option>배송 문제</option>
                                        <option>기타 문의</option>
                                    </select>
                                </label>

                                <label>제목 *
                                    <input value={title} onChange={e => setTitle(e.target.value)} placeholder="게시글 제목" required />
                                </label>

                                <label>내용 *
                                    <textarea value={content} onChange={e => setContent(e.target.value)} placeholder="문제와 요청 사항을 작성해 주세요." required />
                                </label>

                                <label>사진 첨부 (선택, 1MB 이하)
                                    <input type="file" accept="image/jpeg,image/png,image/webp" onChange={addPhoto} />
                                </label>

                                {photoLoading && <p className="inq-note">사진을 읽고 있습니다.</p>}

                                {photo && (
                                    <div className="inq-photo">
                                        <img src={photo} alt="첨부 사진 미리보기" />
                                        <button type="button" onClick={removePhoto}>사진 제거</button>
                                    </div>
                                )}
                            </div>

                            {error && <p className="inq-error" role="alert">{error}</p>}

                            <div className="inq-actions">
                                <button type="button" onClick={back}>취소</button>
                                <button type="submit"
                                    disabled={photoLoading || !customerManager.trim() || !contact.trim() || !orderNo.trim() || !title.trim() || !content.trim()}>
                                    {editing ? "수정 완료" : "게시글 등록"}
                                </button>
                            </div>
                        </form>
                    </section>
                )}

                {/* 문의 상세 */}
                {page === "detail" && selected && (
                    <section>
                        <header className="inq-head">
                            <p>GOODS / CLAIM</p>
                            <h1>{selected.title}</h1>
                        </header>

                        {master || verified ? (
                            <div className="inq-box inq-detail">
                                <div className="inq-detail-top">
                                    <h2>문의 상세</h2>
                                    <span className="inq-status">{selected.status || "접수"}</span>
                                </div>

                                <div className="inq-detail-info">
                                    <div><span>업체명</span><strong>{selected.companyName || selected.company || "-"}</strong></div>
                                    <div><span>작성자</span><strong>{selected.customerManager || selected.manager || "-"}</strong></div>
                                    <div><span>연락처</span><strong>{selected.phone || selected.email || selected.contact || "-"}</strong></div>
                                    <div><span>주문번호</span><strong>{selected.orderNo}</strong></div>
                                    <div><span>문의 유형</span><strong>{selected.inquiryType || selected.type || "기타 문의"}</strong></div>
                                </div>

                                <div className="inq-detail-body">
                                    <h3>문의 내용</h3>
                                    <p>{selected.content}</p>
                                </div>

                                {selected.photo && (
                                    <div className="inq-detail-images">
                                        <h3>첨부 사진</h3>
                                        <img className="inq-detail-photo" src={selected.photo} alt="문의 첨부 사진" />
                                    </div>
                                )}
                            </div>
                        ) : (
                            <form className="inq-box" onSubmit={check}>
                                <h2>주문번호 확인</h2>
                                <p>문의 내용을 확인하려면 주문번호를 입력하세요.</p>

                                <label>주문번호
                                    <input value={checkNo} onChange={e => setCheckNo(e.target.value)} placeholder="주문번호" required />
                                </label>

                                {error && <p className="inq-error" role="alert">{error}</p>}

                                <div className="inq-actions">
                                    <button type="submit">확인</button>
                                </div>
                            </form>
                        )}

                        {error && (master || verified) && <p className="inq-error" role="alert">{error}</p>}

                        <div className="inq-actions">
                            <button type="button" onClick={back}>목록으로</button>

                            {(master || verified) && (
                                <div className="inq-detail-buttons">
                                    {!master && verified && (
                                        <button type="button" onClick={edit}>수정</button>
                                    )}
                                    <button type="button" className="inq-delete" onClick={remove}>삭제</button>
                                </div>
                            )}
                        </div>
                    </section>
                )}
            </div>
        </main>
    );
}

export default HomeInquiry;
